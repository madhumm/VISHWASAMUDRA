﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Settings.IOModels
{
    public class UserMenuControl
    {
        public string Operation { get; set; }
        public Guid? ApplicationId { get; set; }
        public string ApplicationName { get; set; }
        public Guid? MenuId { get; set; }
        public string MenuName { get; set; }
        public Guid? ParentMenuID { get; set; }

		public string Path { get; set; }

	}
}
