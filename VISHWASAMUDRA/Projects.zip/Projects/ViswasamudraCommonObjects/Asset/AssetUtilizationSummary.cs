﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Text;
using System.Text.Json.Serialization;

namespace ViswasamudraCommonObjects.Asset
{
    public class AssetUtilizationSummary
    {
        public Guid? PROJECT_CODE { get; set; }
        public Guid? ASSET_SPECIFICATION { get; set; }
        public string PROJECT_CODE_NAME { get; set; }
        public string ASSET_TYPE_NAME { get; set; }
        public string ASSET_SPECIFICATION_NAME { get; set; }
        public Guid? ASSET_TYPE { get; set; }
        public string Utilization { get; set; }

        public bool filterEnabled{get;set;}
            public List<AssetUtilizationSummary> assetUtilizationSummary { get; set; }
    }

    public class AssetUtilizationSummaryReport
    {
        [Display(Name="Project Name")]
        public string PROJECT_NAME { get; set; }
        [DisplayName("Asset Name")]
        public string ASSET_TYPE { get; set; }
        [DisplayName("Asset Specification")]
        public string ASSET_SPECIFICATION { get; set; }
        [DisplayName("Utilization")]
        public string Utilization { get; set; }
     
    }
}
