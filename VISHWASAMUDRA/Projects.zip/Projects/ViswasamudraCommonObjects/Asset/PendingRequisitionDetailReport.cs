﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset
{
    public class PendingRequisitionDetailReport
    {        
        public Guid? PROJECT { get; set; }
        public string PROJECT_NAME { get; set; }
        public Guid? TASK_TYPE { get; set; }
        public string TASK_TYPE_NAME { get; set; }
        public Guid? REQUISITION { get; set; }
        public string REQUISITION_NO { get; set; }
        public Guid? STRUCTURE_TYPE { get; set; }
        public string STRUCTURE_TYPE_NAME { get; set; }
        public Guid? STRUCTURE_SUB_TYPE { get; set; }
        public string STRUCTURE_SUB_TYPE_NAME { get; set; }
        public Guid? ASSET_TYPE { get; set; }
        public string ASSET_TYPE_NAME { get; set; }
        public Guid? ASSET_SPECIFICATION { get; set; }
        public string ASSET_SPECIFICATION_NAME { get; set; }
        public string REQUESTED_QTY { get; set; }

        public List<PendingRequisitionDetailReport> pendingRequisitionDetailReport { get; set; }
    }
}
