﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset
{
    public class ApprovedRequisitionsReport
    {        
        public Guid? PROJECT { get; set; }
        public string PROJECT_NAME { get; set; }
        public Guid? TASK_TYPE { get; set; }
        public string TASK_TYPE_NAME { get; set; }
        public Guid? REQUISITION { get; set; }
        public string REQUISITION_NO { get; set; }        
        public string REQUESTED_QTY { get; set; }
        public string FULFILLED_STATUS { get; set; }

        public List<ApprovedRequisitionsReport> approvedRequisitionsReport { get; set; }
    }
}
