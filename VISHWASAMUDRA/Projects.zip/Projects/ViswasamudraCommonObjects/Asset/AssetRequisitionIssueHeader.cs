﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset
{
    public class AssetRequisitionIssueHeader
    {
        public int Id { get; set; }
        public Guid AssetIssueHeaderId { get; set; }
        public string AssetRequisitionNo { get; set; }
        public Guid? AssetRequisitionHeader { get; set; }
        public Guid? AssetRequisitionDetail { get; set; }
        public DateTime? AssetRequisitionDate { get; set; }
        public Guid? Tasktype { get; set; }
        public Guid? Project { get; set; }
        public DateTime? RequiredFromDate { get; set; }
        public DateTime? RequiredToDate { get; set; }
        public string RequestedBy { get; set; }
        public string ApprovedBy { get; set; }
        public string IssueNo { get; set; }
        public string IssuedBy { get; set; }
        public Guid? Store { get; set; }
        public string AssetTakenBy { get; set; }
        public string Remarks { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
    }
}
