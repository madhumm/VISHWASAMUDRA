﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset
{
    public class AssetRequisitionUsageHeader
    {
        public int Id { get; set; }
        public Guid AssetUsageHeaderId { get; set; }
        public Guid AssetIssueHeaderId { get; set; }
        public string AssetIssueName { get; set; }
        public string TaskTypeName { get; set; }
        public Guid? Tasktype { get; set; }
        public Guid? Project { get; set; }
        public string ProjectName { get; set; }
        public string UsedDescription { get; set; }
        public DateTime? UsedTillDate { get; set; }
        public string UsageDescription { get; set; }
        public string Remarks { get; set; }
        public string UsedBy { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
        public string[] selectedIssues { get; set; }

        public string StructureName { get; set; }

        public string SubStructureName { get; set; }

        public string AssetTypeName { get; set; }

        public string AssetSpecificationName { get; set; }
    }
}
