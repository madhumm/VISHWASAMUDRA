﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset
{
    public class ApprovedRequisitionDetailReport
    {        
        public Guid? PROJECT { get; set; }
        public string PROJECT_NAME { get; set; }
        public Guid? TASK_TYPE { get; set; }
        public string TASK_TYPE_NAME { get; set; }
        public Guid? REQUISITION { get; set; }
        public string ASSET_REQUISITION_NO { get; set; }        
        public DateTime? REQUISITION_DATE { get; set; }
        public string REQUESTED_BY { get; set; }
        public Guid? STRUCTURE_TYPE { get; set; }
        public string STRUCTURE_TYPE_NAME { get; set; }
        public Guid? STRUCTURE_SUB_TYPE { get; set; }
        public string STRUCTURE_SUB_TYPE_NAME { get; set; }
        public Guid? ASSET_TYPE { get; set; }
        public string ASSET_TYPE_NAME { get; set; }
        public Guid? ASSET_SPECIFICATION { get; set; }
        public string ASSET_SPECIFICATION_NAME { get; set; }
        public string REQUESTED_QTY { get; set; }
        public string Fulfilled_Status { get; set; }
        public string RETURNED_QTY { get; set; }
        public string REPORT_TYPE { get; set; }
        public bool filterEnabled { get; set; }
        public List<ApprovedRequisitionDetailReport> approvedRequisitionDetailReport { get; set; }
    }
}
