﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset
{
    public class AssetUtilizationDetailReport
    {
        public Guid STRUCTURE_TYPE { get; set; }
        public Guid STRUCTURE_SUB_TYPE { get; set; }
        public Guid? PROJECT_CODE { get; set; }
        public string PROJECT_NAME { get; set; }
        public Guid STORE { get; set; }
        public string STORE_NAME { get; set; }
        public Guid? ASSET_TYPE { get; set; }
        public string ASSET_TYPE_NAME { get; set; }
        public Guid? ASSET_SPECIFICATION { get; set; }
        public string ASSET_SPECIFICATION_NAME { get; set; }
        public string ASSET_NAME { get; set; }
        public Guid? ASSETID { get; set; }
        public int USE_FREQUENCY { get; set; }
        public int USED_COUNT { get; set; }
        public decimal UTILIZATION { get; set; }
        public string STRUCTURE_SUB_TYPE_NAME { get; set; }
        public string ASSET_STATUS_NAME { get; set; }
        public string ASSET_STATUS { get; set; }
        public string AVAILABLE_TO_USE { get; set; }
        public bool filterEnabled { get; set; }
        //public string UNDER_REPAIR { get; set; }
        //public int TOTAL_QUANTITY { get; set; }
        //public string ReportType { get; set; }
        //public int Quantity { get; set; }
        //public int SCRAPPED_QUANTITY { get; set; }
        public List<AssetUtilizationDetailReport> assetUtilizationDetailReport { get; set; }
    }
}
