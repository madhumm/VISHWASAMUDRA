﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VSAssetManagement.IOModels
{
    public class AssetReceiptHeader
    {
        public Guid AssetIssueHeaderId { get; set; }
        public string AssetRequisitionNo { get; set; }
        public string IssueNo { get; set; }
        public Guid? AssetRequisitionHeader { get; set; }
        public Guid? AssetRequisitionDetail { get; set; }
        public Guid? Tasktype { get; set; }
        public string TasktypeName { get; set; }
        public Guid? Project { get; set; }
        public string ProjectName { get; set; }
        public Guid? Store { get; set; }
        public string StoreName { get; set; }
        public Guid? StructureType { get; set; }
        public string StructureTypeName { get; set; }
        public Guid? StructureSubType { get; set; }
        public string StructureSubTypeName { get; set; }
        public Guid? AssetType { get; set; }
        public string AssetTypeName { get; set; }
        public string IssuedBy { get; set; }
        public string AssetTakenBy { get; set; }
        public Guid? AssetSpecification { get; set; }
        public int? QuantityRequired { get; set; }
        public int? IssuedQuantity { get; set; }
        public int? ReceiptQuantity { get; set; }
    }
}
