﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class DivisionSearch
    {
        public IEnumerable<VSManagement.IOModels.Division> resultList { get; set; }
        public VSManagement.IOModels.Division searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
