﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class Usersearch
    {
        public IEnumerable<VSManagement.IOModels.UserLogin> resultList { get; set; }
        public VSManagement.IOModels.UserLogin searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
