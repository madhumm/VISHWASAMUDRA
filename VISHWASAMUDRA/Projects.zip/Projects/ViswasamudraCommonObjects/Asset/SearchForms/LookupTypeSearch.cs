﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class LookupTypeSearch
    {
        public IEnumerable<VSAssetManagement.IOModels.LookupType> resultList { get; set; }
        public VSAssetManagement.IOModels.LookupType searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
