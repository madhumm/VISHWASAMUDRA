﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class ZonesSearch
    {
        public IEnumerable<VSManagement.IOModels.Zones> resultList { get; set; }
        public VSManagement.IOModels.Zones searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
