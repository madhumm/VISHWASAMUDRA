﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class AssetSearch
    {

        public IEnumerable<VSAssetManagement.IOModels.Asset> resultList { get; set; }
        public VSAssetManagement.IOModels.Asset searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
