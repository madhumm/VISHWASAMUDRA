﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class EmployeeSearch
    {
        public IEnumerable<VSManagement.IOModels.Employee> resultList { get; set; }
        public VSManagement.IOModels.Employee searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
