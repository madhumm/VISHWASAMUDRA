﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class AssetTransferSearch
    {
        public IEnumerable<VSAssetManagement.IOModels.AssetTransfer> resultList { get; set; }
        public VSAssetManagement.IOModels.AssetTransfer searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
