﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class CompanySearch
    {
        public IEnumerable<VSManagement.IOModels.Company> resultList { get; set; }
        public VSManagement.IOModels.Company searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
