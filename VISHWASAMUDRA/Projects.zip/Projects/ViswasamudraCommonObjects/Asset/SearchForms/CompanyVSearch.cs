﻿using System;
using System.Collections.Generic;
using System.Text;
using ViswasamudraCommonObjects.Project;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class CompanyVSearch
	{
		public IEnumerable<CompanyV> resultList { get; set; }
		public CompanyV searchFilter { get; set; }
		public bool filterEnabled { get; set; }
	}
}