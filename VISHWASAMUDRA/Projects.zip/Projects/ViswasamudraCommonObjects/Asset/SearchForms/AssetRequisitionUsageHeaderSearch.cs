﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class AssetRequisitionUsageHeaderSearch
    {
        public IEnumerable<ViswasamudraCommonObjects.Asset.AssetRequisitionUsageHeader> resultList { get; set; }
        public ViswasamudraCommonObjects.Asset.AssetRequisitionUsageHeader searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
