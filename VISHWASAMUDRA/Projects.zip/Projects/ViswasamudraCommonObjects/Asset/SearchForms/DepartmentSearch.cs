﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class DepartmentSearch
    {
        public IEnumerable<VSManagement.IOModels.Department> resultList { get; set; }
        public VSManagement.IOModels.Department searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
