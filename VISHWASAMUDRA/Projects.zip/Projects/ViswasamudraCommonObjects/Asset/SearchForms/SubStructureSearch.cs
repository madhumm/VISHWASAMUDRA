﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class SubStructureSearch
    {
        public IEnumerable<ViswasamudraCommonObjects.Asset.Substructure> resultList { get; set; }
        public ViswasamudraCommonObjects.Asset.Substructure searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
