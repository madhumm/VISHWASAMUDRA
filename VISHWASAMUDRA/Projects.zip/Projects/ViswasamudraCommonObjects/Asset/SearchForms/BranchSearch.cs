﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class BranchSearch
    {
        public IEnumerable<VSManagement.IOModels.Branch> resultList { get; set; }
        public VSManagement.IOModels.Branch searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
