﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class TagSearchForms
    {

        public IEnumerable<VSAssetManagement.IOModels.Tag> resultList { get; set; }
        public VSAssetManagement.IOModels.Tag searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
