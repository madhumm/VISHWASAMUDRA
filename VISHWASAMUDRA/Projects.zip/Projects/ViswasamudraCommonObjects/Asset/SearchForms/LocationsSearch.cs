﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class LocationsSearch
    {
        public IEnumerable<VSManagement.IOModels.Locations> resultList { get; set; }
        public VSManagement.IOModels.Locations searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
