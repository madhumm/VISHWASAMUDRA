﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class SalutationSearch
    {
        public IEnumerable<VSManagement.IOModels.Salutation> resultList { get; set; }
        public VSManagement.IOModels.Salutation searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
