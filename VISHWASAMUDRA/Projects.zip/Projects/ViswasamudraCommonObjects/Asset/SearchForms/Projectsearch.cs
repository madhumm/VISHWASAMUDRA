﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class Projectsearch
    {
        public IEnumerable<Project.Project> resultList { get; set; }
        public Project.Project searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
