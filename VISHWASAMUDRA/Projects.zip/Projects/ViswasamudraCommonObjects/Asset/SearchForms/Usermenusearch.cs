﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class Usermenusearch
    {
        public IEnumerable<VSManagement.IOModels.UserMenu> resultList { get; set; }
        public VSManagement.IOModels.UserMenu searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
