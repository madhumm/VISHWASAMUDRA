﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class AssetRequisitionSearch
    {
        public IEnumerable<VSAssetManagement.IOModels.AssetRequisition> resultList { get; set; }
        public VSAssetManagement.IOModels.AssetRequisition searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
