﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class Usercontrolsearch
    {
        public IEnumerable<VSManagement.IOModels.UserControl> resultList { get; set; }
        public VSManagement.IOModels.UserControl searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
