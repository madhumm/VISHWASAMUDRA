﻿using System;
using System.Collections.Generic;
using System.Text;
using ViswasamudraCommonObjects.Project;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class ProjectTypesSearch
    {
        public IEnumerable<ProjectTypes> resultList { get; set; }
        public ProjectTypes searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
