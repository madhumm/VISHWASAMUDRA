﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class StructureSearch
    {
        public IEnumerable<ViswasamudraCommonObjects.Asset.Structure> resultList { get; set; }
        public ViswasamudraCommonObjects.Asset.Structure searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
