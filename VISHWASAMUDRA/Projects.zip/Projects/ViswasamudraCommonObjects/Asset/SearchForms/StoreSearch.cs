﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class StoreSearch
    {
        public IEnumerable<VSAssetManagement.IOModels.Store> resultList { get; set; }
        public VSAssetManagement.IOModels.Store searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
