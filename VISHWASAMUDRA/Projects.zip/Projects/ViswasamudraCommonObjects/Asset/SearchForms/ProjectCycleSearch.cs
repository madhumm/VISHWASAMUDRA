﻿using System;
using System.Collections.Generic;
using System.Text;
using ViswasamudraCommonObjects.Project;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class ProjectCycleSearch
    {
        public IEnumerable<ProjectCycle> resultList { get; set; }
        public ProjectCycle searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
