﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class DeputationSearch
    {
        public IEnumerable<VSManagement.IOModels.Deputation> resultList { get; set; }
        public VSManagement.IOModels.Deputation searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
