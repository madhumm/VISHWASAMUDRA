﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class Rolessearch
    {
        public IEnumerable<VSManagement.IOModels.UserRole> resultList { get; set; }
        public VSManagement.IOModels.UserRole searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
