﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class Reasonssearch
    {
        public IEnumerable<VSAssetManagement.IOModels.Reason> resultList { get; set; }
        public VSAssetManagement.IOModels.Reason searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
