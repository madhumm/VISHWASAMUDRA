﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset.SearchForms
{
    public class BatchSearchForm
    {
        public IEnumerable<VSAssetManagement.IOModels.BatchSearch> resultList { get; set; }
        public VSAssetManagement.IOModels.BatchSearch searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
