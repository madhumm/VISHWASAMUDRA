﻿using System.Collections.Generic;

namespace ViswasamudraCommonObjects.SearchForms.Mines
{
    public class PermitRequestSearch
    {
        public IEnumerable<ViswasamudraCommonObjects.Mines.PermitRequest> resultList { get; set; }
        public ViswasamudraCommonObjects.Mines.PermitRequestHeader searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
