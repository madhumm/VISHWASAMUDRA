﻿using System;
using System.Collections.Generic;
using System.Text;
using ViswasamudraCommonObjects.Project;

namespace ViswasamudraCommonObjects.Asset
{
    public class AssetRequisitionsReport
    {
        public Guid? TASK_TYPE { get; set; }
        public string TASK_TYPE_NAME { get; set; }
        public Guid? PROJECT { get; set; }
        public string PROJECT_NAME { get; set; }
        public Guid?  STRUCTURE_TYPE { get; set; }
        public string  STRUCTURE_TYPE_NAME { get; set; }
        public Guid? STRUCTURE_SUB_TYPE { get; set; }
        public string STRUCTURE_SUB_TYPE_NAME { get; set; }
        public Guid? ASSET_TYPE { get; set; }
        public string ASSET_TYPE_NAME { get; set; }
        public Guid?  ASSET_SPECIFICATION { get; set; }
        public string  ASSET_SPECIFICATION_NAME { get; set; }
        public string ReportType { get; set; }
        public string PENDING { get; set; }
        public string APPROVED { get; set; }
        public string COMPLETELYFULFILLED { get; set; }
        public string NOTFULFILLED { get; set; }

        public string PARTIALLYFULFILLED { get; set; }
        public bool filterEnabled { get; set; }
        public string FROM_PROJECT_NAME { get; set; }
        public List<AssetRequisitionsReport> assetRequisitionsReport { get; set; }
    }
}
