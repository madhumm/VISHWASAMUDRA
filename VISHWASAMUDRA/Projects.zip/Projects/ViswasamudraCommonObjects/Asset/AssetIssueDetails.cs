﻿using System;
using System.Collections.Generic;
using System.Text;

namespace VSAssetManagement.IOModels
{
    public class AssetIssueDetails
    {
        public Guid AssetIssueHeaderId { get; set; }
        public Guid AssetIssueDetailId { get; set; }
        public Guid AssetId { get; set; }
        public string AssetName { get; set; }
        public Guid AssetRequisitionHeader { get; set; }
        public Guid AssetRequisitionDetail { get; set; }
        public Guid Structure { get; set; }
        public string StructureName { get; set; }
        public Guid SubStructure { get; set; }
        public string SubStructureName { get; set; }
        public Guid AssetType { get; set; }
        public string AssetTypeName { get; set; }
        public Guid AssetSpecification { get; set; }
        public string AssetSpecificationName { get; set; }
        public int RequestedQty { get; set; }
        public int IssuedQty { get; set; }
        public Guid Uom { get; set; }
        public string UomName { get; set; }
        public string AssetRequisitionNo { get; set; }
        public Guid Tasktype { get; set; }
        public string TasktypeName { get; set; }
        public Guid Project { get; set; }
        public string ProjectName { get; set; }
        public DateTime RequiredFromDate { get; set; }
        public DateTime RequiredToDate { get; set; }
        public string RequestedBy { get; set; }
        public string ApprovedBy { get; set; }
        public string IssueNo { get; set; }
        public string IssuedBy { get; set; }
        public Guid Store { get; set; }
        public string StoreName { get; set; }
        public string AssetTakenBy { get; set; }
        public Guid TagId { get; set; }
        public string Code { get; set; }
        public Guid ToProject { get; set; }
        public string ToProjectName { get; set; }
        public Guid FromProject { get; set; }
        public string FromProjectName { get; set; }
    }
}
