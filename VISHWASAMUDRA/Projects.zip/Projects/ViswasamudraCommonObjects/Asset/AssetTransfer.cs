﻿using System;
using System.Collections.Generic;

namespace VSAssetManagement.IOModels
{
    public partial class AssetTransfer
    {
        public AssetTransferHeader header { get; set; }
        public List<AssetTransferDetails> details { get; set; }
        public bool isApproval { get; set; }
    }
}
