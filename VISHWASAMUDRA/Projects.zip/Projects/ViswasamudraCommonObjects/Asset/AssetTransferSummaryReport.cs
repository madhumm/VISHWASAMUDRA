﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset
{
    public class AssetTransferSummaryReport
    {
        public string FROM_PROJECT_NAME { get; set; }
        public Guid? FROM_PROJECT { get; set; }
        public string TO_PROJECT_NAME { get; set; }
        public Guid? TO_PROJECT { get; set; }
        public string ASSET_TYPE_NAME { get; set; }
        public Guid? ASSET_TYPE { get; set; }
        public string ASSET_SPECIFICATION_NAME { get; set; }
        public Guid? ASSET_SPECIFICATION { get; set; }
        public int? ISSUED_QUANTITY { get; set; }
        public int? RECEIPT_QUANTITY { get; set; }
        public bool filterEnabled { get; set; }

    }

    public class AssetTransferRenderType
    {
        public string FROM_PROJECT_NAME { get; set; }
        public Guid? FROM_PROJECT { get; set; }
        public string TO_PROJECT_NAME { get; set; }
        public Guid? TO_PROJECT { get; set; }
        public string ASSET_TYPE_NAME { get; set; }
        public Guid? ASSET_TYPE { get; set; }
        public string ASSET_SPECIFICATION_NAME { get; set; }
        public Guid? ASSET_SPECIFICATION { get; set; }
        public int? ISSUED_QUANTITY { get; set; }
        public int? RECEIPT_QUANTITY { get; set; }

    }
}
