﻿using System;

namespace VSAssetManagement.IOModels
{
    public partial class AssetTransferHeader
    {
        public int Id { get; set; }
        public Guid Guid { get; set; }
        public string AssetTrRequisitionNo { get; set; }
        public DateTime? AssetTrRequisitionDate { get; set; }
        public Guid? TaskType { get; set; }
        public Guid? FromProject { get; set; }
        public Guid? ToProject { get; set; }
        public DateTime? RequiredFromDate { get; set; }
        public DateTime? RequiredToDate { get; set; }
        public Guid? RequestedBy { get; set; }
        public string ApprovedBy { get; set; }
        public string Remarks { get; set; }
        public Guid? RequisitionStatus { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int? RecordStatus { get; set; }
        public string TaskTypeName { get; set; }
        public string FromProjectName { get; set; }
        public string ToProjectName { get; set; }
        public string RequisitionStatusName { get; set; }
        public string RequestedByName { get; set; }
        public string ApprovedByName { get; set; }
        public string Reason { get; set; }
        public string ApprovalFlag { get; set; }
        public int Quantity { get; set; }
    }
}
