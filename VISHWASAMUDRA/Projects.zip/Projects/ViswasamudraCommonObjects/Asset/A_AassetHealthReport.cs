﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset
{
    public class A_AassetHealthReport
    {
        public string ASSET_CODE { get; set; }
        public string ASSET_NAME { get; set; }
        public string COMPANY_NAME { get; set; }
        public Guid? PROJECT_CODE { get; set; }
        public Guid? STRUCTURE_TYPE { get; set; }
        public Guid? TAG_ID { get; set; }
        public Guid? ASSET_TYPE { get; set; }
        public Guid? ASSET_SPECIFICATION { get; set; }
        public Guid? STORE { get; set; }
        public Guid? BATCH_NO { get; set; }
        public Guid? STRUCTURE_SUB_TYPE { get; set; }
        public string PROJECT_CODE_NAME { get; set; }
        public string STRUCTURE_TYPE_NAME { get; set; }
        public string TAG_ID_NAME { get; set; }
        public string ASSET_TYPE_NAME { get; set; }
        public string ASSET_SPECIFICATION_NAME { get; set; }
        public string STORE_NAME { get; set; }
        public string STRUCTURE_SUB_TYPE_NAME { get; set; }
        public string ASSET_STATUS_NAME { get; set; }
        public string ASSET_STATUS { get; set; }
        public string AVAILABLE_TO_USE { get; set; }
        public string IN_USE { get; set; }
        public string UNDER_REPAIR { get; set; }
        public int TOTAL_QUANTITY { get; set; }
        public string ReportType { get; set; }
        public int Quantity { get; set; }
        public int SCRAPPED_QUANTITY { get; set; }
        public bool filterEnabled { get; set; }
        public List<A_AassetHealthReport> AassetHealthReport { get; set; }
    }
}
