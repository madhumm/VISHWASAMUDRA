﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset
{
    public class AssetRequisitionIssueDetails
    {
        public int Id { get; set; }
        public Guid AssetIssueDetailId { get; set; }
        public Guid? AssetIssueHeaderId { get; set; }
        public Guid? AssetRequisitionHeader { get; set; }
        public Guid? AssetRequisitionDetail { get; set; }
        public Guid? Structure { get; set; }
        public string StructureName { get; set; }
        public Guid? SubStructure { get; set; }
        public string SubStructureName { get; set; }
        public Guid? AssetType { get; set; }
        public string AssetTypeName { get; set; }
        public Guid? AssetSpecification { get; set; }
        public string AssetSpecificationName { get; set; }
        public int? RequestedQty { get; set; }
        public int? IssuedQty { get; set; }
        public Guid? Uom { get; set; }

        public string UOMName { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
    }
}
