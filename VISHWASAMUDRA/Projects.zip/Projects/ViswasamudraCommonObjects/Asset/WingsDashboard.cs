﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset
{
    public class WingsDashboard
    {
        public string ASSET_SPECIFICATION_NAME { get; set; }
        public string AVAILABLE { get; set; }
        public string IN_USE { get; set; }
        public string UNDER_REPAIR { get; set; }
        public string UNDER_SCRAP { get; set; }
        public string TOTAL_QTY { get; set; }
        public string AVAILABLE_PER { get; set; }
        public string IN_USE_PER { get; set; }
        public string UNDER_REPAIR_PER { get; set; }
        public string UNDER_SCRAP_PER { get; set; }
        public string UTILIZATION_PER { get; set; }
        public string PENDING { get; set; }
        public string APPROVED { get; set; }
        public string COMPLETELYFULFILLED { get; set; }
        public string PARTIALLYFULFILLED { get; set; }
        public string NOTFULFILLED { get; set; }
        public string REQ_TOTAL { get; set; }
        public string REJECTED { get; set; }
        public string REJ_QUANTITY_REQUIRED { get; set; }
        public string COMPLETELYFULFILLED_QTY { get; set; }
        public string PARTIALLYFULFILLED_QTY { get; set; }
        public string TOT_QUANTITY_REQUIRED { get; set; }
        public string REQUESTS_CREARTED { get; set; }
        public string APPROVED_QTY { get; set; }
        public string APRV_PERCENTAGE { get; set; }

    }
}
