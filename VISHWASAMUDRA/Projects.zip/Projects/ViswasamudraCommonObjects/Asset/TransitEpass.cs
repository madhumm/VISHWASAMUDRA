﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset
{
    public class TempTransitEpass
    {
        public int Id { get; set; }
        public Guid Guid { get; set; }
        public string EpassNo { get; set; }
        public DateTime? TransitDateTime { get; set; }
        public string TruckNo { get; set; }
        public string Mineral { get; set; }
        public string Quantity { get; set; }
        public string Uom { get; set; }
        public string GeoCoordinates { get; set; }
        public string Licence { get; set; }
        public string DeviceId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public string RecordStatus { get; set; }
    }
}
