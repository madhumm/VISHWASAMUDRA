﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Asset
{
    public class AssetRequisitionUsageDetails
    {
        public int Id { get; set; }
        public Guid AssetUsageDetailId { get; set; }
        public Guid AssetUsageHeaderId { get; set; }
        public Guid? Structure { get; set; }
        public Guid? SubStructure { get; set; }
        public Guid? AssetType { get; set; }
        public Guid? AssetSpecification { get; set; }
        public Guid AssetIssueDetailId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
    }
}
