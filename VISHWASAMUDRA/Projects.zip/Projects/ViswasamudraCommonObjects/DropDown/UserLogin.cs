﻿using System;

namespace VSManagement.IOModels.DropDown
{
    public class User : ResponseBody
    {
        public string UserName { get; set; }
        public Guid? Guid { get; set; }
    }
}
