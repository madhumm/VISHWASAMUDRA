﻿using System;

namespace ViswasamudraCommonObjects.Util
{
    public class AuthorizeRecordRequest
    {
        public string ApprovalFlag { get; set; }
        public string Reason { get; set; }
        public Guid Guid { get; set; }
    }
}
