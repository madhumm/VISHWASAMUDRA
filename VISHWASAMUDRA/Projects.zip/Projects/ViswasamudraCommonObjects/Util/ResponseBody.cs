﻿using System;
using System.Collections.Generic;
using System.Dynamic;
using System.Text;

namespace VSManagement.IOModels
{
    public class ResponseBody
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public string UserName { get; set; }
        public dynamic Response { get; set; }
    }
}
