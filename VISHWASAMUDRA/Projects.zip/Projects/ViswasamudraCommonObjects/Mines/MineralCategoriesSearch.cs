﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Mines
{
    public class MineralCategoriesSearch
    {
        public IEnumerable<MineralCategories> resultList { get; set; }
        public MineralCategories searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
