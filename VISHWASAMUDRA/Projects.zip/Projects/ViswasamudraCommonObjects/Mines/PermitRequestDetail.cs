﻿using System;

namespace ViswasamudraCommonObjects.Mines
{
    public partial class PermitRequestDetail
    {
        public int Id { get; set; }
        public Guid? PrDetailId { get; set; }
        public Guid? PrHeaderId { get; set; }
        public string ContractorBlkNo { get; set; }
        public string BlkNo { get; set; }
        public Guid? UomId { get; set; }
        public string UomName { get; set; }
        public decimal? ActualLength { get; set; }
        public decimal? ActualBreadth { get; set; }
        public decimal? ActualHeight { get; set; }
        public decimal? ActualVolume { get; set; }
        public decimal? ApprovedLenght { get; set; }
        public decimal? ApprovedBreadth { get; set; }
        public decimal? ApprovedHeight { get; set; }
        public decimal? ApprovedVolume { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public Guid? LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }

        #region user-defined-fields
        public bool isEditable { get; set; }
        #endregion
    }
}
