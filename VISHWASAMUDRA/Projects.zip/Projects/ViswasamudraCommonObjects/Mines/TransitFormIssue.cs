using System.Collections.Generic;

namespace ViswasamudraCommonObjects.Mines
{
    public class TransitFormIssue
    {
        public TransitFormIssueHeader header { get; set; }
        public List<TransitFormIssueDetail> details { get; set; }
    }
}
