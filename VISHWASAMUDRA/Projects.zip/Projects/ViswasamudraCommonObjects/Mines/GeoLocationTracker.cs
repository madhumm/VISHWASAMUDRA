﻿using System;

namespace VSAssetManagement.IOModels
{
    public partial class GeoLocationTracker
    {
        public string UserId { get; set; }
        public string DeviceId { get; set; }
        public string Longitude { get; set; }
        public Guid Guid { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
        public int Id { get; set; }
        public string Latitude { get; set; }
    }
}
