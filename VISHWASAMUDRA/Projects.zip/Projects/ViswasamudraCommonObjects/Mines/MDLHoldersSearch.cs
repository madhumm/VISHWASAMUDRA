﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Mines
{
    public class MDLHoldersSearch
    {
        public IEnumerable<MDLHolder> resultList { get; set; }
        public MDLHolder searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
