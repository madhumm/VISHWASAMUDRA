﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Mines
{
    public class MinesLookupTypeValues
    {
        public int Id { get; set; }
        public Guid Guid { get; set; }
        public Guid LookupId { get; set; }
        public string LookupValueCode { get; set; }
        public string LookupValueName { get; set; }
        public int? OrderId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
        public string LookupCode { get; set; }
        public string LookupName { get; set; }
        public List<MinesLookupTypeValues> resultList { get; set;}
    }
}
