﻿using System;

namespace ViswasamudraCommonObjects.Mines
{
    public partial class PermitRequestHeader
    {
        public int Id { get; set; }
        public Guid? PrHeaderId { get; set; }
        public string PermitNo { get; set; }
        public Guid? LeaseHolderId { get; set; }
        public string LeaseHolderName { get; set; }
        public Guid? MineralLocationId { get; set; }
        public string MineralLocationName { get; set; }
        public Guid? MineralId { get; set; }
        public string MineralName { get; set; }
        public int? SurveyRequired { get; set; }
        public Guid? PrType { get; set; }
        public string PrTypeName { get; set; }
        public DateTime? ReqDate { get; set; }
        public DateTime? ReqFromdate { get; set; }
        public DateTime? ReqTodate { get; set; }
        public decimal? RequestedQty { get; set; }
        public decimal? ApprovedQty { get; set; }
        public Guid? UomId { get; set; }
        public string UomName { get; set; }
        public int? BlocksVehiclesCnt { get; set; }
        public Guid? RequestStatus { get; set; }
        public string Remarks { get; set; }
        public Guid? SurveyorId { get; set; }
        public DateTime? AssignedDate { get; set; }
        public Guid? AssignedBy { get; set; }
        public string AssignedByName { get; set; }
        public Guid? ApprovedBy { get; set; }
        public string ApprovedByName { get; set; }
        public DateTime? ApprovedDate { get; set; }
        public string DeviceId { get; set; }
        public string Ipaddress { get; set; }
        public string GeoCoordinates { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public Guid? LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
        public string RequestApprovalFlag { get; set; } = "blank";
        public string Reason { get; set; }

        #region user-defined-fields
        public string SurveyorName { get; set; }
        public string RequestStatusName { get; set; }
        public string RequestStatusCode { get; set; }

        public bool isEditable { get; set; }
        public string ApprovalFlag { get; set; }
        public Guid? Guid { get; set; }

        #endregion
    }
}
