﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Mines
{
    public class LeaseHolders
    {
        public Guid guid { get; set; }
        public string  LeaseHolderName { get; set; }
        public string LeaseHolderCode { get; set; }
        public string ContractPersonName { get; set; }

        public string GSTNo { get; set; }

        public string GSTCertificate { get; set; }

        public string Pan { get; set; }
        public string PanCertificate { get; set; }

        public string MobileNo { get; set; }

        public string AlterNateMobileNo { get; set; }
        public string Email { get; set; }

        public string Address1 { get; set; }
        public string Address2 { get; set; }

        public string City { get; set; }

        public string District { get; set; }

        public string State { get; set; }

        public string PinCode { get; set; }

        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }

    }
}
