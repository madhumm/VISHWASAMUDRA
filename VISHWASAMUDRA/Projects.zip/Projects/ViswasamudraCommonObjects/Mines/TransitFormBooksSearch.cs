﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Mines
{
    public class TransitFormBooksSearch
    {
        public IEnumerable<TransitFormBooks> resultList { get; set; }
        public TransitFormBooks searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
