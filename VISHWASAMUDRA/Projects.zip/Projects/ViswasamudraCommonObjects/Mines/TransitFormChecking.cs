﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Mines
{
    public partial class TransitFormChecking
    {
        public int Id { get; set; }
        public Guid? TransitFormCheckId { get; set; }
        public DateTime? CheckedDatetime { get; set; }
        public int? Checktype { get; set; }
        public string TransitFormSerialNo { get; set; }
        public string GeoCordinates { get; set; }
        public Guid? CheckedBy { get; set; }
        public string DeviceId { get; set; }
        public string Ipaddress { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
    }
}
