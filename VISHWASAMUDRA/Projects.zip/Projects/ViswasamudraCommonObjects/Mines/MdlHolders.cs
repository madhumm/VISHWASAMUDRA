﻿using System;

namespace ViswasamudraCommonObjects.MINES
{
    public partial class MdlHolders
    {
        public int Id { get; set; }
        public Guid? MdlhId { get; set; }
        public string MdlhCode { get; set; }
        public string MdlhName { get; set; }
        public Guid? MineralId { get; set; }
        public string BusinessPlace { get; set; }
        public DateTime? ValidFrom { get; set; }
        public DateTime? ValidTo { get; set; }
        public string SurveyNos { get; set; }
        public string ContactPersionName { get; set; }
        public string GstRegNo { get; set; }
        public string GstCertUpload { get; set; }
        public string PanNo { get; set; }
        public string PancardUpload { get; set; }
        public string Mobile { get; set; }
        public string AlternateMobile { get; set; }
        public string Email { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public Guid? District { get; set; }
        public Guid? State { get; set; }
        public Guid? PinCode { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
    }
}
