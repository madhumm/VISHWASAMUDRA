﻿using System;

namespace ViswasamudraCommonObjects.Mines
{
    public partial class TransitFormIssueDetail
    {
        public int Id { get; set; }
        public Guid? TransitFormIssueDetailId { get; set; }
        public Guid? TransitFormIssueHeaderId { get; set; }
        public string ContractorBlkNo { get; set; }
        public string BlkNo { get; set; }
        public Guid? UomId { get; set; }
        public decimal? ApprovedLength { get; set; }
        public decimal? ApprovedBreadth { get; set; }
        public decimal? ApprovedHeight { get; set; }
        public decimal? ApprovedVolume { get; set; }
        public decimal? ApprovedQuantity { get; set; }
        public Guid? ApprovedVolumeQtyUom { get; set; }
        public decimal? SeigniorageFee { get; set; }
        public decimal? CessOnMbl { get; set; }
        public decimal? ConsiderationAmount { get; set; }
        public decimal? NmetAmount { get; set; }
        public decimal? MeritAmount { get; set; }
        public decimal? DmfAmount { get; set; }
        public decimal? ItAmount { get; set; }
        public decimal? GstAmount { get; set; }
        public decimal? UserCharges { get; set; }
        public decimal? TransitFormCharges { get; set; }
        public decimal? MiscCharges { get; set; }
        public decimal? OtherMiscCharges { get; set; }
        public decimal? TotalAmount { get; set; }
        public Guid? TransitFormBookNoId { get; set; }
        public string TransitFormSerialNo { get; set; }
        public decimal? LoadedQuantity { get; set; }
        public decimal? MineralSaleValue { get; set; }
        public Guid? MdlHolderId { get; set; }
        public string ConsigneeName { get; set; }
        public string ConsigneeAddress { get; set; }
        public string DestinationPlace { get; set; }
        public string DestinationDistanceInKm { get; set; }
        public DateTime? DispatchDatetime { get; set; }
        public DateTime? DatetimeToReach { get; set; }
        public string Destination { get; set; }
        public string VehicleRegNo { get; set; }
        public string DriverName { get; set; }
        public string DriverLicenseNo { get; set; }
        public string QrCode { get; set; }
        public DateTime? TransitFormValidityDate { get; set; }
        public string ContractorAuthorizedPerson { get; set; }
        public string TransitFormStatus { get; set; }
        public string TransitFormVoidReason { get; set; }
        public string Remarks { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public Guid? LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }

        #region user-defined-fields
        public string TransitFormBookNo { get; set; }
        public string UomName { get; set; }
        public string MdlHolderName { get; set; }

        public decimal? ActualLength { get; set; }
        public decimal? ActualBreadth { get; set; }
        public decimal? ActualHeight { get; set; }
        public decimal? ActualVolume { get; set; }
        #endregion
    }
}
