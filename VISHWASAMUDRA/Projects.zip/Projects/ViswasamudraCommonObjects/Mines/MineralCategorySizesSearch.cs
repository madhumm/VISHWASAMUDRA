﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Mines
{
    public class MineralCategorySizesSearch
    {
        public IEnumerable<MineralCategorySizes> resultList { get; set; }
        public MineralCategorySizes searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
