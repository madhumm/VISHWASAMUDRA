﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Mines
{
    public class MineralsSearch
    {
        public IEnumerable<Minerals> resultList { get; set; }
        public Minerals searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
