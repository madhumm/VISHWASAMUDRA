using System.Collections.Generic;

namespace ViswasamudraCommonObjects.Mines
{
    public class PermitRequest
    {
        public PermitRequestHeader header { get; set; }
        public List<PermitRequestDetail> details { get; set; }
    }
}
