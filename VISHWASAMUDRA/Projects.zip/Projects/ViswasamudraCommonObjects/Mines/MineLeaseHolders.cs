﻿using System;
using System.Collections.Generic;
using System.Security.Cryptography.X509Certificates;

namespace ViswasamudraCommonObjects.Mines
{
    public partial class MineLeaseHolders
    {
        public int Id { get; set; }
        public Guid? LeaseHolderId { get; set; }
        public string LeaseHolderCode { get; set; }
        public string LeaseHolderName { get; set; }
        public string GstRegistrationNo { get; set; }
        public string GstCertificateUpload { get; set; }
        public string PanNumber { get; set; }
        public string PanCardUpload { get; set; }
        public string MobileNo { get; set; }
        public string AlternateMobileNo { get; set; }
        public string EmailId { get; set; }
        public string AddressLine1 { get; set; }
        public string AddressLine2 { get; set; }
        public string City { get; set; }
        public Guid? District { get; set; }
        public Guid? State { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
        public string ContactPerson { get; set; }
        public string PinCode { get; set; }
        public string FromApp { get; set; }

        #region user-defined
        public bool SurveyRequired { get; set; }
        public string MineralCode { get; set; }
        public bool RequiredLeasedMines { get; set; }
        public List<MineLocations> MineLocations { get; set; }
        #endregion
    }
}
