﻿using System;

namespace ViswasamudraCommonObjects.Mines
{
    public partial class TransitFormIssueHeader
    {
        public int Id { get; set; }
        public Guid? TransitFormIssueHeaderId { get; set; }
        public string TransitFormIssueNo { get; set; }
        public DateTime? IssueDate { get; set; }
        public Guid? LeaseHolderId { get; set; }
        public Guid? MineralLocationId { get; set; }
        public Guid? MineralId { get; set; }
        public string PermitNo { get; set; }
        public decimal? RequestedQty { get; set; }
        public decimal? ApprovedQty { get; set; } = 0;
        public Guid? UomId { get; set; }
        public int? BlocksVehiclesCnt { get; set; }
        public int? IssuedTransitForms { get; set; } = 0;
        public string IssueStatus { get; set; }
        public string IssueRemarks { get; set; }
        public Guid? IssuedBy { get; set; }
        public DateTime? PaymentDate { get; set; }
        public Guid? PaymentMode { get; set; }
        public decimal? PayAmount { get; set; }
        public Guid? ReceivedBy { get; set; }
        public DateTime? ReceivedDate { get; set; }
        public string PaymentRemarks { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public Guid? LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }

        #region user-defined-field
        public string LeaseHolderName { get; set; }
        public string MineralLocationName { get; set; }
        public string MineralName { get; set; }
        public string UomName { get; set; }
        public string QrNo { get; set; }
        public bool IsEditable { get; set; }
        #endregion
    }
}
