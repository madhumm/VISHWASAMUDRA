﻿using System;

namespace ViswasamudraCommonObjects.Mines
{
    public partial class MineLocations
    {
        public int Id { get; set; }
        public Guid? LocationId { get; set; }
        public string LocationCode { get; set; }
        public string LocationName { get; set; }
        public Guid? MineralId { get; set; }
        public string MineralName { get; set; }
        public string SurveyNo { get; set; }
        public double? ExtentInHectares { get; set; }
        public Guid? State { get; set; }
        public string StateName { get; set; }
        public Guid? District { get; set; }
        public string DistrictName { get; set; }
        public Guid? Mandal { get; set; }
        public string MandalName { get; set; }
        public Guid? Village { get; set; }
        public string VillageName { get; set; }
        public Guid? Pincode { get; set; }
        public string PincodeName { get; set; }
        public Guid? LandType { get; set; }
        public string LandTypeName { get; set; }
        public string GeoCoordinates { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
    }
}
