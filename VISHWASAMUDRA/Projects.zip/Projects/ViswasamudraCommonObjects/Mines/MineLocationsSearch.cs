﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Mines
{
    public class MineLocationsSearch
    {
        public IEnumerable<MineLocations> resultList { get; set; }
        public MineLocations searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
