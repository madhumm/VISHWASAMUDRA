﻿using System;
using System.Collections.Generic;
using System.Text;
using VSManagement;
namespace ViswasamudraCommonObjects.Mines.MinesSearch
{
    public class UOMSearch
    {
        public IEnumerable<UOM> resultList { get; set; }
        public UOM searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
