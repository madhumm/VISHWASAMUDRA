﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Mines.MinesSearch
{
    public class MinesLookupTypeSearch
    {
        public IEnumerable<MinesLookupType> resultList { get; set; }
        public MinesLookupType searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
