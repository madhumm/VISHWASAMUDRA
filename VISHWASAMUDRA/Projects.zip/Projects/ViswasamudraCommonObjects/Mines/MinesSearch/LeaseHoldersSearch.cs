﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Mines.MinesSearch
{
    public class LeaseHoldersSearch
    {
        public IEnumerable<MineLeaseHolders> resultList { get; set; }
        public MineLeaseHolders searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
