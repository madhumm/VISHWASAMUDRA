﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.Mines.MinesSearch
{
    public class MinesLookupTypeValuesSearch
    {
        public IEnumerable<MinesLookupTypeValues> resultList { get; set; }
        public MinesLookupTypeValues searchFilter { get; set; }
        public bool filterEnabled { get; set; }
    }
}
