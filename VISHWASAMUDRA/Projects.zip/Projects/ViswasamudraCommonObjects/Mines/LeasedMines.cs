﻿using System;

namespace ViswasamudraCommonObjects.Mines
{
    public partial class LeasedMines
    {
        public int Id { get; set; }
        public Guid? LeasedMineHeaderId { get; set; }
        public string LicenseIdNo { get; set; }
        public Guid? LicenseHolderId { get; set; }
        public Guid? MineLocationId { get; set; }
        public Guid? MineralId { get; set; }
        public DateTime? LicenseIssuedDate { get; set; }
        public string LicenseDocumentUpload { get; set; }
        public string GrantNo { get; set; }
        public DateTime? GrantDate { get; set; }
        public string WorkorderNo { get; set; }
        public DateTime? WorkorderDate { get; set; }
        public DateTime? EcApproved { get; set; }
        public int? MineOperational { get; set; }
        public string Remarks { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
    }
}
