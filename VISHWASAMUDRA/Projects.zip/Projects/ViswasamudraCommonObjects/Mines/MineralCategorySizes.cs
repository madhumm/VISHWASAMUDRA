﻿using System;

namespace ViswasamudraCommonObjects.Mines
{
    public partial class MineralCategorySizes
    {
        public int Id { get; set; }        
        public Guid? MineralCategorySizeId { get; set; }
        public string MineralCategorySizeCode { get; set; }
        public string MineralCategorySizeName { get; set; }
        public Guid? MineralCategorySizeUOMId { get; set; }
        public string MineralCategorySizeUOMName { get; set; }
        public int? MineralCategorySizeLength { get; set; }
        public int? MineralCategorySizeBreadth { get; set; }
        public string MineralCategorySizeCompareOperator { get; set; }
        public Guid? MineralCategoryId { get; set; }
        public string MineralCategoryName { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public int RecordStatus { get; set; }
    }
}
