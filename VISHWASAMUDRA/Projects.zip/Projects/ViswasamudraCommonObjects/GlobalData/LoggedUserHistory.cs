﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswasamudraCommonObjects.GlobalData
{
    public class LoggedUserHistory
    {
        public int Id { get; set; }
        public Guid Guid { get; set; }
        public string UserId { get; set; }
        public string LoginId { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public int? IsLoggedIn { get; set; }
        public string Mode { get; set; }
        public string IpUid { get; set; }
    }
}
