﻿using System;

namespace VSManagement.IOModels
{
    public class Employee
    {
        public int Id { get; set; }
        public Guid Guid { get; set; }
        public string EmployeeCode { get; set; }
        public string FirstName { get; set; }
        public string MiddleName { get; set; }
        public string LastName { get; set; }
        public string FatherHusbandName { get; set; }
        public string Gender { get; set; }
        public string DateOfBirth { get; set; }
        public string DateOfJoining { get; set; }
        public string DesignationName { get; set; }
        public string FunctonalDesignationName { get; set; }
        public string CompanyName { get; set; }
        public string DivisionName { get; set; }
        public string ZoneName { get; set; }
        public string BranchName { get; set; }
        public string BranchAddressName { get; set; }
        public string LocationName { get; set; }
        public string DepartmentName { get; set; }
        public string SubDepartmentName { get; set; }
        public string DeputationName { get; set; }
        public string BandName { get; set; }
        public string GradeName { get; set; }
        public string CostCenterName { get; set; }
        public string CategoryName { get; set; }
        public string Reporting1 { get; set; }
        public string Reporting2 { get; set; }
        public string Reporting3 { get; set; }
        public string FinalReporting1 { get; set; }
        public string FinalReporting2 { get; set; }
        public string FinalReporting3 { get; set; }
        public string MaritalStatus { get; set; }
        public string AadharNumber { get; set; }
        public string CurrMobile { get; set; }
        public string CurrHome { get; set; }
        public string CurrOther { get; set; }
        public string CurrEmailWork { get; set; }
        public string CurrEmailPersonal { get; set; }
        public string EmployeeStatusId { get; set; }
        public string EmployeeStatusName { get; set; }
        public string ResignationDate { get; set; }
        public string NoticePeriod { get; set; }
        public string LastworkingDate { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string IsActive { get; set; }
        public int? RecordStatus { get; set; }

    }
}
