﻿using System;
using System.Collections.Generic;

namespace VSManagement.IOModels
{
    public partial class UserControl
    {
        public int Id { get; set; }
        public Guid? MenuId { get; set; }
        public string ControlId { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string IsActive { get; set; }
        public bool Active { get; set; }
        public Guid Guid { get; set; }
        public string MenuName { get; set; }
        public string[] Role { get; set; }
        public List<string> Rolenames { get; set; }
    }
}
