﻿using System;
using System.Collections.Generic;

namespace VSManagement.IOModels
{
    public class UserLogin : ResponseBody
    {
        public int Id { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string OldPassword { get; set; }
        public int? WrongAttempt { get; set; }
        public int? PasswordReset { get; set; }
        public int? LoggedIn { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime? LastUpdatedDateTime { get; set; }
        public Guid? Guid { get; set; }
        public string IsActive { get; set; }
        public bool Active { get; set; }
        public int? RecordStatus { get; set; }
        public string AuthToken { get; set; }
        public string EmailId { get; set; }
        public string Mobile { get; set; }
        public string EmpCode { get; set; }
        public string Status { get; set; }
        public int? Locked { get; set; }
        public bool IsLocked { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Department { get; set; }
        public string Reporting { get; set; }
        public string[] Role { get; set; }
        public string[] Projects { get; set; }
        public string ConfirmPassword { get; set; }
        public List<string> Rolenames { get; set; }
        public List<string> RoleCodes { get; set; }
        public string Mode { get; set; }
        public List<string> ProjectNames { get; set; }
        public string IpUid { get; set; }
        public Guid LogGuid { get; set; }
    }
}
