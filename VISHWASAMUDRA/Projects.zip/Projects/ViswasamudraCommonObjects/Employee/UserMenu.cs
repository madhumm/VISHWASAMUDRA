﻿using System;
using System.Collections.Generic;

namespace VSManagement.IOModels
{
    public partial class UserMenu
    {
        public int Id { get; set; }
        public Guid ApplicationId { get; set; }
        public Guid? Parent { get; set; }
        public string ParentMenuName { get; set; }
        public string MenuName { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string IsActive { get; set; }
        public Guid Guid { get; set; }
        public string ApplicationName { get; set; }
        public int RecordStatus { get; set; }
        public string Path { get; set; }
        public string[] Role { get; set; }
        public List<string> Rolenames { get; set; }
    }
}
