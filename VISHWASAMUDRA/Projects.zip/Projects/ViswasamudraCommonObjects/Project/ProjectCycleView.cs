﻿using System;
using System.ComponentModel.DataAnnotations;

namespace VSAssetManagement.IOModels
{
    public class ProjectCycleView
    {
        public Guid Project_ID { get; set; }
        public Guid Project_Type_ID { get; set; }
        public Guid Project_Cycle_Id { get; set; }        
        public string Project_Code { get; set; }
        public string Project_name { get; set; }
        public string Project_Type_Code { get; set; }
        public string Project_Type_Name { get; set; }        
        public string Project_Cycle_Name { get; set; }
        public string Project_Cycle_Code { get; set; }
        public int Order_No { get; set; }

    }
}
