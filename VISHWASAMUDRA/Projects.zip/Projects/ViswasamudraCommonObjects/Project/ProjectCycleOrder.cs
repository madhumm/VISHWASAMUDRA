﻿using System;
using System.Collections.Generic;

namespace ViswasamudraCommonObjects.Project
{
    public partial class ProjectCycleOrder
    {
        public string Guid { get; set; }
        public string Order { get; set; }
    }
}
