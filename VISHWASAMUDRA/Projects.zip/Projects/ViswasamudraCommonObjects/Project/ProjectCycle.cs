﻿using System;
using System.Collections.Generic;

namespace ViswasamudraCommonObjects.Project
{
    public class ProjectCycle
    {
        public int Id { get; set; }
        public Guid ProjectType { get; set; }
        public Guid ProjCycle { get; set; }
        public string ProjectTypeName { get; set; }
        public string ProjCycleName { get; set; }
        public int OrderNo { get; set; }
        public string CreatedBy { get; set; }
        public DateTime CreatedDateTime { get; set; }
        public string LastUpdatedBy { get; set; }
        public DateTime LastUpdatedTime { get; set; }
        public int RecordStatus { get; set; }
        public Guid Guid { get; set; }

        public List<ProjectCycle> resultList { get; set; }
        public List<Guid> DeletedItems { get; set; }
    }
}
