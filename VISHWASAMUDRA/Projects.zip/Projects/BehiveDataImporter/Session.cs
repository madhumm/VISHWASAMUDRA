﻿using System;
using System.Collections.Generic;
using System.Text;

namespace TestBehiveAPIs
{
    public static class Session
    {
        public static string auth_token { get; set; }
    }
}
