﻿$(document).ready(function () {

    $('#loadRecord').click(function () {
        openLoader("Loading details...");
    });

    $('#deleteRecord').click(function () {
        openLoader("Deleting record...");
    });

    // [ notification-button ]
    $('.notifications.btn').on('click', function (e) {
        e.preventDefault();

        var nFrom = $(this).attr('data-from');
        var nAlign = $(this).attr('data-align');
        var nIcons = $(this).attr('data-notify-icon');
        var nType = $(this).attr('data-type');
        var nAnimIn = $(this).attr('data-animation-in');
        var nAnimOut = $(this).attr('data-animation-out');
        var message = '';

        // [ Initialize validation ]
        $('#assetusageform').validate({
            ignore: '.ignore, .select2-input',
            focusInvalid: false,
            rules: {
                'AssetIssueHeaderId': {
                    required: true,
                },
                'Project': {
                    required: true,
                },
                'Tasktype': {
                    required: true,
                },
                'UsedDescription': {
                    required: true,
                },
                'UsedTillDate': {
                    required: true,
                }
                ,
                'UsageDescription': {
                    required: true,
                },
                'UsedBy': {
                    required: true,
                }
            },

            // Errors //

            errorPlacement: function errorPlacement(error, element) {
                var $parent = $(element).parents('.form-group');

                // Do not duplicate errors
                if ($parent.find('.jquery-validation-error').length) {
                    return;
                }

                $parent.append(
                    error.addClass('jquery-validation-error small form-text invalid-feedback')
                );
            },
            highlight: function (element) {
                var $el = $(element);
                var $parent = $el.parents('.form-group');

                $el.addClass('is-invalid');

                // Select2 and Tagsinput
                if ($el.hasClass('select2-hidden-accessible') || $el.attr('data-role') === 'tagsinput') {
                    $el.parent().addClass('is-invalid');
                }
            },
            unhighlight: function (element) {
                $(element).parents('.form-group').find('.is-invalid').removeClass('is-invalid');
            }
        });

        if ($('#assetusageform').valid()) {
            var selecteddata = GetCheckboxCheckedValeues();
            if (selecteddata.length > 0) {

                openLoader('Saving Asset usage details.....');
                $.ajax({
                    url: 'AssetUsageModification',
                    data: toJson(),
                    type: 'Post',
                    success: function (data) {
                        closeLoader();
                        if (data?.success) {
                            nType = 'success';
                            message = data?.message;
                            setTimeout(function () {
                                window.location.replace('/AssetRequisitionUsage/');
                            }, 200);
                            let mode = $("#hdnGuid").val().replaceAll('-', '') == 0 ? 'Created' : 'Updated';
                            notify(nFrom, nAlign, nIcons, nType, nAnimIn, nAnimOut, ' Successfully', " Asset usage ");
                           
                        } else {
                            nType = 'danger';
                            message = data?.message;
                            console.error('Error saving Asset usage:', message);
                            if (message.includes("Asset usage Exist"))
                                notify(nFrom, nAlign, nIcons, nType, nAnimIn, nAnimOut, "Asset usage are existed", " Asset usage ");
                            else
                                notify(nFrom, nAlign, nIcons, nType, nAnimIn, nAnimOut, "Error saving", " Asset usage ");
                        }
                    },
                    error: function (xhr, ajaxOptions, thrownError) {
                        nType = 'danger';
                        message = 'Error In Updation';
                        console.error('Error saving Asset usage:', thrownError);
                        notify(nFrom, nAlign, nIcons, nType, nAnimIn, nAnimOut, "Error saving", " Asset usage ")
                    },

                });
            } else {
                alert("Select one issue");
            }
        }
    });




});

function toJson() {
    var SelectedIssuesValues = GetCheckboxCheckedValeues();
    return Project = {
        AssetIssueHeaderId: $("#AssetIssueHeaderId").val(), Project: $('#Project').val(), Tasktype: $('#Tasktype').val(), UsedDescription: $('#UsedDescription').val()
        , UsedTillDate: $('#UsedTillDate').val(), UsageDescription: $('#UsageDescription').val(), Remarks: $('#Remarks').val(),
        UsedBy: $('#UsedBy').val(), selectedIssues: SelectedIssuesValues
    };
};

function GetCheckboxCheckedValeues() {
    var checkedissue=[]
    var grid = document.getElementById("assets");
    var checkBoxes = grid.getElementsByTagName("INPUT");
    if (checkBoxes.length > 0) {
        for (var i = 0; i < checkBoxes.length; i++) {
            var checkedid = checkBoxes[i].id;
            var checkboxproperty = document.getElementById(checkedid);
            if (checkboxproperty.checked) {
                checkedissue.push(checkedid);

            }
        }
    }
    return checkedissue;
}

function LoadIssueDetails() {
    var AssetIssueHeaderId = $('#AssetIssueHeaderId').val();
    $.ajax(
        {
            url: '/AssetRequisitionUsage/AssetIssuesbyAssetNo?HeaderID=' + AssetIssueHeaderId,
            type: 'GET',
            data: "",
            contentType: 'application/json; charset=utf-8',
            success: function (data) {
                $("#partialDiv").html(data);
                setTimeout(function () {
                    LoadHeaderDetails(AssetIssueHeaderId);
                }, 25);

            },
            error: function () {
                alert("Error");
            }
        });

}
function ValidateUsedTillDate() {
    var useddate =new Date($("#UsedTillDate").val());
    var date = new Date();
    if (useddate > date) {
        alert("Used Till Date not allowing futere date." )
        $("#UsedTillDate").val("");
    }
}

function LoadHeaderDetails(AssetIssueHeaderId) {

    $.ajax(
        {
            url: '/AssetRequisitionUsage/AssetIssuesHeaderDetailsByAssetNo?HeaderID=' + AssetIssueHeaderId,
            type: 'GET',
            data: "",
            contentType: 'application/json; charset=utf-8',
            success: function (data) {
                debugger;
                $('#Tasktype').val(data.tasktype);
                $('#Project').val(data.project);
                $('#UsedBy').val(data.assetTakenBy);

            },
            error: function () {

            }
        });

}

