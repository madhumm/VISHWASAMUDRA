﻿function SelectDropDown(type) {
    $.ajax({
        
    });
}