﻿$(document).ready(function () {
    $('#deleteRecord').click(function () {
        openLoader("Deleting record...");
    });

    $('.notifications.btn').on('click', function (e) {
        e.preventDefault();

        var nFrom = $(this).attr('data-from');
        var nAlign = $(this).attr('data-align');
        var nIcons = $(this).attr('data-notify-icon');
        var nType = $(this).attr('data-type');
        var nAnimIn = $(this).attr('data-animation-in');
        var nAnimOut = $(this).attr('data-animation-out');
        var message = '';

        // [ Initialize validation ]
        $('#minelocationsform').validate({
            ignore: '.ignore, .select2-input',
            focusInvalid: false,
            rules: {
                'LocationCode': {
                    required: true,
                },
                'LocationName': {
                    required: true,
                },
                'MineralId': {
                    required: false,
                },
                'SurveyNo': {
                    required: true,
                },
                'ExtentInHectares': {
                    required: true,
                },
                'State': {
                    required: true,
                },
                'District': {
                    required: true,
                },
                'Mandal': {
                    required: true,
                },
                'Village': {
                    required: true,
                },
                'Pincode': {
                    required: true,
                },
                'LandType': {
                    required: true,
                },
                'GeoCoordinates': {
                    required: true,
                }
            },

            // Errors //
            errorPlacement: function errorPlacement(error, element) {
                var $parent = $(element).parents('.form-group');

                // Do not duplicate errors
                if ($parent.find('.jquery-validation-error').length) {
                    return;
                }

                $parent.append(
                    error.addClass('jquery-validation-error small form-text invalid-feedback')
                );
            },
            highlight: function (element) {
                var $el = $(element);
                var $parent = $el.parents('.form-group');

                $el.addClass('is-invalid');

                // Select2 and Tagsinput
                if ($el.hasClass('select2-hidden-accessible') || $el.attr('data-role') === 'tagsinput') {
                    $el.parent().addClass('is-invalid');
                }
            },
            unhighlight: function (element) {
                $(element).parents('.form-group').find('.is-invalid').removeClass('is-invalid');
            }
        });

        if ($('#minelocationsform').valid()) {
            openLoader('Saving Mine Location Details.');
            $.ajax({
                url: 'MineLocationModification',
                data: toJson(),
                type: 'Post',
                success: function (data) {
                    closeLoader();
                    if (data?.success) {
                        nType = 'success';
                        message = data?.message;
                        let mode = $("#hdnGuid").val().replaceAll('-', '') == 0 ? 'Created' : 'Updated';
                        notify(nFrom, nAlign, nIcons, nType, nAnimIn, nAnimOut, ' Success ', " Mine Location ");
                    } else {
                        nType = 'danger';
                        message = data?.message;
                        console.error('Error saving Mine Location:', message);
                        if (message.includes("Exist"))
                            notify(nFrom, nAlign, nIcons, nType, nAnimIn, nAnimOut, "Record already exist", " Mine Location ");
                        else
                            notify(nFrom, nAlign, nIcons, nType, nAnimIn, nAnimOut, "Error saving", " Mine Location ");
                    }
                },
                error: function (xhr, ajaxOptions, thrownError) {
                    nType = 'danger';
                    message = 'Error In Updation';
                    console.error('Error saving Mine Location:', thrownError);
                    notify(nFrom, nAlign, nIcons, nType, nAnimIn, nAnimOut, "Error saving", " Mine Location ")
                },

            });
        }
    });
});


function toJson() {
    return minelocations = {
        Id: $("#hdnId").val(), LocationId: $("#hdnGuid").val(), LocationCode: $('#LocationCode').val(), LocationName: $('#LocationName').val(),
        MineralId: $('#MineralId option:selected').val(), SurveyNo: $('#SurveyNo').val(), ExtentInHectares: $('#ExtentInHectares').val(),
        State: $('#State option:selected').val(), District: $('#District option:selected').val(), Mandal: $('#Mandal option:selected').val(),
        Village: $('#Village option:selected').val(), Pincode: $('#Pincode option:selected').val(), LandType: $('#LandType option:selected').val(),
        GeoCoordinates: $('#GeoCoordinates').val()
    };
};