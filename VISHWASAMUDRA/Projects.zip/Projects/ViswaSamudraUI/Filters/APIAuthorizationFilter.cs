﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Text;
using Microsoft.AspNetCore.Http;

namespace ViswaSamudraUI.Filters
{
    public class APIAuthorizationFilter: Attribute, IAuthorizationFilter
    {
        public void OnAuthorization(AuthorizationFilterContext context)
        {
            if (!context.HttpContext.Request.IsHttps)
            {
                context.Result = new ForbidResult();
                return;
            }

            using (var client = new HttpClient())
            {
                byte[] data = null;
                string apiUrl = context.HttpContext.Session.GetString("api-url");
                if(string.IsNullOrEmpty(apiUrl))
                {
                    context.Result = new RedirectResult("../Unauthorized");
                    return;
                }

                if (!context.HttpContext.Session.TryGetValue("auth-token", out data))
                {
                    context.Result = new RedirectResult("../Unauthorized");
                    return;
                }
                string token = Encoding.UTF8.GetString(data);

                client.BaseAddress = new Uri(apiUrl);
                client.DefaultRequestHeaders.Accept.Clear();
                if (!string.IsNullOrEmpty(token))
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                }
                var getdata = client.GetAsync("/authorize").Result;


                if (getdata.IsSuccessStatusCode)
                {
                    string result = getdata.Content.ReadAsStringAsync().Result;
                }
                else if (getdata.StatusCode == System.Net.HttpStatusCode.Unauthorized)
                {
                    context.Result = new RedirectResult("../Unauthorized");
                    return;
                }
                else
                {
                    context.Result = new StatusCodeResult(500);
                    return;
                }
                return;
            }
        }
    }
}