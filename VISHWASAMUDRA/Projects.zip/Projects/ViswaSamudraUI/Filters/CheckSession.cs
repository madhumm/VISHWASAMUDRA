﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.AspNetCore.Routing;
//using System.Web.Http.Results;

namespace ViswaSamudraUI.Filters
{
    public class CheckSession: ActionFilterAttribute
    {
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            base.OnActionExecuting(filterContext);

            //filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new
            //{
            //    controller = "Login",
            //    action = "SessionOut"
            //}));

            if (filterContext.HttpContext == null || filterContext.HttpContext.Session.GetString("user") == null)
            {
                filterContext.Result = new RedirectToRouteResult(new RouteValueDictionary(new
                {
                    controller = "Login",
                    action = "SessionOut"
                }));
            }
        }
    }
}
