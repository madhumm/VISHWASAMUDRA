﻿/*using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Security.Claims;
using System.Threading.Tasks;

namespace ViswaSamudraUI
{
    public static class HandleState
    {
        public static IConfiguration _config;

        private static dynamic GetClaim(IEnumerable<Claim> claims, string claim)
        {
            return claims
                    .Where(x => x.Type == claim)
                    .FirstOrDefault().Value;
        }

        public static async Task<string> AuthorizeRequest(IConfiguration _config, HttpContext context = null)
        {
            string token = context.Session.GetString("auth-token");
            if (string.IsNullOrEmpty(token))
            {
                return "Unauthorized";
            }

            try
            {
                using (HttpClient client = new HttpClient())
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", token);
                    using (HttpResponseMessage response = await client.GetAsync($"{_config["urls"]}/authorize"))
                    {
                        using (HttpContent content = response.Content)
                        {
                            string responseString = content.ReadAsStringAsync().Result.ToString();
                            if (responseString == "Authorized request.") return "Success";
                        }
                    }
                }
            }
            catch (Exception e)
            {
                return "";
            }
            return "Unauthorized";
        }

        public static double GetTimeDifferenceFromNow(int? time)
        {
            var dateTime = DateTimeOffset.FromUnixTimeSeconds((long)time);
            TimeSpan span = DateTime.Now - dateTime;
            return span.TotalSeconds;
        }

        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64EncodedBytes = System.Convert.FromBase64String(base64EncodedData);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }

        public static string GetClientScopes(string clientId)
        {
            //Client scopes returned will be comma seperated
            var jwksRequest = (HttpWebRequest)WebRequest.Create($"{_config["authority_endpoint"]}/oauth/client-scopes?clientId=" + clientId);
            jwksRequest.Method = "GET";

            var clientAssertionResponse = (HttpWebResponse)jwksRequest.GetResponse();
            StreamReader reader = new StreamReader(clientAssertionResponse.GetResponseStream());
            return reader.ReadToEnd();
        }
    }
}
*/