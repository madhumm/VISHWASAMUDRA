using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace ViswaSamudraUI.Views.NonGranitePermitRequest.Approval
{
    public class ViewDetailsModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
