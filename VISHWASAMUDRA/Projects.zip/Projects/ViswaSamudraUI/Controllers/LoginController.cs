﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using ViswaSamudraUI.Providers.HRMS;
using VSManagement.IOModels;

namespace ViswaSamudraUI.Controllers
{
    public class LoginController : Controller
    {
        UserProvider provider = new UserProvider("","");

        private readonly IConfiguration _config;
        public LoginController(IConfiguration config)
        {
            _config = config;
        }
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Home()
        {
            return View();
        }

        public IActionResult RedirectDashboard()
        {
            return RedirectToAction("Index", "Dashboard");
        }

        [HttpPost]
        public IActionResult authenticate([FromForm] UserLogin model)
        {
            HttpContext.Session.Clear();
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(model.UserName + "~success");
            string authKey = string.Empty;
            authKey = Convert.ToBase64String(plainTextBytes);

            UserLogin response = provider.Login(model);

            if (response.Success)
            {
                //response.UserName = authKey;
                HttpContext.Session.SetString("auth-token", response.AuthToken);
                HttpContext.Session.SetString("user", response.UserName);
                HttpContext.Session.SetString("user-projects", string.Join(",", response.Projects));
                HttpContext.Session.SetString("FullName", response.FirstName+' '+response.LastName);
                HttpContext.Session.SetString("userGuid", response.Guid.ToString());
                HttpContext.Session.SetString("api-url", _config["urls"]);
                //return Redirect("../Dashboard");
            }
            HttpContext.Session.SetString("auth-error", response.Message);
            //return Redirect("/login");
            return Ok(response);
        }

        [HttpGet]
        public IActionResult logout()
        {
            string token = HttpContext.Session.GetString("auth-token");
            provider = new UserProvider(token, "");
            provider.LogOut();
            HttpContext.Session.Clear();
            return Redirect("../Login");
        }

      
        public IActionResult SessionOut()
        {
            HttpContext.Session.Clear();
            return View();
        }



    }
}
