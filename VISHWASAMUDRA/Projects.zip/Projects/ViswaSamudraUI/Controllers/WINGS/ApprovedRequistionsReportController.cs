﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using ViswasamudraCommonObjects.Asset;
using ViswaSamudraUI.Providers.Assets;
using VSManagement.IOModels.DropDown;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class ApprovedRequistionsReportController : Controller
    {
        ReportDetails Provider = new ReportDetails();                
        ProjectProvider projectProvider = null;        

        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public ApprovedRequistionsReportController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");            
            projectProvider = new ProjectProvider(httpContextAccessor);
        }

        public IActionResult Index(ApprovedRequisitionsReport requestModel)
        {
            if (requestModel != null)
            {
                //ViewBag.StructureType = lookUpProvider.GetSelectList("STY", requestModel.STRUCTURE_TYPE.ToString());
                //ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", requestModel.STRUCTURE_SUB_TYPE.ToString());
                //ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", requestModel.ASSET_TYPE.ToString());
                //ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", requestModel.ASSET_SPECIFICATION.ToString());
                ViewBag.PurchaseProject = projectProvider.GetSelectList(requestModel.PROJECT.ToString());
                //ViewBag.PurchaseStore = storeProvider.GetSelectList(0, "");
            }
            else
            {
                requestModel = new ApprovedRequisitionsReport();                
                ViewBag.PurchaseProject = projectProvider.GetSelectList("0", "");                
            }

            requestModel.approvedRequisitionsReport = GetApprovedRequisitionsReport(requestModel);
            return View(requestModel);
        }

        public List<ApprovedRequisitionsReport> GetApprovedRequisitionsReport(ApprovedRequisitionsReport approvedRequisitionsReport)
        {            
            return Provider.GetApprovedRequisitionsReport(approvedRequisitionsReport);
        }
    }
}
