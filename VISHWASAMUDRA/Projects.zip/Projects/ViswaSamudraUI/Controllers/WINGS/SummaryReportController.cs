﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Razor.Language;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Threading.Tasks;
using ViswaSamudraUI.Providers;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class SummaryReportController : Controller
    {
        ReportDetails Provider = new ReportDetails();
        TableHelper TableHelper = new TableHelper();
        public IActionResult Index()
        {
            ViewBag.HtmlStr = ProjectHtml().Result.ToString();
            return View();
        }

        public async Task<string> ProjectHtml()
        {
            IEnumerable<R_ProjectReport> drp = Provider.GetProjectSummary();
            List<RenderType> rtypelist = new List<RenderType>();
            foreach (var Item in drp)
            {
                RenderType render = new RenderType();
                render.NAME = Item.PROJECT_NAME;
                render.CODE = Item.PROJECT_CODE;
                render.TOTAL = Item.TOTAL;
                render.AVAILABLE = Item.AVAILABLE;
                render.UNDER_USE = Item.UNDER_USE;
                render.TRFR_INWARD = Item.TRFR_INWARD;
                render.TRFR_OUTWARD = Item.TRFR_OUTWARD;
                render.UNDER_REPAIR = Item.UNDER_REPAIR;
                render.UNDER_SCRAP = Item.UNDER_SCRAP;
                rtypelist.Add(render);
            }
            return GetTableHtml(rtypelist, "Project Name", "Project Code");
        }

        public async Task<string> StoreHtml()
        {
            IEnumerable<R_StoreReport> drp = Provider.GetStoreSummary();
            List<RenderType> rtypelist = new List<RenderType>();
            foreach (var Item in drp)
            {
                RenderType render = new RenderType();
                render.NAME = Item.STORE_NAME;
                render.CODE = Item.STORE_CODE;
                render.TOTAL = Item.TOTAL;
                render.AVAILABLE = Item.AVAILABLE;
                render.UNDER_USE = Item.UNDER_USE;
                render.TRFR_INWARD = Item.TRFR_INWARD;
                render.TRFR_OUTWARD = Item.TRFR_OUTWARD;
                render.UNDER_REPAIR = Item.UNDER_REPAIR;
                render.UNDER_SCRAP = Item.UNDER_SCRAP;
                rtypelist.Add(render);
            }
            return GetTableHtml(rtypelist,"Store Name", "Store Code");

        }

        public async Task<string> StructureHtml()
        {
            IEnumerable<R_StructureReport> drp = Provider.GetStructureSummary();
            List<RenderType> rtypelist = new List<RenderType>();
            foreach (var Item in drp)
            {
                RenderType render = new RenderType();
                render.NAME = Item.STRUCTURE;                
                render.TOTAL = Item.TOTAL;
                render.AVAILABLE = Item.AVAILABLE;
                render.UNDER_USE = Item.UNDER_USE;
                render.TRFR_INWARD = Item.TRFR_INWARD;
                render.TRFR_OUTWARD = Item.TRFR_OUTWARD;
                render.UNDER_REPAIR = Item.UNDER_REPAIR;
                render.UNDER_SCRAP = Item.UNDER_SCRAP;
                rtypelist.Add(render);
            }
            return GetTableHtml(rtypelist, "Structure");

        }

        public async Task<string> SubStructureHtml()
        {
            IEnumerable<R_SubStructureReport> drp = Provider.GetSubStructureSummary();
            List<RenderType> rtypelist = new List<RenderType>();
            foreach (var Item in drp)
            {
                RenderType render = new RenderType();
                render.NAME = Item.SUB_STRUCTURE;
                render.TOTAL = Item.TOTAL;
                render.AVAILABLE = Item.AVAILABLE;
                render.UNDER_USE = Item.UNDER_USE;
                render.TRFR_INWARD = Item.TRFR_INWARD;
                render.TRFR_OUTWARD = Item.TRFR_OUTWARD;
                render.UNDER_REPAIR = Item.UNDER_REPAIR;
                render.UNDER_SCRAP = Item.UNDER_SCRAP;
                rtypelist.Add(render);
            }
            return GetTableHtml(rtypelist, "Sub Structure");

        }

        public async Task<string> AssetTypeHtml()
        {
            IEnumerable<R_AssertTypeReport> drp = Provider.GetAssetTypeSummary();
            List<RenderType> rtypelist = new List<RenderType>();
            foreach (var Item in drp)
            {
                RenderType render = new RenderType();
                render.NAME = Item.ASSET_TYPE;
                render.TOTAL = Item.TOTAL;
                render.AVAILABLE = Item.AVAILABLE;
                render.UNDER_USE = Item.UNDER_USE;
                render.TRFR_INWARD = Item.TRFR_INWARD;
                render.TRFR_OUTWARD = Item.TRFR_OUTWARD;
                render.UNDER_REPAIR = Item.UNDER_REPAIR;
                render.UNDER_SCRAP = Item.UNDER_SCRAP;
                rtypelist.Add(render);
            }
            return GetTableHtml(rtypelist, "Asset Type");

        }

        public async Task<string> AssetSpecificationHtml()
        {
            IEnumerable<R_AssertSpecReport> drp = Provider.GetAssetSpecSummary();
            List<RenderType> rtypelist = new List<RenderType>();
            foreach (var Item in drp)
            {
                RenderType render = new RenderType();
                render.NAME = Item.ASSET_SPEC;
                render.TOTAL = Item.TOTAL;
                render.AVAILABLE = Item.AVAILABLE;
                render.UNDER_USE = Item.UNDER_USE;
                render.TRFR_INWARD = Item.TRFR_INWARD;
                render.TRFR_OUTWARD = Item.TRFR_OUTWARD;
                render.UNDER_REPAIR = Item.UNDER_REPAIR;
                render.UNDER_SCRAP = Item.UNDER_SCRAP;
                rtypelist.Add(render);
            }
            return GetTableHtml(rtypelist, "Asset Specification");

        }




        public string GetTableHtml(List<RenderType> drp, string Name,string Code=null)
        {
            string data = "";
            data = data + TableHelper.TableStart() + TableHeader(Name, Code);
            data = data + "<tbody>";
            int i = 1;
            int colspan= Code==null ? 1 : 2;

            foreach (var item in drp)
            {
                if (i >= drp.Count())
                {
                    data = data + "<tfoot>" +
                "<tr> " +
                "<th rowspan = '1' colspan = '"+ colspan.ToString() + "' >  </th> "+
                "<th rowspan = '1' colspan = '1' > Total </th> " +
                "<th rowspan = '1' colspan = '1' > " + item.TOTAL + " </th> " +
                "<th rowspan = '1' colspan = '1' > " + item.AVAILABLE + " </th> " +
                "<th rowspan = '1' colspan = '1' > " + item.UNDER_USE + " </th> " +
                "<th rowspan = '1' colspan = '1' > " + item.TRFR_INWARD + " </th> " +
                "<th rowspan = '1' colspan = '1' > " + item.TRFR_OUTWARD + " </th> " +
                "<th rowspan = '1' colspan = '1' > " + item.UNDER_REPAIR + " </th> " +
                "<th rowspan = '1' colspan = '1' > " + item.UNDER_SCRAP + " </th> " +
                "</tr>" +
                "</tfoot>";
                }
                else
                {
                    data = data + "<tr>";
                    if (i < drp.Count())
                        data = data + "<td>" + i.ToString() + "</td> ";
                    else
                        data = data + "<td></td> ";
                    if(Code != null)
                    data = data + "<td>" + item.CODE + "</td> ";
                    data = data + "<td>" + item.NAME + "</td> ";
                    data = data + "<td>" + item.TOTAL + "</td> ";
                    data = data + "<td>" + item.AVAILABLE + "</td> ";
                    data = data + "<td>" + item.UNDER_USE + "</td> ";
                    data = data + "<td>" + item.TRFR_INWARD + "</td> ";
                    data = data + "<td>" + item.TRFR_OUTWARD + "</td> ";
                    data = data + "<td>" + item.UNDER_REPAIR + "</td> ";
                    data = data + "<td>" + item.UNDER_SCRAP + "</td> ";
                    data = data + " </tr>";
                }
                i++;
            }
            data = data + "</tbody>";
            data = data + "</table>";
            return data;
        }

        public string TableHeader(string Name, string Code = null)
        {
            if(Code != null)
            return
                "<thead>" +
                "<tr>" +
                "<th>Sno</th>" +
                "<th>" + Code + "</th>"+
                "<th>" + Name + "</th>" +
                "<th>Total</th>" +
                "<th>Available</th>" +
                "<th>UnderUse</th>" +
               "<th>Transfer To Qty</th>" +
                "<th> Transfer From Qty</th>" +
                "<th>Under Repair Qty</th>" +
                "<th>Scrapped Qty</th>" +
                "</tr>" +
                "</thead>";
            else
                return
                "<thead>" +
                "<tr>" +
                "<th>Sno</th>" +                
                "<th>" + Name + "</th>" +
                "<th>Total</th>" +
                "<th>Available</th>" +
                "<th>UnderUse</th>" +
                "<th>Transfer To Qty</th>" +
                "<th> Transfer From Qty</th>" +
                "<th>Under Repair Qty</th>" +
                "<th>Scrapped Qty</th>" +
                "</tr>" +
                "</thead>";


        }
    }

    public class RenderType
    {
        public string NAME { get; set; }
        public string CODE { get; set; }
        public string TOTAL { get; set; }
        public string AVAILABLE { get; set; }
        public string UNDER_USE { get; set; }
        public string TRFR_INWARD { get; set; }
        public string TRFR_OUTWARD { get; set; }
        public string UNDER_REPAIR { get; set; }
        public string UNDER_SCRAP { get; set; }
    
    }
}