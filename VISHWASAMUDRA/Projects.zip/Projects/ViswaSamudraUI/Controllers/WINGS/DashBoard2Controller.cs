﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using ViswaSamudraUI.Providers.Assets;
using ViswasamudraCommonObjects.Asset;
using VSAssetManagement.IOModels;
using System.Linq;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class DashBoard2Controller : Controller
    {
        ReportDetails Provider = new ReportDetails();
        
        public IActionResult Index()
        {
            Guid userID= Guid.Parse(HttpContext.Session.GetString("userGuid"));
            ViewBag.WingsDbData = Provider.GetWingsDashboardSummary();             
            return View();            
        }      
    }
}
