﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using ViswasamudraCommonObjects.Asset;
using ViswaSamudraUI.Providers.Assets;
using VSManagement.IOModels.DropDown;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class PendingRequistionsReportController : Controller
    {
        ReportDetails Provider = new ReportDetails();                
        ProjectProvider projectProvider = null;        

        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public PendingRequistionsReportController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");            
            projectProvider = new ProjectProvider(httpContextAccessor);
        }

        public IActionResult Index(PendingRequisitionsReport requestModel)
        {
            if (requestModel != null)
            {
                //ViewBag.StructureType = lookUpProvider.GetSelectList("STY", requestModel.STRUCTURE_TYPE.ToString());
                //ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", requestModel.STRUCTURE_SUB_TYPE.ToString());
                //ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", requestModel.ASSET_TYPE.ToString());
                //ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", requestModel.ASSET_SPECIFICATION.ToString());
                ViewBag.PurchaseProject = projectProvider.GetSelectList(requestModel.PROJECT.ToString());
                //ViewBag.PurchaseStore = storeProvider.GetSelectList(0, "");
            }
            else
            {
                requestModel = new PendingRequisitionsReport();                
                ViewBag.PurchaseProject = projectProvider.GetSelectList("0", "");                
            }

            requestModel.pendingRequisitionsReport = GetPendingRequisitionsReport(requestModel);
            return View(requestModel);
        }

        public List<PendingRequisitionsReport> GetPendingRequisitionsReport(PendingRequisitionsReport pendingRequisitionsReport)
        {            
            return Provider.GetPendingRequisitionsReport(pendingRequisitionsReport);
        }
    }
}
