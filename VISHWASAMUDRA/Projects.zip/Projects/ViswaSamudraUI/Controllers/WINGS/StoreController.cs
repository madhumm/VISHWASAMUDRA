﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class StoreController : Controller
    {
        string user = string.Empty;
        StoreProvider provider = null;
        ProjectProvider projectProvider = new ProjectProvider();
        private readonly IHttpContextAccessor _httpContextAccessor;
        public StoreController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            provider = new StoreProvider(user, httpContextAccessor);
            projectProvider = new ProjectProvider(httpContextAccessor);
        }
        public IActionResult Index(StoreSearch requestModel)
        {
            StoreSearch returnModel = new StoreSearch();
            if (requestModel.searchFilter != null)
            {
                ViewBag.ParentStore = provider.GetSelectList(0, requestModel.searchFilter.ParentStore);
                ViewBag.Project = projectProvider.GetSelectList(requestModel.searchFilter.Project);
                returnModel.filterEnabled = true;
            }
            else
            {
                requestModel.searchFilter = new Store();
                ViewBag.ParentStore = provider.GetSelectList(0);
                ViewBag.Project = projectProvider.GetSelectList();
            }
            IEnumerable<Store> list = provider.GetAll(requestModel.searchFilter).OrderByDescending(s=>s.Id);
            returnModel.resultList = list;
            return View(returnModel);
        }

        public async Task<IActionResult> StoreOps(Store ioModel)
        {
            if (ioModel.Guid == Guid.Empty)
            {
                ViewBag.ParentStore = provider.GetSelectList(0);
                ViewBag.Project = projectProvider.GetSelectList();
                return View(ioModel);
            }
            IEnumerable<Store> list = provider.GetAllStore(ioModel);
            var result = list.FirstOrDefault();
            ViewBag.ParentStore = provider.GetSelectList(result.Id, result.ParentStore);
            ViewBag.Project = projectProvider.GetSelectList(result.Guid.ToString());
            return View(result);
        }

        public ActionResult StoreModification(Store model)
        {
            return Ok(provider.Add(model));           
        }

        public IActionResult Delete(Store model)
        {
            ResponseBody res = provider.Delete(model);
            if(res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
