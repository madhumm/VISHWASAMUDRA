﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class LookUpChildController : Controller
    {
        LookUpProvider lookUpProvider = null;
        LookupTypeValue lookupTypevalue = new LookupTypeValue();
        LookupType lookupType = new LookupType();
        private Guid guidV;
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public LookUpChildController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            lookUpProvider = new LookUpProvider(user);
        }
        public IActionResult Index(Guid guid)
        {
            if (guid == Guid.Empty)
            {
                guid = (Guid)TempData["GuidValue"];
            }
            lookupTypevalue.LookupTypeId = guid;
            lookupType.Guid = guid;
            return View(Getdata(lookupTypevalue));
        }

        public IEnumerable<LookupTypeValue> Getdata(LookupTypeValue lookupTypevalue)
        {
            IEnumerable<LookupTypeValue> list = LookUpList(lookupTypevalue).OrderBy(x => x.OrderId).ToList();
            ViewBag.lookupname = lookUpProvider.GetLookupData(lookupType).Select(x => x.Name).FirstOrDefault();
            ViewBag.lookupguid = lookUpProvider.GetLookupData(lookupType).Select(x => x.Guid).FirstOrDefault();
            return list;
        }

        public ActionResult LookUpTypeModification(LookupTypeValue model)
        {
            TempData["GuidValue"] = model.LookupTypeId;
            return Ok(lookUpProvider.Add(model));
        }

        public IEnumerable<LookupTypeValue> LookUpList(LookupTypeValue flookupType)
        {
            return lookUpProvider.GetLookupValue(flookupType);
        }

        public IActionResult Delete(LookupTypeValue model)
        {
            lookupTypevalue.Guid = model.Guid;
            LookupTypeValue ltypeId = LookUpList(lookupTypevalue).FirstOrDefault();
            ResponseBody res = lookUpProvider.DeleteValue(model);
            if (res != null && res.Success == true)
            {
                var GuidValue = (Guid)ltypeId.LookupTypeId;
                TempData["GuidValue"] = GuidValue;
                return RedirectToAction("Index", "LookUpChild");
            }
            else
            {
                return Ok(res);
            }
        }

        public ActionResult SaveLookupvaluesOrder(LookupTypeValue model)
        {
            ResponseBody response = lookUpProvider.Save(model);
            return Ok(response);
        }

    }
}
