﻿using DocumentFormat.OpenXml.EMMA;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Asset;
using ViswaSamudraUI.Providers.Assets;
using VSManagement.IOModels.DropDown;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class AssetRequisitionsReportController : Controller
    {
        ReportDetails Provider = new ReportDetails();
        AssetProvider assetprovider;
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectProvider projectProvider = null;
        TableHelper TableHelper = new TableHelper();
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public AssetRequisitionsReportController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetprovider = new AssetProvider(user, httpContextAccessor);
            projectProvider = new ProjectProvider(httpContextAccessor);
        }
        public IActionResult Index(AssetRequisitionsReport requestModel)
        {
            if (requestModel != null)
            {
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY", requestModel.STRUCTURE_TYPE.ToString());
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", requestModel.STRUCTURE_SUB_TYPE.ToString());
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", requestModel.ASSET_TYPE.ToString());
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", requestModel.ASSET_SPECIFICATION.ToString());
                ViewBag.PurchaseProject = projectProvider.GetSelectList(requestModel.PROJECT.ToString());
                if (requestModel.PROJECT == null && requestModel.ASSET_SPECIFICATION == null && requestModel.ASSET_TYPE == null
                    && requestModel.STRUCTURE_TYPE == null && requestModel.STRUCTURE_SUB_TYPE == null)
                {
                    requestModel.filterEnabled = false;

                }
                else
                {

                    requestModel.filterEnabled = true;
                }
            }
            else
            {
                requestModel = new AssetRequisitionsReport();
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY", "");
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", "");
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", "");
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", "");
                ViewBag.PurchaseProject = projectProvider.GetSelectList("0", "");
                requestModel.filterEnabled = false;
            }
            if (string.IsNullOrEmpty(requestModel.ReportType)|| requestModel.ReportType=="R")
            {
                requestModel.ReportType = "R";
                ViewBag.title = "Asset Requestion Report";
            }
            else
            {
                ViewBag.title = "Asset Transfer Report";
            }
            requestModel.assetRequisitionsReport = GetassetRequisitionsReport(requestModel);
            ViewBag.HtmlStr = GetTableHtml(requestModel.assetRequisitionsReport, requestModel.ReportType).ToString();
            return View(requestModel);
        }

        public List<AssetRequisitionsReport> GetassetRequisitionsReport(AssetRequisitionsReport assetRequisitionsReport)
        {
           // return new List<AssetRequisitionsReport>();
           return Provider.GetassetRequisitionsReport(assetRequisitionsReport);
        }


        public string GetTableHtml(List<AssetRequisitionsReport> drp, string ReportType)
        {

            ViswasamudraCommonObjects.Asset.AssetRequisitionsReport objAssetRequisitionsReporrts = new ViswasamudraCommonObjects.Asset.AssetRequisitionsReport();
            objAssetRequisitionsReporrts.ASSET_SPECIFICATION_NAME = "Total Requisitions";
            objAssetRequisitionsReporrts.PENDING = drp.Sum(item => Convert.ToInt32(item.PENDING)).ToString();
            objAssetRequisitionsReporrts.APPROVED = drp.Sum(item => Convert.ToInt32(item.APPROVED)).ToString();
            objAssetRequisitionsReporrts.COMPLETELYFULFILLED = drp.Sum(item => Convert.ToInt32(item.COMPLETELYFULFILLED)).ToString();
            objAssetRequisitionsReporrts.PARTIALLYFULFILLED = drp.Sum(item => Convert.ToInt32(item.PARTIALLYFULFILLED)).ToString();
            objAssetRequisitionsReporrts.NOTFULFILLED = drp.Sum(item => Convert.ToInt32(item.NOTFULFILLED)).ToString();
            string data = "";
            data = data + TableHelper.TableStart() + TableHeader(ReportType);
            data = data + "<tbody>";
            int i = 1;
            int colspan = 6;
            if (ReportType == "R")
            {
                foreach (var item in drp)
                {
                    if (string.IsNullOrEmpty(item.NOTFULFILLED))
                    {
                        item.NOTFULFILLED = "0";
                    }
                    string PendingLink_href = "/AssetRequestionDetailReport?ASSET_TYPE=" + item.ASSET_TYPE + '&' +
                        "ASSET_SPECIFICATION=" + item.ASSET_SPECIFICATION + '&' +
                        "STRUCTURE_TYPE=" + item.STRUCTURE_TYPE + '&' +
                         "STRUCTURE_SUB_TYPE=" + item.STRUCTURE_SUB_TYPE;
                    string ApprovedLink_href = "/ApprovedRequistionDetailReport?ASSET_TYPE=" + item.ASSET_TYPE + '&' +
                        "ASSET_SPECIFICATION=" + item.ASSET_SPECIFICATION + '&' +
                        "STRUCTURE_TYPE=" + item.STRUCTURE_TYPE + '&' +
                         "STRUCTURE_SUB_TYPE=" + item.STRUCTURE_SUB_TYPE;

                    data = data + "<tr>";
                    data = data + "<td>" + i.ToString() + "</td> ";
                    data = data + "<td>" + item.PROJECT_NAME + "</td> ";
                    data = data + "<td>" + item.TASK_TYPE_NAME + "</td> ";
                    data = data + "<td>" + item.STRUCTURE_TYPE_NAME + "</td> ";
                    data = data + "<td>" + item.STRUCTURE_SUB_TYPE_NAME + "</td> ";
                    data = data + "<td>" + item.ASSET_TYPE_NAME + "</td> ";
                    data = data + "<td>" + item.ASSET_SPECIFICATION_NAME + "</td> ";
                    data = data + "<td>" + "<u><a  title=" + "'Pending Requistions'" + " href= " + PendingLink_href + " >" + item.PENDING + "</a></u>" + "</td> ";
                    data = data + "<td>" + "<u><a  title=" + "'Approved Requistions'" + " href= " + ApprovedLink_href + " >" + item.APPROVED + "</a></u>" + "</td> ";
                    data = data + "<td>" + item.COMPLETELYFULFILLED + "</td> ";
                    data = data + "<td>" + item.PARTIALLYFULFILLED + "</td> ";
                    data = data + "<td>" + item.NOTFULFILLED + "</td> ";
                    data = data + " </tr>";

                    i++;
                }
            }
            else
            {
                colspan = 7;
                foreach (var item in drp)
                {
                    if (string.IsNullOrEmpty(item.NOTFULFILLED))
                    {
                        item.NOTFULFILLED = "0";
                    }
                    string PendingLink_href = "/AssetRequestionDetailReport?ASSET_TYPE=" + item.ASSET_TYPE + '&' +
                        "ASSET_SPECIFICATION=" + item.ASSET_SPECIFICATION + '&' +
                        "STRUCTURE_TYPE=" + item.STRUCTURE_TYPE + '&' +
                         "STRUCTURE_SUB_TYPE=" + item.STRUCTURE_SUB_TYPE;
                    string ApprovedLink_href = "/ApprovedRequistionDetailReport?ASSET_TYPE=" + item.ASSET_TYPE + '&' +
                        "ASSET_SPECIFICATION=" + item.ASSET_SPECIFICATION + '&' +
                        "STRUCTURE_TYPE=" + item.STRUCTURE_TYPE + '&' +
                         "STRUCTURE_SUB_TYPE=" + item.STRUCTURE_SUB_TYPE;

                    data = data + "<tr>";
                    data = data + "<td>" + i.ToString() + "</td> ";
                    data = data + "<td>" + item.FROM_PROJECT_NAME + "</td> ";
                    data = data + "<td>" + item.PROJECT_NAME + "</td> ";
                    data = data + "<td>" + item.TASK_TYPE_NAME + "</td> ";
                    data = data + "<td>" + item.STRUCTURE_TYPE_NAME + "</td> ";
                    data = data + "<td>" + item.STRUCTURE_SUB_TYPE_NAME + "</td> ";
                    data = data + "<td>" + item.ASSET_TYPE_NAME + "</td> ";
                    data = data + "<td>" + item.ASSET_SPECIFICATION_NAME + "</td> ";
                    data = data + "<td>" + "<u><a  title=" + "'Pending Requistions'" + " href= " + PendingLink_href + " >" + item.PENDING + "</a></u>" + "</td> ";
                    data = data + "<td>" + "<u><a  title=" + "'Approved Requistions'" + " href= " + ApprovedLink_href + " >" + item.APPROVED + "</a></u>" + "</td> ";
                    data = data + "<td>" + item.COMPLETELYFULFILLED + "</td> ";
                    data = data + "<td>" + item.PARTIALLYFULFILLED + "</td> ";
                    data = data + "<td>" + item.NOTFULFILLED + "</td> ";
                    data = data + " </tr>";

                    i++;
                }
            }

            data = data + "<tfoot>" +
               "<tr> " +
               "<th rowspan = '1' colspan = '" + colspan.ToString() + "' >  </th> " +
               "<th rowspan = '1' colspan = '1' >"+ objAssetRequisitionsReporrts.ASSET_SPECIFICATION_NAME +"</th> " +
               "<th rowspan = '1' colspan = '1' > " + objAssetRequisitionsReporrts.PENDING + " </th> " +
               "<th rowspan = '1' colspan = '1' > " + objAssetRequisitionsReporrts.APPROVED + " </th> " +
               "<th rowspan = '1' colspan = '1' > " + objAssetRequisitionsReporrts.COMPLETELYFULFILLED + " </th> " +
               "<th rowspan = '1' colspan = '1' > " + objAssetRequisitionsReporrts.PARTIALLYFULFILLED + " </th> " +
               "<th rowspan = '1' colspan = '1' > " + objAssetRequisitionsReporrts.NOTFULFILLED + " </th> " +
               "</tr>" +
               "</tfoot>";
            data = data + "</tbody>";
            data = data + "</table>";
            return data;


        }
        public string TableHeader(string  ReportType)
        {
            if (ReportType == "R")
            {
                return
                    "<thead>" +
                    "<tr>" +
                    "<th>Sno</th>" +
                    "<th>Project Name</th>" +
                   "<th>Task Type</th>" +
                    "<th>Structure Type</th>" +
                    "<th> Sub Structure Type</th>" +
                    "<th>Asset Type</th>" +
                    "<th>Asset Specification</th>" +
                    "<th>Pending Requisitions</th>" +
                     "<th>Approved Requisitions</th>" +
                    "<th>Completely Fulfilled</th>" +
                    "<th>Partially Fulfilled</th>" +
                    "<th>Not Fulfilled</th>" +
                    "</tr>" +
                    "</thead>";
            }
            else
            {
                return
                    "<thead>" +
                    "<tr>" +
                    "<th>Sno</th>" +
                    "<th>From Project </th>" +
                    "<th>To Project </th>" +
                   "<th>Task Type</th>" +
                    "<th>Structure Type</th>" +
                    "<th> Sub Structure Type</th>" +
                    "<th>Asset Type</th>" +
                    "<th>Asset Specification</th>" +
                    "<th>Pending Requisitions</th>" +
                     "<th>Approved Requisitions</th>" +
                    "<th>Completely Fulfilled</th>" +
                    "<th>Partially Fulfilled</th>" +
                    "<th>Not Fulfilled</th>" +
                    "</tr>" +
                    "</thead>";
            }


        }
    }
}
