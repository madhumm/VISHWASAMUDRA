﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswasamudraCommonObjects.Util;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;
using VSManagement.IOModels.DropDown;

namespace ViswaSamudraUI.Controllers.WINGS.Approval
{
    [CheckSession]
    public class AssetRequisitionApprovalController : Controller
    {
        //AssetProvider provider = new AssetProvider();
        string user = string.Empty;
        List<AssetRequisitionDetails> arDetails = new List<AssetRequisitionDetails>();
        AssetRequisitionHeader aHeader = new AssetRequisitionHeader();
        AssetRequisition aRequisition = new AssetRequisition();
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectProvider projectProvider = new ProjectProvider();
        AssetRequistionProvider assetRequistionProvider = null;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public AssetRequisitionApprovalController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetRequistionProvider = new AssetRequistionProvider(user, _httpContextAccessor);
        }

        public IActionResult Index(AssetRequisitionSearch requestModel)
        {
            AssetRequisitionSearch returnModel = new AssetRequisitionSearch();
            returnModel.searchFilter = new AssetRequisition();
            if (requestModel.searchFilter == null)
            {
                ViewBag.RequestedUsers = assetRequistionProvider.GetUserData(null, "");
                ViewBag.TaskType = lookUpProvider.GetSelectList("TTY");
                ViewBag.Project = projectProvider.GetSelectList();
            }
            else
            {

                ViewBag.RequestedUsers = assetRequistionProvider.GetUserData(requestModel.searchFilter.header.Project,requestModel.searchFilter.header.RequestedBy);
                ViewBag.TaskType = lookUpProvider.GetSelectList("TTY", requestModel.searchFilter.header.TaskType.ToString());
                ViewBag.Project = projectProvider.GetSelectList(requestModel.searchFilter.header.Project.ToString());
                aHeader = requestModel.searchFilter.header;
                returnModel.filterEnabled = true;
            }
            IEnumerable<AssetRequisition> list = getdetails();
            returnModel.resultList= list;
            return View("~/Views/Wingz/Approval/AssetRequisitionApproval/Index.cshtml", returnModel);
        }

        public IEnumerable<AssetRequisition> getdetails()
        {
            string user = HttpContext.Session.GetString("user");
            if(string.IsNullOrEmpty(user)) return new List<AssetRequisition>();
            aHeader.RecordStatus = 1;
            aHeader.ApprovedBy = user;
            aHeader.ApprovalFlag = "blank";
            aRequisition.header = aHeader;
            return assetRequistionProvider.GetAll(aRequisition).OrderByDescending(a => a.header.Id);
        }

        public ActionResult AssetRequisitionModification(AssetRequisition model)
        {
            return Ok(assetRequistionProvider.Add(model));
        }
        public async Task<IActionResult> AssetRequisitionApprovalOps(AssetRequisitionHeader model)
        {
            aHeader.Guid = model.Guid;
            aRequisition.header = aHeader;
            AssetRequisition AssetReq = aRequisition;

            AssetReq = assetRequistionProvider.GetAll(aRequisition).FirstOrDefault();
            
            return View("~/Views/Wingz/Approval/AssetRequisitionApproval/ViewDetails.cshtml", AssetReq);
        }
        public ActionResult Delete(Guid guid)
        {
            aHeader.Guid = guid;
            aHeader.LastUpdatedDateTime = DateTime.Now;
            aHeader.LastUpdatedBy = user;
            aRequisition.header = aHeader;
            AssetRequisition AssetReq = aRequisition;
            ResponseBody res = assetRequistionProvider.Delete(AssetReq);
            if (res != null && res.Success == true)
            {   
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }

        public ActionResult Approve(AuthorizeRecordRequest model)
        {
            aHeader.ApprovalFlag = model.ApprovalFlag;
            aHeader.LastUpdatedBy = user;
            aHeader.LastUpdatedDateTime = DateTime.Now;
            aHeader.Guid = model.Guid;
            aHeader.Reason = model.Reason;
            aRequisition.header = aHeader;
            return Ok(assetRequistionProvider.Approve(aRequisition));
        }
    }
}
