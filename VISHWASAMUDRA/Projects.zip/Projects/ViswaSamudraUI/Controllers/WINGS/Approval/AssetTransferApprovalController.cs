﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswasamudraCommonObjects.Util;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS.Approval
{
    [CheckSession]
    public class AssetTransferApprovalController : Controller
    {
        string user = string.Empty;
        //AssetProvider provider = new AssetProvider();
        List<AssetTransferDetails> arDetails = new List<AssetTransferDetails>();
        AssetTransferHeader aHeader = new AssetTransferHeader();
        AssetTransfer aTransfer = new AssetTransfer();
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectProvider projectProvider = new ProjectProvider();
        AssetTransferProvider assetTransferProvider = null;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public AssetTransferApprovalController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetTransferProvider = new AssetTransferProvider(user, httpContextAccessor);
        }


        public IActionResult Index(AssetTransferSearch requestModel)
        {
            AssetTransferSearch returnModel = new AssetTransferSearch();

            if (requestModel.searchFilter != null)
            {
                ViewBag.RequestedUsers = lookUpProvider.GetActiveUserDropDownbyProject(requestModel.searchFilter.header.ToProject,requestModel.searchFilter.header.RequestedBy.ToString());
                ViewBag.TaskType = lookUpProvider.GetSelectList("TTY", requestModel.searchFilter.header.TaskType.ToString());
                ViewBag.FromProject = projectProvider.GetSelectList(requestModel.searchFilter.header.FromProject.ToString());
                ViewBag.ToProject = projectProvider.GetSelectList(requestModel.searchFilter.header.ToProject.ToString(), requestModel.searchFilter.header.FromProject.ToString());
                aHeader = requestModel.searchFilter.header;
                returnModel.filterEnabled = true;
            }
            else
            {
                ViewBag.RequestedUsers = lookUpProvider.GetActiveUserDropDownbyProject(null,null);
                ViewBag.TaskType = lookUpProvider.GetSelectList("TTY");
                ViewBag.FromProject = projectProvider.GetSelectList();
                ViewBag.ToProject = projectProvider.GetSelectList();
            }
            IEnumerable<AssetTransfer> list = getdetails();
            returnModel.resultList = list;
            return View("~/Views/Wingz/Approval/AssetTransferApproval/Index.cshtml", returnModel);
        }

        public IEnumerable<AssetTransfer> getdetails()
        {
            string user = HttpContext.Session.GetString("userGuid");
            if(string.IsNullOrEmpty(user)) return new List<AssetTransfer>();
            aHeader.RecordStatus = 1;
            aHeader.ApprovedBy = user;
            aHeader.ApprovalFlag = "blank";
            aTransfer.header = aHeader;
            return assetTransferProvider.GetAll(aTransfer).OrderByDescending(a => a.header.Id);
        }

        public ActionResult AssetTransferModification(AssetTransfer model)
        {
            return Ok(assetTransferProvider.Add(model));
        }
        public async Task<IActionResult> AssetTransferApprovalOps(AssetTransferHeader model)
        {
            aHeader.Guid = model.Guid;
            aTransfer.header = aHeader;
            AssetTransfer AssetReq = aTransfer;

            AssetReq = assetTransferProvider.GetAll(aTransfer).FirstOrDefault();
            AssetReq.isApproval = true;
            //return View("~/Views/Wingz/Approval/AssetTransferApproval/ViewDetails.cshtml", AssetReq);
            return View("~/Views/AssetTransfer/AssetTransferOps.cshtml", AssetReq);
        }
        public ActionResult Delete(Guid guid)
        {
            aHeader.Guid = guid;
            aHeader.LastUpdatedDateTime = DateTime.Now;
            aHeader.LastUpdatedBy = user;
            aTransfer.header = aHeader;
            AssetTransfer AssetReq = aTransfer;
            ResponseBody res = assetTransferProvider.Delete(AssetReq);
            if (res != null && res.Success == true)
            {   
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }

        public ActionResult Approve(AuthorizeRecordRequest model)
        {
            aHeader.ApprovalFlag = model.ApprovalFlag;
            aHeader.LastUpdatedBy = user;
            aHeader.LastUpdatedDateTime = DateTime.Now;
            aHeader.Guid = model.Guid;
            aHeader.Reason = model.Reason;
            aTransfer.header = aHeader;
            return Ok(assetTransferProvider.Approve(aTransfer));
        }

        public async Task<IActionResult> GetActiveUserDropDownbyProject(Guid Project)
        {
            if (Project == null || Project == new Guid())
            {
                List<SelectListItem> newList = new List<SelectListItem>();
                return Json(newList);
            }
            else
            {
                List<SelectListItem> Employees = lookUpProvider.GetActiveUserDropDownbyProject(Project, null);
                return Json(Employees);
            }


        }

        
    }
}
