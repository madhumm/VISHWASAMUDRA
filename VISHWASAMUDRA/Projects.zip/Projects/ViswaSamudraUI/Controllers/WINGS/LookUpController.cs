﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class LookUpController : Controller
    {
        LookUpProvider lookUpProvider = null;
        LookupType lookupType = new LookupType();
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public LookUpController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            lookUpProvider = new LookUpProvider(user);
        }
        public IActionResult Index(LookupTypeSearch requestModel)
        {
            LookupTypeSearch returnModel = new LookupTypeSearch();

            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }
            IEnumerable<LookupType> list = LookUpList(requestModel.searchFilter).OrderByDescending(I => I.Id);
            returnModel.resultList = list;
            return View(returnModel);
        }

        public IActionResult LoadGrid()
        {
            IEnumerable<LookupType> list = LookUpList(lookupType);
            return View(list);
        }

        public IEnumerable<LookupType> LookUpList(LookupType flookupType)
        {
            if (flookupType != null)
            {
                return lookUpProvider.GetLookupData(flookupType).OrderByDescending(I => I.Id);
            }
            else
            {
                return lookUpProvider.GetLookupData(lookupType).OrderByDescending(I => I.Id);
            }
        }

        public IActionResult lookupops(Guid guid = new Guid())
        {
            if (guid == Guid.Empty)
            {
                LookupType ioModel=new LookupType();
                ViewBag.Status = lookUpProvider.GetSelectList("TGS");
                return View(ioModel);
            }
            lookupType.Guid = guid;
            IEnumerable<LookupType> list = LookUpList(lookupType);
            return View(list.FirstOrDefault());
        }
        public ActionResult LookUpTypeModification(LookupType model)
        {
            return Ok(lookUpProvider.Add(model));
        }

        public IActionResult Delete(LookupType model)
        {
            ResponseBody res = lookUpProvider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
