﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswaSamudraUI.Providers.Assets;
using Microsoft.AspNetCore.Mvc.Rendering;
using io =VSAssetManagement.IOModels;
using System.Text.RegularExpressions;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Filters;
using ViswasamudraCommonObjects.Asset.SearchForms;
using Microsoft.AspNetCore.Http;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class ReasonController : Controller
    {
        ReasonProvider reasonProvider = null;
        LookUpProvider lookUpProvider = null;
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public ReasonController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            lookUpProvider = new LookUpProvider(user);
            reasonProvider = new ReasonProvider(user);
        }
        public IActionResult Index(Reasonssearch requestModel)
        {
            Reasonssearch returnModel = new Reasonssearch();
            if (requestModel.searchFilter != null)
            {
                ViewBag.reasontype = lookUpProvider.GetSelectList("RTY", requestModel.searchFilter.ReasonType.ToString());
                returnModel.filterEnabled = true;
            }
            else
            {
                ViewBag.reasontype = lookUpProvider.GetSelectList("RTY");
            }
            IEnumerable<io.Reason> reasonList = reasonProvider.GetAllReason(requestModel.searchFilter);
            returnModel.resultList = reasonList;
            return View(returnModel);            
        }
        public async Task<IActionResult> ReasonGetDetailById(io.Reason resModel)
        {
            if (resModel.Guid == Guid.Empty || resModel.Guid == null)
            {
                ViewBag.reasontype = lookUpProvider.GetSelectList("RTY");
                return View("ReasonOps", resModel);
            }
            IEnumerable<io.Reason> poList = reasonProvider.GetAllReason(resModel);
            var result = poList.FirstOrDefault();           
            
            ViewBag.reasontype = lookUpProvider.GetSelectList("RTY", result.ReasonType.ToString());

            return View("ReasonOps", result);
        }

        public ActionResult ReasonModification(io.Reason resModel)
        {
            return Ok(reasonProvider.AddReason(resModel));
            //return Content(poStatus);
        }

        public IActionResult Delete(io.Reason model)
        {
            ResponseBody res = reasonProvider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
