﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class AssetRequisitionController : Controller
    {
        string user = string.Empty;
        //AssetProvider provider = new AssetProvider();
        List<AssetRequisitionDetails> arDetails = new List<AssetRequisitionDetails>();
        AssetRequisitionHeader aHeader = new AssetRequisitionHeader();
        AssetRequisition aRequisition = new AssetRequisition();
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectProvider projectProvider = new ProjectProvider();
        AssetRequistionProvider assetRequistionProvider = null;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public AssetRequisitionController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetRequistionProvider = new AssetRequistionProvider(user, httpContextAccessor);
            projectProvider = new ProjectProvider(httpContextAccessor);
        }

        public IActionResult Index(AssetRequisitionSearch requestModel)
        {            
            AssetRequisitionSearch returnModel = new AssetRequisitionSearch();
            returnModel.searchFilter = new AssetRequisition();
            if (requestModel.searchFilter == null)
            {
                ViewBag.RequestedUsers = assetRequistionProvider.GetUserData(null,"");
                ViewBag.ApproveUsers = assetRequistionProvider.GetUserData(null,"");
                ViewBag.TaskType = lookUpProvider.GetSelectList("TTY");
                ViewBag.Project = projectProvider.GetSelectList();
            }
            else
            {
                ViewBag.Project = projectProvider.GetSelectList(requestModel.searchFilter.header.Project.ToString());
                ViewBag.RequestedUsers = assetRequistionProvider.GetUserData(requestModel.searchFilter.header.Project,requestModel.searchFilter.header.RequestedBy);
                ViewBag.ApproveUsers = assetRequistionProvider.GetUserData(requestModel.searchFilter.header.Project,requestModel.searchFilter.header.ApprovedBy);
                ViewBag.TaskType = lookUpProvider.GetSelectList("TTY", requestModel.searchFilter.header.TaskType.ToString());
                ViewBag.Project = projectProvider.GetSelectList(requestModel.searchFilter.header.Project.ToString());
                aHeader = requestModel.searchFilter.header;
                returnModel.filterEnabled = true;
            }
            IEnumerable<AssetRequisition> list = getdetails();
            returnModel.resultList = list;
            return View(returnModel);
        }

        public IEnumerable<AssetRequisition> getdetails()
        {
            aHeader.RecordStatus = 1;
            aRequisition.header = aHeader;
            return assetRequistionProvider.GetAll(aRequisition).OrderByDescending(a => a.header.Id);
        }

        public ActionResult AssetRequisitionModification(AssetRequisition model)
        {
            return Ok(assetRequistionProvider.Add(model));
        }
        public async Task<IActionResult> AssetRequisitionOps(AssetRequisitionHeader model)
        {
            aHeader.Guid = model.Guid;
            aRequisition.header = aHeader;
            AssetRequisition AssetReq = aRequisition;

            if (model.Guid == System.Guid.Empty)
            {
                ViewBag.RequestedUsers = assetRequistionProvider.GetUserData(null,null);
                ViewBag.ApproveUsers = assetRequistionProvider.GetUserData(null, null);
                ViewBag.TaskType = lookUpProvider.GetSelectList("TTY");
                ViewBag.Project = projectProvider.GetSelectList();
            }
            else
            {
                
                AssetReq = assetRequistionProvider.GetAll(aRequisition).FirstOrDefault();
                ViewBag.RequestedUsers = assetRequistionProvider.GetUserData(AssetReq.header.Project, AssetReq.header.RequestedBy);
                ViewBag.ApproveUsers = assetRequistionProvider.GetUserData(AssetReq.header.Project, AssetReq.header.ApprovedBy);
                ViewBag.TaskType = lookUpProvider.GetSelectList("TTY", AssetReq.header.TaskType.ToString());
                ViewBag.Project = projectProvider.GetSelectList(AssetReq.header.Project.ToString());
            }           
            
            ViewBag.StructureType = lookUpProvider.GetSelectList("STY");
            ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST");
            ViewBag.AssetType = lookUpProvider.GetSelectList("ATY");
            ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS");
            ViewBag.Uom = lookUpProvider.GetSelectList("UOM");

            return View(AssetReq);
        }
        public ActionResult Delete(Guid guid)
        {
            aHeader.Guid = guid;
            aHeader.LastUpdatedDateTime = DateTime.Now;
            aHeader.LastUpdatedBy = user;
            aRequisition.header = aHeader;
            AssetRequisition AssetReq = aRequisition;
            ResponseBody res = assetRequistionProvider.Delete(AssetReq);
            if (res != null && res.Success == true)
            {   
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }


        }

        public async Task<IActionResult> EmployeesbyProject(Guid Project)
        {
            if (Project == null || Project == new Guid())
            {
                List<SelectListItem> newList = new List<SelectListItem>();
                return Json(newList);
            }
            else
            {
                List<SelectListItem> Employees = assetRequistionProvider.GetUserData(Project, null);
                return Json(Employees);
            }

            
        }
    }
}
