﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using ViswaSamudraUI.Models;
using Newtonsoft.Json;
using VSAssetManagement.IOModels;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Providers;
using ViswaSamudraUI.Providers.HRMS;
using Settings.IOModels;
using Microsoft.AspNetCore.Http;
using Microsoft.CodeAnalysis.CSharp.Syntax;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class HomeController : Controller
    {
        UserMenuProvider Provider = new UserMenuProvider();
        public async Task<IActionResult> Index()
        {
            string _username = HttpContext.Session.GetString("user");
            if (string.IsNullOrEmpty(_username)) return Redirect("login");
            IEnumerable<UserMenuControl> drp = Provider.GetUserMenuControls(_username);
            String UI = "";
            foreach (string oprName in drp.Select(x => x.Operation).Distinct())
            {
                UI= UI+GetHeader(oprName);
                foreach (string Application in drp.Where(u=>u.Operation== oprName).Select(x => x.ApplicationName).Distinct())
                {
                    UI = UI + GetApplication(Application);
                    foreach(var Menu in drp.Where(u => u.ApplicationName == Application && u.ParentMenuID==null ))
                    {
                        if(drp.Where(m=>m.ParentMenuID== Menu.MenuId).Any())
                        {
                            UI = UI + GetParentMenu(Menu.MenuName);
							UI = UI + Contructmenu(drp.Where(u => u.ParentMenuID == Menu.MenuId));
                            //Menu closing Tag
							UI = UI + CloseTag();
						}
                        else
                        {
                            UI = UI + GetMenu(Menu.MenuName, Menu.Path);
						}
                    }
                    //Application Closing Tag
                    UI = UI + CloseTag();
                }
            }            
            ViewBag.MenuStr = UI.Replace("'", @"""").Replace("$$", "'");
            return View();
        }


        public string Contructmenu(IEnumerable<UserMenuControl> umu,String UI="")
        {            
            foreach (var Menu in umu)
            {
                if (umu.Where(m => m.ParentMenuID == Menu.MenuId).Any())
                {
					UI = UI + GetParentMenu(Menu.MenuName);
					UI = UI + Contructmenu(umu.Where(u => u.ParentMenuID == Menu.MenuId), UI);
					//Menu closing Tag
				}
				else
                {
                    UI = UI + GetMenu(Menu.MenuName,Menu.Path);
                }
            }
            return UI;
        }


        public string GetHeader(String Header)
        {
            return "<li class='nav-item pcoded-menu-caption'> <label>" + Header + "</label> </li>";
        }

        public string GetApplication(String appName)
        {
            return "<li class='nav-item pcoded-hasmenu'>" +
                   "<a href = '#' class='nav-link waves-effect waves-light'><span class='pcoded-micon'><i class='feather icon-airplay'></i></span><span class='pcoded-mtext'>"+ appName + "</span></a>" +
                   "<ul class='pcoded-submenu'>";
        }

        public string GetMenu(String MenuName,String Path)
        {
            return "<li class='' id='" + MenuName.Replace(" ", "") + "ID' ><a class='waves-effect' onclick='LoadPage($$"+ Path + "$$);'>" + MenuName + "</a></li>";
        }

        public String GetParentMenu(String ParentName)
        {
            return "<li class='nav-item pcoded-hasmenu'>" +
                   "<a href = '#!' class='nav-link waves-effect waves-light'><span class='pcoded-mtext'>" + ParentName + "</span></a>" +
                   "<ul class='pcoded-submenu' style='display: none;padding:0'>";
        }

        public String CloseTag()
        {
            return "</ul></li>";
        }




    }
}
