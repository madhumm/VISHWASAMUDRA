﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Drawing;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class DetailedReportController : Controller
    {
        ReportDetails Provider = new ReportDetails();
        TableHelper TableHelper = new TableHelper();
        public IActionResult Index()
        {
            IEnumerable<S_DetailedReport> drp = Provider.GetSummaryReport();
            string data = "";
            data = data + TableHelper.TableStart() + TableHelper.TableHeader("Structure");
            data = data + "<tbody>";
            int i = 1;
            foreach (var item in drp)
            {
                data = data + "<tr>";
                data = data + TableHelper.CreateChildLink(item.STRUCTURE + "_Link" + i.ToString());
                data = data + "<td>" + i.ToString() + "</td> ";
                data = data + "<td>" + item.STRUCTURE + "</td> ";
                data = data + "<td>" + item.TOTAL + "</td> ";
                data = data + "<td>" + item.AVAILABLE + "</td> ";
                data = data + "<td>" + item.UNDER_USE + "</td> ";
                data = data + "<td>" + item.TRFR_INWARD + "</td> ";
                data = data + "<td>" + item.TRFR_OUTWARD + "</td> ";
                data = data + "<td>" + item.UNDER_REPAIR + "</td> ";
                data = data + "<td>" + item.UNDER_SCRAP + "</td> ";
                data = data + " </tr>";

                data = data + "<tr>";
                data = data + TableHelper.innertablehead(item.STRUCTURE + "_Link" + i.ToString(), 1);
                data = data + TableHelper.TableHeader("SubStructure");
                int j = 1;
                foreach (var substructure in item.subStructureDetails)
                {
                    data = data + "<tr>";
                    data = data + TableHelper.CreateChildLink(substructure.SUB_STRUCTURE + "_Link" + j.ToString());
                    data = data + "<td>" + j.ToString() + "</td> ";
                    data = data + "<td>" + substructure.SUB_STRUCTURE + "</td> ";
                    data = data + "<td>" + substructure.TOTAL + "</td> ";
                    data = data + "<td>" + substructure.AVAILABLE + "</td> ";
                    data = data + "<td>" + substructure.UNDER_USE + "</td> ";
                    data = data + "<td>" + substructure.TRFR_INWARD + "</td> ";
                    data = data + "<td>" + substructure.TRFR_OUTWARD + "</td> ";
                    data = data + "<td>" + substructure.UNDER_REPAIR + "</td> ";
                    data = data + "<td>" + substructure.UNDER_SCRAP + "</td> ";
                    data = data + " </tr>";

                    data = data + "<tr>";
                    data = data + TableHelper.innertablehead(substructure.SUB_STRUCTURE + "_Link" + j.ToString(), 2);
                    data = data + TableHelper.TableHeader("Asset Type");
                    int k = 1;
                    foreach (var assetType in substructure.assertTypeReport)
                    {
                        data = data + "<tr>";
                        data = data + TableHelper.CreateChildLink(assetType.ASSET_TYPE + "_Link" + k.ToString());
                        data = data + "<td>" + k.ToString() + "</td> ";
                        data = data + "<td>" + assetType.ASSET_TYPE + "</td> ";
                        data = data + "<td>" + assetType.TOTAL + "</td> ";
                        data = data + "<td>" + assetType.AVAILABLE + "</td> ";
                        data = data + "<td>" + assetType.UNDER_USE + "</td> ";
                        data = data + "<td>" + assetType.TRFR_INWARD + "</td> ";
                        data = data + "<td>" + assetType.TRFR_OUTWARD + "</td> ";
                        data = data + "<td>" + assetType.UNDER_REPAIR + "</td> ";
                        data = data + "<td>" + assetType.UNDER_SCRAP + "</td> ";
                        data = data + "</tr>";

                        data = data + "<tr>";
                        data = data + TableHelper.innertablehead(assetType.ASSET_TYPE + "_Link" + k.ToString(), 3);
                        data = data + TableHelper.TableHeader("Asset Specification");
                        int l = 1;
                        foreach (var assetSpec in assetType.assertSpecReport)
                        {
                            data = data + "<tr>";
                            data = data + TableHelper.CreateChildLink(assetSpec.ASSET_SPEC + "_Link" + l.ToString());
                            data = data + "<td>" + l.ToString() + "</td> ";
                            data = data + "<td>" + assetSpec.ASSET_SPEC + "</td> ";
                            data = data + "<td>" + assetSpec.TOTAL + "</td> ";
                            data = data + "<td>" + assetSpec.AVAILABLE + "</td> ";
                            data = data + "<td>" + assetSpec.UNDER_USE + "</td> ";
                            data = data + "<td>" + assetSpec.TRFR_INWARD + "</td> ";
                            data = data + "<td>" + assetSpec.TRFR_OUTWARD + "</td> ";
                            data = data + "<td>" + assetSpec.UNDER_REPAIR + "</td> ";
                            data = data + "<td>" + assetSpec.UNDER_SCRAP + "</td> ";
                            data = data + " </tr>";

                            data = data + "<tr>";
                            data = data + TableHelper.innertablehead(assetSpec.ASSET_SPEC + "_Link" + l.ToString(), 4);
                            data = data + TableHelper.TableHeader("Project Name", "Project Code");

                            int m = 1;
                            foreach (var finproject in assetSpec.PROJECT_LIST)
                            {
                                data = data + "<tr>";
                                data = data + CreateProjectChildLink(finproject);
                                data = data + "<td>" + m.ToString() + "</td> ";
                                data = data + "<td>" + finproject.PROJECT_CODE + "</td> ";
                                data = data + "<td>" + finproject.PROJECT_NAME + "</td> ";
                                data = data + "<td>" + finproject.TOTAL + "</td> ";
                                data = data + "<td>" + finproject.AVAILABLE + "</td> ";
                                data = data + "<td>" + finproject.UNDER_USE + "</td> ";
                                data = data + "<td>" + finproject.TRFR_INWARD + "</td> ";
                                data = data + "<td>" + finproject.TRFR_OUTWARD + "</td> ";
                                data = data + "<td>" + finproject.UNDER_REPAIR + "</td> ";
                                data = data + "<td>" + finproject.UNDER_SCRAP + "</td> ";
                                data = data + " </tr>";
                                m++;
                            }
                            data = data + "</tbody>";
                            data = data + "</table>";
                        }
                        data = data + "</tbody>";
                        data = data + "</table>";
                        k++;
                    }
                    data = data + "</tbody>";
                    data = data + "</table>";
                    j++;
                }
                data = data + "</tbody>";
                data = data + "</table>";
                i++;
            }
            data = data + "</tbody>";
            data = data + "</table>";
            ViewBag.HtmlStr = data.Replace("'", @"""").Replace("$SC", "'");
            return View(drp);
        }

        public async Task<string> ShowStoreAndProject(S_ProjectReport prjr)
        {
            S_StoreReport srp = new S_StoreReport();
            srp.STRUCTURE = prjr.STRUCTURE;
            srp.SUB_STRUCTURE = prjr.SUB_STRUCTURE;
            srp.ASSET_TYPE = prjr.ASSET_TYPE;
            srp.ASSET_SPEC = prjr.ASSET_SPEC;
            srp.PROJECT_NAME = prjr.PROJECT_NAME;
            srp.PROJECT_CODE = prjr.PROJECT_CODE;

            IEnumerable<S_StoreReport> drp = Provider.GetStoreSummaryReport(srp);
            string data = "";
            data = data + TableHelper.TableStart() + TableHelper.TableHeader("Store", "Store Code");
            data = data + "<tbody>";
            int i = 1;

            foreach (var item in drp)
            {
                data = data + "<tr>";
                data = data + "<td></td> ";
                data = data + "<td>" + i.ToString() + "</td> ";
                data = data + "<td>" + item.STORE_CODE + "</td> ";
                data = data + "<td>" + item.STORE_NAME + "</td> ";
                data = data + "<td>" + item.TOTAL + "</td> ";
                data = data + "<td>" + item.AVAILABLE + "</td> ";
                data = data + "<td>" + item.UNDER_USE + "</td> ";
                data = data + "<td>" + item.TRFR_INWARD + "</td> ";
                data = data + "<td>" + item.TRFR_OUTWARD + "</td> ";
                data = data + "<td>" + item.UNDER_REPAIR + "</td> ";
                data = data + "<td>" + item.UNDER_SCRAP + "</td> ";
                data = data + " </tr>";
                i++;
            }
            data = data + "</tbody>";
            data = data + "</table>";
            return data;
        }
        public string CreateProjectChildLink(S_ProjectReport pjr)
        {
            return "<td>" +
                "<a class='feather icon-eye' onclick='openstoredetails($SC" + pjr.STRUCTURE + "$SC,$SC" + pjr.SUB_STRUCTURE + "$SC," +
                "$SC" + pjr.ASSET_TYPE + "$SC,$SC" + pjr.ASSET_SPEC + "$SC,$SC" + pjr.PROJECT_NAME + "$SC,$SC" + pjr.PROJECT_CODE + "$SC); return false;'></a>" +
                "</td>";
        }



    }
}
