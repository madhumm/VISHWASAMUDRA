﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Security.Cryptography;
using ViswasamudraCommonObjects.Asset;
using ViswaSamudraUI.Providers.Assets;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class AssetUtilizationDetailReportController : Controller
    {
        ReportDetails Provider = new ReportDetails();
        AssetProvider assetprovider;
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectProvider projectProvider = new ProjectProvider();
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        TableHelper TableHelper = new TableHelper();
        public AssetUtilizationDetailReportController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetprovider = new AssetProvider(user, httpContextAccessor);
            projectProvider = new ProjectProvider(httpContextAccessor);
        }
        public IActionResult Index(AssetUtilizationDetailReport requestModel)
        {
            if (requestModel != null)
            {
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", requestModel.ASSET_TYPE.ToString());
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", requestModel.ASSET_SPECIFICATION.ToString());
                ViewBag.PurchaseProject = projectProvider.GetSelectList(requestModel.PROJECT_CODE.ToString());
              
                if (requestModel.PROJECT_CODE == null && 
                    requestModel.ASSET_TYPE == null && 
                    requestModel.ASSET_SPECIFICATION == null)
                {
                    requestModel.filterEnabled = false;

                }
                else
                {

                    requestModel.filterEnabled = true;
                }
            }
            else
            {
                requestModel = new AssetUtilizationDetailReport();
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", "");
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", "");
                ViewBag.PurchaseProject = projectProvider.GetSelectList("0", "");
                requestModel.filterEnabled = false;
            }
            requestModel.assetUtilizationDetailReport = GetAssetUtilizationDetailReport(requestModel);
            ViewBag.HtmlStr = GetTableHtml(requestModel.assetUtilizationDetailReport).ToString();
            return View(requestModel);
        }
        public List<AssetUtilizationDetailReport> GetAssetUtilizationDetailReport(AssetUtilizationDetailReport AssetUtilizationDetailReport)
        {
            return Provider.GetAssetUtilizationDetailReport(AssetUtilizationDetailReport);
        }

        public string GetTableHtml(List<AssetUtilizationDetailReport> drp)
        {
            string data = "";
            data = data + TableHelper.TableStart() + TableHeader();
            data = data + "<tbody>";
            int i = 1;

            foreach (var item in drp)
            {
                data = data + "<tr>";
                data = data + "<td>" + i.ToString() + "</td> ";
                data = data + "<td>" + item.PROJECT_NAME + "</td> ";
                data = data + "<td>" + item.STORE_NAME + "</td> ";
                data = data + "<td>" + item.ASSET_TYPE_NAME + "</td> ";
                data = data + "<td>" + item.ASSET_SPECIFICATION_NAME + "</td> ";
                data = data + "<td>" + item.ASSET_NAME + "</td> ";
                data = data + "<td>" + item.USE_FREQUENCY + "</td> ";
                data = data + "<td>" + item.USED_COUNT + "</td> ";
                data = data + "<td>" + item.UTILIZATION + "</td> ";
               
                data = data + " </tr>";

                i++;
            }
            data = data + "</tbody>";
            data = data + "</table>";
            return data;


        }
        public string TableStart() => $"<table id='AssetUtilizationReport' class='table table-striped table-bordered nowrap'>";
        public string TableHeader()
        {

            return
                "<thead>" +
                "<tr>" +
                "<th>Sno</th>" +
                "<th>Project Name</th>" +
                "<th>Store Name</th>" +
                "<th>Asset Type</th>" +
                "<th>Asset Specification</th>" +
                "<th>Asset Name</th>" +
                "<th>Use Frequency</th>" +
                "<th>No. Of Times Used</th>" +
                "<th>Utilization %</th>" +
                "</tr>" +
                "</thead>";


        }

    }
}
