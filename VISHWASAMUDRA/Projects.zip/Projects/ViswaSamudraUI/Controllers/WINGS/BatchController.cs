﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Http.Results;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswasamudraCommonObjects.Project;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;
using io = VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class BatchController : Controller
    {
        BatchProvider batchOrder = null;
        LookUpProvider lookUpProvider = new LookUpProvider();
        PurchaseOrderProvider purchaseOrderProvider = null;
        ProjectProvider projectProvider = null;
        CompanyVProvider companyVProvider = new CompanyVProvider();
        StoreProvider storeProvider = new StoreProvider();
        PurchaseOrder po = new PurchaseOrder();
        Project pr = new Project();
       
        string user = string.Empty;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public BatchController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            batchOrder = new BatchProvider(user, httpContextAccessor);
            purchaseOrderProvider = new PurchaseOrderProvider(user, httpContextAccessor);
            projectProvider = new ProjectProvider(httpContextAccessor);
        }
        public IActionResult Index(BatchSearchForm Requestmodel)
        {
            BatchSearchForm returnmodel = new BatchSearchForm();
            BatchSearch batchModel = new BatchSearch();
            if (Requestmodel.searchFilter != null)
            {
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY", Requestmodel.searchFilter.StructureType);
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", Requestmodel.searchFilter.StructureSubType);
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", Requestmodel.searchFilter.AssetType);
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", Requestmodel.searchFilter.AssetSpecification);
                ViewBag.Uom = lookUpProvider.GetSelectList("UOM", Requestmodel.searchFilter.Uom);
                ViewBag.UsageUom = lookUpProvider.GetSelectList("UOM", Requestmodel.searchFilter.UsageUom);
                ViewBag.Users = lookUpProvider.GetUserData(); 
                ViewBag.PurchaseOrderNo = purchaseOrderProvider.GetUserProjectPurchaseSelectList(Requestmodel.searchFilter.PurchaseOrderId.ToString());
                ViewBag.PurchaseProject = projectProvider.GetSelectList(Requestmodel.searchFilter.PurchaseProject.ToString());
                ViewBag.PurchaseStore = storeProvider.GetSelectListPro(0, Requestmodel.searchFilter.PurchaseProject, Requestmodel.searchFilter.PurchaseStore.ToString());
                returnmodel.filterEnabled = true;
            }
            else
            {
                Requestmodel.searchFilter = new BatchSearch();
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY");
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST");
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY");
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS");
                ViewBag.Uom = lookUpProvider.GetSelectList("UOM");
                ViewBag.UsageUom = lookUpProvider.GetSelectList("UOM");
                ViewBag.Users = lookUpProvider.GetUserData(); ;
                ViewBag.PurchaseOrderNo = purchaseOrderProvider.GetUserProjectPurchaseSelectList();
                ViewBag.PurchaseProject = projectProvider.GetSelectList();
            }
            IEnumerable<BatchSearch> list = batchOrder.GetBatchSearch(Requestmodel.searchFilter).OrderByDescending(l => l.Id);
            returnmodel.resultList = list;
            return View(returnmodel);
        }

        public ActionResult POModification(PurchaseOrder PO)
        {
            return Ok(purchaseOrderProvider.AddPurchaseOrder(PO));
        }

        public PurchaseOrder POGet(PurchaseOrder PO)
        {
            po.Guid = PO.Guid;
            return purchaseOrderProvider.GetAllPurchaseOrder(po).FirstOrDefault();
        }

        //public SelectListItem POCompanyByProject(Project project) //SelectListItem
        //{
        //    pr.Guid = project.Guid;

        //    return projectProvider.GetCompanyByProject((pr.Guid).ToString());
        //}

        public List<SelectListItem> POStoreByProject(Project project)
        {
            return ViewBag.PurchaseStore = storeProvider.GetSelectListPro(0, project.Guid);
        }

        public async Task<IActionResult> BatchOps(BatchSearch model)
        {

            if (model.Guid == Guid.Empty)
            {
                model.PurchaseOrderDate = Convert.ToDateTime(DateTime.Now.ToString("MM/dd/yyyy HH:mm"), CultureInfo.InvariantCulture);
                model.InvoiceDate = Convert.ToDateTime(DateTime.Now.ToString("MM/dd/yyyy HH:mm"), CultureInfo.InvariantCulture);
                model.ReceivedDate = Convert.ToDateTime(DateTime.Now.ToString("MM/dd/yyyy HH:mm"), CultureInfo.InvariantCulture);
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY");
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST");
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY");
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS");
                ViewBag.Uom = lookUpProvider.GetSelectList("UOM");
                ViewBag.UsageUom = lookUpProvider.GetSelectList("UOM");
                ViewBag.Users = lookUpProvider.GetUserData(); ;
                ViewBag.PurchaseOrderNo = purchaseOrderProvider.GetUserProjectPurchaseSelectList();
                ViewBag.PurchaseProject = projectProvider.GetSelectList();
                ViewBag.CompanyName = companyVProvider.GetSelectList(0);
                ViewBag.PurchaseStore = storeProvider.GetSelectListPro(0, new Guid(), null);
                return View(model);
            }
            else
            {
                IEnumerable<BatchSearch> BatchList = batchOrder.GetAllBatches(model);
                var result = BatchList.FirstOrDefault();
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY", result.StructureType.ToString());
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", result.StructureSubType.ToString());
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", result.AssetType.ToString());
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", result.AssetSpecification.ToString());
                ViewBag.Uom = lookUpProvider.GetSelectList("UOM", result.Uom.ToString());
                ViewBag.UsageUom = lookUpProvider.GetSelectList("UOM", result.UsageUom.ToString());
                ViewBag.Users = lookUpProvider.GetUserData(result.ReceivedBy);
                ViewBag.PurchaseOrderNo = purchaseOrderProvider.GetUserProjectPurchaseSelectList(result.PurchaseOrderId.ToString());
                ViewBag.PurchaseProject = projectProvider.GetSelectList(result.PurchaseProject.ToString());
                ViewBag.CompanyName = companyVProvider.GetSelectList(0, result.Company.ToString());
                ViewBag.PurchaseStore = storeProvider.GetSelectListPro(0, result.PurchaseProject, result.PurchaseStore.ToString());
                return View(result);

            }

        }
        public ActionResult BatchModification(BatchSearch batchModel)
        {
            ResponseBody batchStatus = batchOrder.BatchModifications(batchModel);
            po.Guid = batchModel.PurchaseOrderId;
            po.RecordStatus = 1;
            po.Company = batchModel.Company;
            po.PurchaseProject = batchModel.PurchaseProject;
            po.PurchaseStore = batchModel.PurchaseStore;
            po.PurchaseOrderDate = batchModel.PurchaseOrderDate;
            ResponseBody Postatus = purchaseOrderProvider.UpdatePurchaseOrder(po);
            return Ok(batchStatus);
        }
    }
}
