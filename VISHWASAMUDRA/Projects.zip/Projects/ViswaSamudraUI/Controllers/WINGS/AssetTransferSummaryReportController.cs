﻿using DocumentFormat.OpenXml.EMMA;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class AssetTransferSummaryReportController : Controller
    {
        ReportDetails Provider = new ReportDetails();
        AssetProvider assetprovider;
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectProvider projectProvider = null;
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        TableHelper TableHelper = new TableHelper();
        public AssetTransferSummaryReportController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetprovider = new AssetProvider(user, httpContextAccessor);
            projectProvider = new ProjectProvider(httpContextAccessor);
        }
        public IActionResult Index(AssetTransferSummaryReport requestModel)
        {
           
            ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", requestModel.ASSET_TYPE.ToString());
            ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", requestModel.ASSET_SPECIFICATION.ToString());
            ViewBag.FromProject = projectProvider.GetSelectList(requestModel.FROM_PROJECT.ToString());
            ViewBag.ToProject = projectProvider.GetSelectList(requestModel.TO_PROJECT.ToString());
            if (requestModel.FROM_PROJECT == null && requestModel.ASSET_SPECIFICATION == null && requestModel.TO_PROJECT == null
                 && requestModel.ASSET_TYPE == null)
            {
                requestModel.filterEnabled = false;

            }
            else
            {

                requestModel.filterEnabled = true;
            }
            List<AssetTransferSummaryReport> assetTransferSummaryReports= Provider.GetAssetTransferSummeryReport(requestModel);
            ViewBag.HtmlStr = ProjectHtml(assetTransferSummaryReports).Result.ToString();
            return View(requestModel);
        }

        public async Task<string> ProjectHtml(List<AssetTransferSummaryReport>  assetTransferSummaryReports)
        {
           
            List<AssetTransferRenderType> rtypelist = new List<AssetTransferRenderType>();
            foreach (var Item in assetTransferSummaryReports)
            {
                AssetTransferRenderType render = new AssetTransferRenderType();
                render.FROM_PROJECT = Item.FROM_PROJECT;
                render.FROM_PROJECT_NAME = Item.FROM_PROJECT_NAME;
                render.TO_PROJECT = Item.TO_PROJECT;
                render.TO_PROJECT_NAME = Item.TO_PROJECT_NAME;
                render.ASSET_TYPE = Item.ASSET_TYPE;
                render.ASSET_TYPE_NAME = Item.ASSET_TYPE_NAME;
                render.ASSET_SPECIFICATION = Item.ASSET_SPECIFICATION;
                render.ASSET_SPECIFICATION_NAME = Item.ASSET_SPECIFICATION_NAME;
                render.RECEIPT_QUANTITY = Item.RECEIPT_QUANTITY;
                render.ISSUED_QUANTITY = Item.ISSUED_QUANTITY;
                rtypelist.Add(render);
            }
            return GetTableHtml(rtypelist);
        }

        public string GetTableHtml(List<AssetTransferRenderType> drp)
        {
            string data = "";
            data = data + TableHelper.TableStart() + TableHeader();
            data = data + "<tbody>";
            int i = 1;

            foreach (var item in drp)
            {
                if (item.RECEIPT_QUANTITY == null)
                {
                    item.RECEIPT_QUANTITY = 0;
                }
                if (item.ISSUED_QUANTITY == null)
                {
                    item.ISSUED_QUANTITY = 0;
                }
                data = data + "<tr>";
                    data = data + "<td>" + i.ToString() + "</td> ";
                    data = data + "<td>" + item.FROM_PROJECT_NAME + "</td> ";
                    data = data + "<td>" + item.TO_PROJECT_NAME + "</td> ";
                    data = data + "<td>" + item.ASSET_TYPE_NAME + "</td> ";
                    data = data + "<td>" + item.ASSET_SPECIFICATION_NAME + "</td> ";
                    data = data + "<td>" + item.RECEIPT_QUANTITY+ "</td> ";
                    data = data + "<td>" + item.ISSUED_QUANTITY + "</td> ";
                    data = data + " </tr>";
                
                i++;
            }
            data = data + "</tbody>";
            data = data + "</table>";
            return data;
            
            
        }
        public string TableStart() => $"<table id='AssetTransfersummaryTable' class='table table-striped table-bordered nowrap'>";
        public string TableHeader()
        {
            
                return
                    "<thead>" +
                    "<tr>" +
                    "<th>Sno</th>" +
                    "<th>From Project</th>" +
                    "<th>To Project</th>" +
                    "<th>Asset Type</th>" +
                    "<th>Asset Specification</th>" +
                    "<th>Transfered Qty</th>" +
                    "<th>Return Qty</th>" +
                    "</tr>" +
                    "</thead>";


        }
    }
}
