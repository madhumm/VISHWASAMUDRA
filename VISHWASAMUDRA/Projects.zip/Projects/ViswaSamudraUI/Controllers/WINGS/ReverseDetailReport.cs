﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Drawing;
using System.Reflection;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class ReverseDetailReport : Controller
    {
        ReportDetails Provider = new ReportDetails();   
        TableHelper TableHelper = new TableHelper();
        public IActionResult Index()
        {
            IEnumerable<R_ProjectReport> drp = Provider.GetRevSummaryReport();
            string data = "";
            data = data + TableHelper.TableStart() + TableHelper.TableHeader("Project","Code");
            data = data + "<tbody>";
            int i = 1;
            foreach (var item in drp)
            {
                data = data + "<tr>";
                data = data + TableHelper.CreateChildLink(item.PROJECT_NAME + "_Link" + i.ToString());
                data = data + "<td>" + i.ToString() + "</td> ";
                data = data + "<td>" + item.PROJECT_CODE + "</td> ";
                data = data + "<td>" + item.PROJECT_NAME + "</td> ";
                data = data + "<td>" + item.TOTAL + "</td> ";
                data = data + "<td>" + item.AVAILABLE + "</td> ";
                data = data + "<td>" + item.UNDER_USE + "</td> ";
                data = data + "<td>" + item.TRFR_INWARD + "</td> ";
                data = data + "<td>" + item.TRFR_OUTWARD + "</td> ";
                data = data + "<td>" + item.UNDER_REPAIR + "</td> ";
                data = data + "<td>" + item.UNDER_SCRAP + "</td> ";
               
                data = data + " </tr>";

                data = data + "<tr>";
                data = data + TableHelper.innertablehead(item.PROJECT_NAME + "_Link" + i.ToString(), 1);
                data = data + TableHelper.TableHeader("Store","Code");
                int j = 1;
                foreach (var store in item.storeReport)
                {
                    data = data + "<tr>";
                    data = data + TableHelper.CreateChildLink(store.STORE_NAME + "_Link" + j.ToString());
                    data = data + "<td>" + j.ToString() + "</td> ";
                    data = data + "<td>" + store.STORE_CODE + "</td> ";
                    data = data + "<td>" + store.STORE_NAME + "</td> ";
                    data = data + "<td>" + store.TOTAL + "</td> ";
                    data = data + "<td>" + store.AVAILABLE + "</td> ";
                    data = data + "<td>" + store.UNDER_USE + "</td> ";
                    data = data + "<td>" + store.TRFR_INWARD + "</td> ";
                    data = data + "<td>" + store.TRFR_OUTWARD + "</td> ";
                    data = data + "<td>" + store.UNDER_REPAIR + "</td> ";
                    data = data + "<td>" + store.UNDER_SCRAP + "</td> ";
                    data = data + " </tr>";

                    data = data + "<tr>";
                    data = data + TableHelper.innertablehead(store.STORE_NAME + "_Link" + j.ToString(), 2);
                    data = data + TableHelper.TableHeader("Structure");
                    int k = 1;
                    foreach (var structure in store.structureReport)
                    {
                        data = data + "<tr>";
                        data = data + TableHelper.CreateChildLink(structure.STRUCTURE + "_Link" + k.ToString());
                        data = data + "<td>" + k.ToString() + "</td> ";
                        data = data + "<td>" + structure.STRUCTURE + "</td> ";
                        data = data + "<td>" + structure.TOTAL + "</td> ";
                        data = data + "<td>" + structure.AVAILABLE + "</td> ";
                        data = data + "<td>" + structure.UNDER_USE + "</td> ";
                        data = data + "<td>" + structure.TRFR_INWARD + "</td> ";
                        data = data + "<td>" + structure.TRFR_OUTWARD + "</td> ";
                        data = data + "<td>" + structure.UNDER_REPAIR + "</td> ";
                        data = data + "<td>" + structure.UNDER_SCRAP + "</td> ";
                        
                        data = data + "</tr>";

                        data = data + "<tr>";
                        data = data + TableHelper.innertablehead(structure.STRUCTURE + "_Link" + k.ToString(), 3);
                        data = data + TableHelper.TableHeader("Sub Structure");
                        int l = 1;
                        foreach (var substructure in structure.subStructureReport)
                        {
                            data = data + "<tr>";
                            data = data + TableHelper.CreateChildLink(substructure.SUB_STRUCTURE + "_Link" + l.ToString());
                            data = data + "<td>" + l.ToString() + "</td> ";
                            data = data + "<td>" + substructure.SUB_STRUCTURE + "</td> ";
                            data = data + "<td>" + substructure.TOTAL + "</td> ";
                            data = data + "<td>" + substructure.AVAILABLE + "</td> ";
                            data = data + "<td>" + substructure.UNDER_USE + "</td> ";
                            data = data + "<td>" + substructure.TRFR_INWARD + "</td> ";
                            data = data + "<td>" + substructure.TRFR_OUTWARD + "</td> ";
                            data = data + "<td>" + substructure.UNDER_REPAIR + "</td> ";
                            data = data + "<td>" + substructure.UNDER_SCRAP + "</td> ";
                           
                            data = data + " </tr>";

                            data = data + "<tr>";
                            data = data + TableHelper.innertablehead(substructure.SUB_STRUCTURE + "_Link" + l.ToString(), 4);
                            data = data + TableHelper.TableHeader("Asset Type");

                            int m = 1;
                            foreach (var finassetType in substructure.assertTypeReport)
                            {
                                data = data + "<tr>";
                                data = data + CreateAssetSpecChildLink(finassetType);
                                data = data + "<td>" + m.ToString() + "</td> ";                                
                                data = data + "<td>" + finassetType.ASSET_TYPE + "</td> ";
                                data = data + "<td>" + finassetType.TOTAL + "</td> ";
                                data = data + "<td>" + finassetType.AVAILABLE + "</td> ";
                                data = data + "<td>" + finassetType.UNDER_USE + "</td> ";
                                data = data + "<td>" + finassetType.TRFR_INWARD + "</td> ";
                                data = data + "<td>" + finassetType.TRFR_OUTWARD + "</td> ";
                                data = data + "<td>" + finassetType.UNDER_REPAIR + "</td> ";
                                data = data + "<td>" + finassetType.UNDER_SCRAP + "</td> ";
                               
                                data = data + " </tr>";
                                m++;
                            }
                            data = data + "</tbody>";
                            data = data + "</table>";
                        }
                        data = data + "</tbody>";
                        data = data + "</table>";
                        k++;
                    }
                    data = data + "</tbody>";
                    data = data + "</table>";
                    j++;
                }
                data = data + "</tbody>";
                data = data + "</table>";
                i++;
            }
            data = data + "</tbody>";
            data = data + "</table>";
            ViewBag.HtmlStr = data.Replace("'", @"""").Replace("$SC", "'");
            return View();
        }

        public string CreateAssetSpecChildLink(R_AssertTypeReport rasp)
        {
            return "<td>" +
                "<a class='feather icon-eye' onclick='openassetspecdetails($SC" + rasp.STRUCTURE + "$SC,$SC" + rasp.SUB_STRUCTURE + "$SC," +
                "$SC" + rasp.ASSET_TYPE + "$SC,$SC" + rasp.STORE_NAME + "$SC,$SC" + rasp.STORE_CODE + "$SC,$SC" + rasp.PROJECT_NAME + "$SC,$SC" + rasp.PROJECT_CODE + "$SC); return false;'></a>" +
                "</td>";
        }

        public async Task<string> ShowAssetSpec(R_AssertTypeReport rasp)
        {
            R_AssertSpecReport rspt = new R_AssertSpecReport();
            rspt.STRUCTURE = rasp.STRUCTURE;
            rspt.SUB_STRUCTURE = rasp.SUB_STRUCTURE;
            rspt.ASSET_TYPE = rasp.ASSET_TYPE;
            rspt.STORE_CODE = rasp.STORE_CODE;
            rspt.STORE_NAME = rasp.STORE_NAME;
            rspt.PROJECT_NAME = rasp.PROJECT_NAME;
            rspt.PROJECT_CODE = rasp.PROJECT_CODE;

            IEnumerable<R_AssertSpecReport> drp = Provider.GetAssetSpecSummaryReport(rspt);
            string data = "";
            data = data + TableHelper.TableStart() + TableHelper.TableHeader("Asset Specification");
            data = data + "<tbody>";
            int i = 1;

            foreach (var item in drp)
            {
                data = data + "<tr>";
                data = data + "<td></td> ";
                data = data + "<td>" + i.ToString() + "</td> ";
                data = data + "<td>" + item.ASSET_SPEC + "</td> ";               
                data = data + "<td>" + item.TOTAL + "</td> ";
                data = data + "<td>" + item.AVAILABLE + "</td> ";
                data = data + "<td>" + item.UNDER_USE + "</td> ";
                data = data + "<td>" + item.TRFR_INWARD + "</td> ";
                data = data + "<td>" + item.TRFR_OUTWARD + "</td> ";
                data = data + "<td>" + item.UNDER_REPAIR + "</td> ";
                data = data + "<td>" + item.UNDER_SCRAP + "</td> ";
              
                data = data + " </tr>";
                i++;
            }
            data = data + "</tbody>";
            data = data + "</table>";
            return data;
        }


    }
}
