﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using ViswasamudraCommonObjects.Asset;
using ViswaSamudraUI.Providers.Assets;
using VSManagement.IOModels.DropDown;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class ApprovedRequistionDetailReportController : Controller
    {
        ReportDetails Provider = new ReportDetails();
        AssetProvider assetprovider;
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectProvider projectProvider = null;

        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        TableHelper TableHelper = new TableHelper();
        public ApprovedRequistionDetailReportController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetprovider = new AssetProvider(user, httpContextAccessor);
            projectProvider = new ProjectProvider(httpContextAccessor);
        }

        public IActionResult Index(ApprovedRequisitionDetailReport requestModel)
        {
            if (requestModel != null)
            {
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY", requestModel.STRUCTURE_TYPE.ToString());
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", requestModel.STRUCTURE_SUB_TYPE.ToString());
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", requestModel.ASSET_TYPE.ToString());
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", requestModel.ASSET_SPECIFICATION.ToString());
                ViewBag.PurchaseProject = projectProvider.GetSelectList(requestModel.PROJECT.ToString());
                if (requestModel.PROJECT == null && requestModel.ASSET_SPECIFICATION == null && requestModel.ASSET_TYPE == null
                   && requestModel.STRUCTURE_TYPE == null && requestModel.STRUCTURE_SUB_TYPE == null)
                {
                    requestModel.filterEnabled = false;

                }
                else
                {

                    requestModel.filterEnabled = true;
                }
            }
            else
            {
                requestModel = new ApprovedRequisitionDetailReport();
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY", "");
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", "");
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", "");
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", "");
                ViewBag.PurchaseProject = projectProvider.GetSelectList("0", "");
                requestModel.filterEnabled = false;
            }
            if (string.IsNullOrEmpty(requestModel.REPORT_TYPE) || requestModel.REPORT_TYPE == "R")
            {
                requestModel.REPORT_TYPE = "R";
                ViewBag.title = "Approved Requistion Detail Report";
            }
            else
            {
                ViewBag.title = "Approved Transfer Detail Report";
            }

            requestModel.approvedRequisitionDetailReport = GetApprovedRequisitionDetailReport(requestModel);

            ViewBag.HtmlStr = GetTableHtml(requestModel.approvedRequisitionDetailReport).ToString();
            return View(requestModel);
        }

        public List<ApprovedRequisitionDetailReport> GetApprovedRequisitionDetailReport(ApprovedRequisitionDetailReport approvedRequisitionDetailReport)
        {            
            return Provider.GetApprovedRequisitionDetailReport(approvedRequisitionDetailReport);
        }

        public string GetTableHtml(List<ApprovedRequisitionDetailReport> drp)
        {
            string data = "";
            data = data + TableHelper.TableStart() + TableHeader();
            data = data + "<tbody>";
            int i = 1;

            foreach (var item in drp)
            {
                data = data + "<tr>";
                data = data + "<td>" + i.ToString() + "</td> ";
                data = data + "<td>" + item.PROJECT_NAME + "</td> ";
                data = data + "<td>" + item.TASK_TYPE_NAME + "</td> ";
                data = data + "<td>" + item.ASSET_REQUISITION_NO + "</td> ";
                data = data + "<td>" + item.STRUCTURE_TYPE_NAME + "</td> ";
                data = data + "<td>" + item.STRUCTURE_SUB_TYPE_NAME + "</td> ";
                data = data + "<td>" + item.ASSET_TYPE_NAME + "</td> ";
                data = data + "<td>" + item.ASSET_SPECIFICATION_NAME + "</td> ";
                data = data + "<td>" + item.REQUESTED_QTY + "</td> ";
                data = data + " </tr>";

                i++;
            }
            data = data + "</tbody>";
            data = data + "</table>";
            return data;


        }
        public string TableHeader()
        {

            return
                "<thead>" +
                "<tr>" +
                "<th>Sno</th>" +
                "<th>Project Name</th>" +
                "<th>Task Type</th>" +
                 "<th>Requestion No</th>" +
                "<th>Structure Type</th>" +
                "<th> Sub Structure Type</th>" +
                "<th>Asset Type</th>" +
                "<th>Asset Specification</th>" +
                "<th>Requested Qty</th>" +
                "</tr>" +
                "</thead>";


        }
    }
}
