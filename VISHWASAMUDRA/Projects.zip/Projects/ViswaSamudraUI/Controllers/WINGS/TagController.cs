﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Filters;
using ViswasamudraCommonObjects.Asset.SearchForms;
using Microsoft.AspNetCore.Http;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class TagController :Controller
    {
        TagProvider provider = null;
        LookUpProvider lookUpProvider = new LookUpProvider();
        Tag aTagSearch = new Tag();

        string user = string.Empty;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public TagController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            provider = new TagProvider(user);
        }
        public IActionResult Index(TagSearchForms requestModel)
        {
            TagSearchForms returnModel = new TagSearchForms();
            if (requestModel.searchFilter != null)
            {
                ViewBag.Status = lookUpProvider.GetSelectListTag("TGS", requestModel.searchFilter.Status);
                returnModel.filterEnabled = true;
            }
            else
            {
                ViewBag.Status = lookUpProvider.GetSelectListTag("TGS");
            }

            IEnumerable<Tag> list = provider.GetTags(requestModel.searchFilter).OrderByDescending(l => l.Id);
            returnModel.resultList = list;
            return View(returnModel);
        }

        public async Task<IActionResult> TagOps(Tag ioModel)
        {
            if (ioModel.Guid == Guid.Empty)
            {
                ViewBag.Status = lookUpProvider.GetSelectListTag("TGS");
                return View(ioModel);
            }
            IEnumerable<Tag> list = provider.GetAllTag(ioModel);
            var tag = list.FirstOrDefault();
            ViewBag.Status = lookUpProvider.GetSelectListTag("TGS", tag.Status);
            return View(tag);
        }

        public ActionResult TagModification(Tag model)
        {
            return Ok(provider.Add(model));
            //return Content(status);
        }

        public IActionResult Delete(Tag model)
        {
            ResponseBody res = provider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
