﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset;
using ViswaSamudraUI.Providers.Assets;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class AssetHealthReportController : Controller
    {
        ReportDetails Provider = new ReportDetails();
        AssetProvider assetprovider;
        LookUpProvider lookUpProvider = new LookUpProvider();
        TagProvider tagProvider = new TagProvider();
        ProjectProvider projectProvider = null;
        StoreProvider storeProvider = new StoreProvider();

        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        TableHelper TableHelper = new TableHelper();
        public AssetHealthReportController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetprovider = new AssetProvider(user, httpContextAccessor);
            projectProvider = new ProjectProvider(httpContextAccessor);
        }

        public IActionResult Index(A_AassetHealthReport requestModel)
        {
            if (requestModel != null)
            {
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY", requestModel.STRUCTURE_TYPE.ToString());
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", requestModel.STRUCTURE_SUB_TYPE.ToString());
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", requestModel.ASSET_TYPE.ToString());
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", requestModel.ASSET_SPECIFICATION.ToString());
                ViewBag.PurchaseProject = projectProvider.GetSelectList(requestModel.PROJECT_CODE.ToString());
                ViewBag.PurchaseStore = storeProvider.GetSelectList(0, "");
                ViewBag.selectTag = tagProvider.GetSelectListWithoutMapped(requestModel.TAG_ID.ToString());
                if (requestModel.PROJECT_CODE == null && requestModel.STORE == null && requestModel.ASSET_SPECIFICATION == null && requestModel.ASSET_TYPE == null
                    && requestModel.STRUCTURE_TYPE == null && requestModel.STRUCTURE_SUB_TYPE == null)
                {
                    requestModel.filterEnabled = false;

                }
                else
                {

                    requestModel.filterEnabled = true;
                }
            }
            else
            {
                requestModel = new A_AassetHealthReport();
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY", "");
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", "");
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", "");
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", "");
                ViewBag.PurchaseProject = projectProvider.GetSelectList("0", "");
                ViewBag.PurchaseStore = storeProvider.GetSelectList(0, "");
                ViewBag.selectTag = tagProvider.GetSelectListWithoutMapped();
                requestModel.filterEnabled = false;
            }
            if (string.IsNullOrEmpty(requestModel.ReportType))
            {
                requestModel.ReportType = "InUse";
            }
            requestModel.AassetHealthReport = GetAssetHealthReport(requestModel);
            if (requestModel.ReportType == "InUse")
            {
                ViewBag.HtmlStr = GetTableHtml(requestModel.AassetHealthReport).ToString();
            }
            else
            {
                ViewBag.HtmlStr=GetScrappedTableHtml(requestModel.AassetHealthReport).ToString();
            }
            return View(requestModel);
        }



        public List<A_AassetHealthReport> GetAssetHealthReport(A_AassetHealthReport HealthModel)
        {
            return Provider.GetAssetHealthReport(HealthModel);
        }

        public string GetTableHtml(List<A_AassetHealthReport> drp)
        {
            string data = "";
            data = data + TableHelper.TableStart() + TableHeader();
            data = data + "<tbody>";
            int i = 1;
            A_AassetHealthReport objA_AassetHealthReport = new A_AassetHealthReport();
            objA_AassetHealthReport.AVAILABLE_TO_USE= drp.Sum(item => Convert.ToInt32(item.AVAILABLE_TO_USE)).ToString();
            objA_AassetHealthReport.IN_USE = drp.Sum(item => Convert.ToInt32(item.IN_USE)).ToString();
            objA_AassetHealthReport.UNDER_REPAIR = drp.Sum(item => Convert.ToInt32(item.UNDER_REPAIR)).ToString();
            objA_AassetHealthReport.TOTAL_QUANTITY = drp.Sum(item => Convert.ToInt32(item.TOTAL_QUANTITY));
            objA_AassetHealthReport.ASSET_SPECIFICATION_NAME = "Total ";
            int colspan = 6;
            foreach (var item in drp)
            {
                data = data + "<tr>";
                data = data + "<td>" + i.ToString() + "</td> ";
                data = data + "<td>" + item.PROJECT_CODE_NAME + "</td> ";
                data = data + "<td>" + item.STORE_NAME + "</td> ";
                data = data + "<td>" + item.STRUCTURE_TYPE_NAME + "</td> ";
                data = data + "<td>" + item.STRUCTURE_SUB_TYPE_NAME + "</td> ";
                data = data + "<td>" + item.ASSET_TYPE_NAME + "</td> ";
                data = data + "<td>" + item.ASSET_SPECIFICATION_NAME + "</td> ";
                data = data + "<td>" + item.AVAILABLE_TO_USE + "</td> ";
                data = data + "<td>" + item.IN_USE + "</td> ";
                data = data + "<td>" + item.UNDER_REPAIR + "</td> ";
                data = data + "<td>" + item.TOTAL_QUANTITY + "</td> ";
                data = data + " </tr>";

                i++;
            }
            data = data + "<tfoot>" +
               "<tr> " +
               "<th rowspan = '1' colspan = '" + colspan.ToString() + "' >  </th> " +
               "<th rowspan = '1' colspan = '1' >" + objA_AassetHealthReport.ASSET_SPECIFICATION_NAME + "</th> " +
               "<th rowspan = '1' colspan = '1' > " + objA_AassetHealthReport.AVAILABLE_TO_USE + " </th> " +
               "<th rowspan = '1' colspan = '1' > " + objA_AassetHealthReport.IN_USE + " </th> " +
               "<th rowspan = '1' colspan = '1' > " + objA_AassetHealthReport.UNDER_REPAIR + " </th> " +
               "<th rowspan = '1' colspan = '1' > " + objA_AassetHealthReport.TOTAL_QUANTITY + " </th> " +
               "</tr>" +
               "</tfoot>";
            data = data + "</tbody>";
            data = data + "</table>";
            return data;

        }
        public string TableStart() => $"<table id='AssetHealthReportTable' class='table table-striped table-bordered nowrap'>";
        public string TableHeader()
        {

            return
                "<thead>" +
                "<tr>" +
                "<th>Sno</th>" +
                "<th>Project Name</th>" +
                "<th>Store Name</th>" +
                "<th>Structure Type</th>" +
                "<th> Sub Structure Type</th>" +
                "<th>Asset Type</th>" +
                "<th>Asset Specification</th>" +
                "<th>Available To use</th>" +
                "<th>In Use</th>" +
                "<th>Under Repair</th>" +
                 "<th>Total Qty</th>" +
                "</tr>" +
                "</thead>";


        }



        public string GetScrappedTableHtml(List<A_AassetHealthReport> drp)
        {
            string data = "";
            data = data + TableHelper.TableStart() + TableScrappedHeader();
            data = data + "<tbody>";
            int i = 1;
            A_AassetHealthReport objA_AassetHealthReport = new A_AassetHealthReport();
            objA_AassetHealthReport.SCRAPPED_QUANTITY = drp.Sum(item => Convert.ToInt32(item.SCRAPPED_QUANTITY));
            int colspan = 6;
            objA_AassetHealthReport.ASSET_SPECIFICATION_NAME = "Total ";
            foreach (var item in drp)
            {
                data = data + "<tr>";
                data = data + "<td>" + i.ToString() + "</td> ";
                data = data + "<td>" + item.PROJECT_CODE_NAME + "</td> ";
                data = data + "<td>" + item.STORE_NAME + "</td> ";
                data = data + "<td>" + item.STRUCTURE_TYPE_NAME + "</td> ";
                data = data + "<td>" + item.STRUCTURE_SUB_TYPE_NAME + "</td> ";
                data = data + "<td>" + item.ASSET_TYPE_NAME + "</td> ";
                data = data + "<td>" + item.ASSET_SPECIFICATION_NAME + "</td> ";
                data = data + "<td>" + item.SCRAPPED_QUANTITY + "</td> ";
                data = data + " </tr>";

                i++;
            }
            data = data + "<tfoot>" +
                "<tr> " +
                "<th rowspan = '1' colspan = '" + colspan.ToString() + "' >  </th> " +
                "<th rowspan = '1' colspan = '1' >" + objA_AassetHealthReport.ASSET_SPECIFICATION_NAME + "</th> " +
                "<th rowspan = '1' colspan = '1' > " + objA_AassetHealthReport.SCRAPPED_QUANTITY + " </th> " +
                "</tr>" +
                "</tfoot>";
            data = data + "</tbody>";
            data = data + "</table>";
            return data;


        }
        public string TableScrappedStart() => $"<table id='AssetHealthReportTable' class='table table-striped table-bordered nowrap'>";
        public string TableScrappedHeader()
        {

            return
                "<thead>" +
                "<tr>" +
                "<th>Sno</th>" +
                "<th>Project Name</th>" +
                "<th>Store Name</th>" +
                "<th>Structure Type</th>" +
                "<th> Sub Structure Type</th>" +
                "<th>Asset Type</th>" +
                "<th>Asset Specification</th>" +
                "<th>Scrapped Quantity</th>" +
               
                "</tr>" +
                "</thead>";


        }
    }
}
