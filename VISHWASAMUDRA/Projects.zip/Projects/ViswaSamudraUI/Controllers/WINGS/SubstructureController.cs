﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers.Assets;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class SubstructureController : Controller
    {
        string user = string.Empty;
        SubstructureProvider provider = null;
        private readonly IHttpContextAccessor _httpContextAccessor;
        StructureProvider structureProvider = new StructureProvider();
        public SubstructureController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            provider = new SubstructureProvider(user);
          
        }
        public IActionResult Index(SubStructureSearch requestModel)
        {
            SubStructureSearch returnModel = new SubStructureSearch();
            if (requestModel.searchFilter != null)
            {
                 ViewBag.structure = structureProvider.GetSelectList( requestModel.searchFilter.Structure.ToString());
                returnModel.filterEnabled = true;
            }
            else
            {
                ViewBag.structure = structureProvider.GetSelectList();
            }

            IEnumerable<Substructure> list = provider.GetAllStructures(requestModel.searchFilter).OrderByDescending(l => l.Id);
            
            returnModel.resultList = list;
            return View(returnModel);
        }

        public async Task<IActionResult> SubStructureOps(Substructure ioModel)
        {
            if (ioModel.Guid == Guid.Empty)
            {
                ViewBag.structure = structureProvider.GetSelectList();
                return View(ioModel);
            }
            else
            {
                IEnumerable<Substructure> list = provider.GetAllStructures(ioModel);
                var substructure = list.FirstOrDefault();
                ViewBag.structure = structureProvider.GetSelectList(substructure.Structure.ToString());
                return View(substructure);
            }
        }

        public ActionResult SubStructureModification(Substructure model)
        {
            return Ok(provider.Add(model));
        }

        public IActionResult Delete(Substructure model)
        {
            ResponseBody res = provider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
