﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class AssetTransferController : Controller
    {
        string user = string.Empty;
        //AssetProvider provider = new AssetProvider();
        List<AssetTransferDetails> arDetails = new List<AssetTransferDetails>();
        AssetTransferHeader aHeader = new AssetTransferHeader();
        AssetTransfer aTransfer = new AssetTransfer();
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectProvider projectProvider =new ProjectProvider();
        ProjectProvider UserprojectProvider = null;
        AssetTransferProvider assetTransferProvider = null;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public AssetTransferController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetTransferProvider = new AssetTransferProvider(user, _httpContextAccessor);
            UserprojectProvider = new ProjectProvider(httpContextAccessor);
        }

        public IActionResult Index(AssetTransferSearch requestModel)
        {
            AssetTransferSearch returnModel = new AssetTransferSearch();

            if (requestModel.searchFilter != null)
            {
                ViewBag.RequestedUsers = lookUpProvider.GetActiveUserDropDownbyProject(requestModel.searchFilter.header.ToProject,requestModel.searchFilter.header.RequestedBy.ToString());
                ViewBag.ApproveUsers = lookUpProvider.GetActiveUserDropDownbyProject(requestModel.searchFilter.header.ToProject,requestModel.searchFilter.header.ApprovedBy);
                ViewBag.TaskType = lookUpProvider.GetSelectList("TTY", requestModel.searchFilter.header.TaskType.ToString());
                ViewBag.FromProject = projectProvider.GetSelectList(requestModel.searchFilter.header.FromProject.ToString());
                ViewBag.ToProject = UserprojectProvider.GetSelectList(requestModel.searchFilter.header.ToProject.ToString(), requestModel.searchFilter.header.FromProject.ToString());

                returnModel.filterEnabled = true;
            }
            else
            {
               
                ViewBag.RequestedUsers = lookUpProvider.GetActiveUserDropDownbyProject(null, null);
                ViewBag.ApproveUsers = lookUpProvider.GetActiveUserDropDownbyProject(null, null);
                ViewBag.TaskType = lookUpProvider.GetSelectList("TTY");
                ViewBag.FromProject = projectProvider.GetSelectList();
                ViewBag.ToProject = UserprojectProvider.GetSelectList();
            }
            IEnumerable<AssetTransfer> list = getdetails(requestModel.searchFilter);

            returnModel.resultList = list; ;
            return View(returnModel);
        }

        public IEnumerable<AssetTransfer> getdetails(AssetTransfer AssetTransfer)
        {
            if (AssetTransfer == null)
            {
                aTransfer.header = aHeader;
                aTransfer.header.RecordStatus = 1;
                return assetTransferProvider.GetAll(aTransfer).OrderByDescending(a => a.header.Id);

            }
            else
            {
                AssetTransfer.header.RecordStatus = 1;
                return assetTransferProvider.GetAll(AssetTransfer).OrderByDescending(a => a.header.Id);

            }

        }

        public ActionResult AssetTransferModification(AssetTransfer model)
        {
            return Ok(assetTransferProvider.Add(model));
        }
        public async Task<IActionResult> AssetTransferOps(AssetTransferHeader model)
        {
            aHeader.Guid = model.Guid;
            aTransfer.header = aHeader;
            AssetTransfer AssetReq = aTransfer;

            if (model.Guid == System.Guid.Empty)
            {
                ViewBag.RequestedUsers = lookUpProvider.GetActiveUserDropDownbyProject(null,null);
                ViewBag.ApproveUsers = lookUpProvider.GetActiveUserDropDownbyProject(null,null);
                ViewBag.TaskType = lookUpProvider.GetSelectList("TTY");
                ViewBag.FromProject = projectProvider.GetSelectList();
                ViewBag.ToProject = UserprojectProvider.GetSelectList();
            }
            else
            {

                AssetReq = assetTransferProvider.GetAll(aTransfer).FirstOrDefault();
                ViewBag.RequestedUsers = lookUpProvider.GetActiveUserDropDownbyProject(AssetReq.header.ToProject,AssetReq.header.RequestedBy.Value.ToString());
                ViewBag.ApproveUsers = lookUpProvider.GetActiveUserDropDownbyProject(AssetReq.header.ToProject,AssetReq.header.ApprovedBy);
                ViewBag.TaskType = lookUpProvider.GetSelectList("TTY", AssetReq.header.TaskType.ToString());
                ViewBag.FromProject = projectProvider.GetSelectList(AssetReq.header.FromProject.ToString());
                ViewBag.ToProject = UserprojectProvider.GetSelectList(AssetReq.header.ToProject.ToString(), AssetReq.header.FromProject.ToString());
            }

            ViewBag.StructureType = lookUpProvider.GetSelectList("STY");
            ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST");
            ViewBag.AssetType = lookUpProvider.GetSelectList("ATY");
            ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS");
            ViewBag.Uom = lookUpProvider.GetSelectList("UOM");

            return View(AssetReq);
        }
        public ActionResult Delete(Guid guid)
        {
            aHeader.Guid = guid;
            aHeader.LastUpdatedDateTime = DateTime.Now;
            aHeader.LastUpdatedBy = user;
            aTransfer.header = aHeader;
            AssetTransfer AssetReq = aTransfer;
            ResponseBody res = assetTransferProvider.Delete(AssetReq);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }


        }
    }
}
