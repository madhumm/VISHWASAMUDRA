﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using ViswasamudraCommonObjects.Asset;
using ViswaSamudraUI.Providers.Assets;
using VSManagement.IOModels.DropDown;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class PendingRequistionDetailReportController : Controller
    {
        ReportDetails Provider = new ReportDetails();
        AssetProvider assetprovider;
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectProvider projectProvider = null;
        StoreProvider storeProvider = new StoreProvider();

        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public PendingRequistionDetailReportController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetprovider = new AssetProvider(user, httpContextAccessor);
            projectProvider = new ProjectProvider(httpContextAccessor);
        }

        public IActionResult Index(PendingRequisitionDetailReport requestModel)
        {
            if (requestModel != null)
            {
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY", requestModel.STRUCTURE_TYPE.ToString());
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", requestModel.STRUCTURE_SUB_TYPE.ToString());
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", requestModel.ASSET_TYPE.ToString());
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", requestModel.ASSET_SPECIFICATION.ToString());
                ViewBag.PurchaseProject = projectProvider.GetSelectList(requestModel.PROJECT.ToString());
                ViewBag.PurchaseStore = storeProvider.GetSelectList(0, "");
            }
            else
            {
                requestModel = new PendingRequisitionDetailReport();
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY", "");
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", "");
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", "");
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", "");
                ViewBag.PurchaseProject = projectProvider.GetSelectList("0", "");
                ViewBag.PurchaseStore = storeProvider.GetSelectList(0, "");
            }

            requestModel.pendingRequisitionDetailReport = GetPendingRequisitionDetailReport(requestModel);
            return View(requestModel);
        }

        public List<PendingRequisitionDetailReport> GetPendingRequisitionDetailReport(PendingRequisitionDetailReport pendingRequisitionDetailReport)
        {            
            return Provider.GetPendingRequisitionDetailReport(pendingRequisitionDetailReport);
        }
    }
}
