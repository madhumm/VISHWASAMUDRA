﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Providers.Assets;
using VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class AssetController : Controller
    {
        AssetProvider assetprovider;
        LookUpProvider lookUpProvider = new LookUpProvider();
        TagProvider tagProvider = new TagProvider();
        ProjectProvider projectProvider = new ProjectProvider();
        StoreProvider storeProvider = new StoreProvider();
        Asset asset = new Asset();
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public AssetController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetprovider = new AssetProvider(user, httpContextAccessor);
            projectProvider = new ProjectProvider(httpContextAccessor);
        }

        public IActionResult Index(AssetSearch requestModel)
        {
            AssetSearch returnModel = new AssetSearch();
            asset.RecordStatus = 1;
            ViewBag.selectTag = tagProvider.GetSelectListWithoutMapped();
          
            if (requestModel.searchFilter != null)
            {
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY", requestModel.searchFilter.StructureType.ToString());
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", requestModel.searchFilter.StructureSubType.ToString());
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", requestModel.searchFilter.AssetType.ToString());
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", requestModel.searchFilter.AssetSpecification.ToString());
                ViewBag.AssetStatus = lookUpProvider.GetSelectList("AST", requestModel.searchFilter.AssetStatus.ToString());
                ViewBag.PurchaseStore = storeProvider.GetSelectList(0, requestModel.searchFilter.Store.ToString());
                ViewBag.PurchaseProject = projectProvider.GetSelectList(requestModel.searchFilter.ProjectCode.ToString());
                returnModel.filterEnabled = true;
            }
            else
            {
                Asset searchFilter = new Asset();
                requestModel.searchFilter = searchFilter;
                ViewBag.StructureType = lookUpProvider.GetSelectList("STY", "");
                ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", "");
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", "");
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", "");
                ViewBag.AssetStatus = lookUpProvider.GetSelectList("AST", "");
                ViewBag.PurchaseProject = projectProvider.GetSelectList();
                //  ViewBag.PurchaseProject = projectProvider.GetSelectList(requestModel.searchFilter.ProjectCode.ToString());
                ViewBag.PurchaseStore = storeProvider.GetSelectList(0, "");
              //  IEnumerable<Asset> list = assetprovider.GetAll(asset);
            }
            // IEnumerable<Asset> list = assetprovider.GetAll(requestModel.searchFilter);
            requestModel.searchFilter.RecordStatus = 1;
            IEnumerable<Asset> list = assetprovider.GetAll(requestModel.searchFilter);
            returnModel.resultList = list;
            return View(returnModel);
        }

        public ActionResult AssetModification(Asset model)
        {
            return Ok(assetprovider.Add(model));
        }        

        public async Task<IActionResult> AssetOps(Asset model)
        {
            asset.Guid = model.Guid;
            asset.RecordStatus = 1;

            var result = assetprovider.GetAll(asset).FirstOrDefault();
            if(result.TagId == null)
            ViewBag.selectTag = tagProvider.GetSelectListWithoutMapped();
            else 
            ViewBag.selectTag = tagProvider.GetSelectListwithExisted((System.Guid)result.TagId);

            ViewBag.StructureType = lookUpProvider.GetSelectList("STY", result.StructureType.ToString());
            ViewBag.StructureSubType = lookUpProvider.GetSelectList("SST", result.StructureSubType.ToString());
            ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", result.AssetType.ToString());
            ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", result.AssetSpecification.ToString());
            ViewBag.PurchaseProject = projectProvider.GetSelectList(result.ProjectCode.ToString());
            ViewBag.PurchaseStore = storeProvider.GetSelectList(0, result.Store.ToString());


            return View(result);
        }
    }
}
