﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers.Assets;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class StructureController : Controller
    {
        string user = string.Empty;
        StructureProvider provider = null;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public StructureController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            provider = new StructureProvider(user);
        }
        public IActionResult Index(StructureSearch requestModel)
        {
            StructureSearch returnModel = new StructureSearch();
            if (requestModel.searchFilter != null)
            {
                // ViewBag.Status = lookUpProvider.GetSelectList("TGS", requestModel.searchFilter.Status);
                returnModel.filterEnabled = true;
            }
            else
            {
                // ViewBag.Status = lookUpProvider.GetSelectList("TGS");
            }

            IEnumerable<Structure> list = provider.GetAllStructures(requestModel.searchFilter).OrderByDescending(l => l.Id);

            returnModel.resultList = list;
            return View(returnModel);

        }
        public async Task<IActionResult> StructureOps(Structure ioModel)
        {
            if (ioModel.Guid == Guid.Empty)
            {
                //ViewBag.Status = lookUpProvider.GetSelectList("TGS");
                return View(ioModel);
            }
            else
            {
                IEnumerable<Structure> list = provider.GetAllStructures(ioModel);
                var Structure = list.FirstOrDefault();
                //ViewBag.Status = lookUpProvider.GetSelectList("TGS", tag.Status);
                return View(Structure);
            }
        }

        public ActionResult StructureModification(Structure model)
        {
            model.TaskType = new Guid();
            return Ok(provider.Add(model));
        }

        public IActionResult Delete(Structure model)
        {
            ResponseBody res = provider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
