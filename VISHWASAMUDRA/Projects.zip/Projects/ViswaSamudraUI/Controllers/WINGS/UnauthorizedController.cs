﻿using Microsoft.AspNetCore.Mvc;
using VSManagement.IOModels;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class UnauthorizedController : Controller
    {
        public IActionResult Index()
        {
            HttpContext.Session.Clear();
            return View();
        }
    }
}
