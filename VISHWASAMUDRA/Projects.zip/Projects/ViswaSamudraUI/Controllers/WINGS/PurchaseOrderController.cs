﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.Net.Http.Headers;
using System.Net.Http;
using System.Text.Json.Serialization;
using System.Threading.Tasks;
using ViswaSamudraUI.Models;
using Newtonsoft.Json;
using VSAssetManagement.IOModels;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Filters;
using Microsoft.AspNetCore.Http;
using VSManagement.IOModels.DropDown;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]

    public class PurchaseOrderController : Controller
    {
        string user = string.Empty;
        PurchaseOrderProvider purchaseOrder = null;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public PurchaseOrderController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            purchaseOrder = new PurchaseOrderProvider(user);
        }
        public async Task<IActionResult> Index()
        {
            List<PurchaseOrder> poList = purchaseOrder.GetAllPurchaseOrder();
            return View(poList);
        }

        public async Task<IActionResult> PoGetDetailById(PurchaseOrder PoIoModel)
        {
            if (PoIoModel.Guid == Guid.Empty)
            {
                return View("PoOps", PoIoModel);
            }
            IEnumerable<PurchaseOrder> poList = purchaseOrder.GetAllPurchaseOrder(PoIoModel);
            return View("PoOps", poList.FirstOrDefault());
        }

        public ActionResult PoModification(PurchaseOrder PoIoModel)
        {
            return Ok(purchaseOrder.AddPurchaseOrder(PoIoModel));
            //return Content(poStatus);
        }
    }
}