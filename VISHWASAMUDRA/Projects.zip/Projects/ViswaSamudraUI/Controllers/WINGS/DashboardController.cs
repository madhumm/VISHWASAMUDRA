﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Filters;

namespace ViswaSamudraUI.Controllers.WINGS
{
    
    public class DashboardController : Controller
    {
        ReportDetails Provider = new ReportDetails();
        public IActionResult Index()
        {
            return View();
        }

        public async Task<IEnumerable<string>> GetDashboardData()
        {
            return Provider.GetStoreSummaryReport();
        }
    }
}
