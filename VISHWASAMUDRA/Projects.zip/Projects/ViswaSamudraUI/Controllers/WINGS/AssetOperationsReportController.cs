﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.IO.Pipelines;
using System.Reflection;
using ViswasamudraCommonObjects.Asset;
using ViswaSamudraUI.Providers.Assets;
using static Microsoft.AspNetCore.Razor.Language.TagHelperMetadata;

namespace ViswaSamudraUI.Controllers.WINGS
{
    public class AssetOperationsReportController : Controller
    {
        ReportDetails Provider = new ReportDetails();
        AssetProvider assetprovider;
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectProvider projectProvider = new ProjectProvider();
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        TableHelper TableHelper = new TableHelper();
        public AssetOperationsReportController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetprovider = new AssetProvider(user, httpContextAccessor);
        }


        public IActionResult Index(AssetUtilizationSummary requestModel)
        {

            if (requestModel != null)
            {
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", requestModel.ASSET_TYPE.ToString());
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", requestModel.ASSET_SPECIFICATION.ToString());
                ViewBag.PurchaseProject = projectProvider.GetSelectList(requestModel.PROJECT_CODE.ToString());
                if (requestModel.PROJECT_CODE == null && requestModel.ASSET_SPECIFICATION == null && requestModel.ASSET_TYPE == null)
                {
                    requestModel.filterEnabled = false;

                }
                else
                {

                    requestModel.filterEnabled = true;
                }
            }
            else
            {
                requestModel = new AssetUtilizationSummary();
                ViewBag.AssetType = lookUpProvider.GetSelectList("ATY", "");
                ViewBag.AssetSpecification = lookUpProvider.GetSelectList("ATS", "");
                ViewBag.PurchaseProject = projectProvider.GetSelectList("0", "");
                requestModel.filterEnabled = false;

            }
            requestModel.assetUtilizationSummary = Provider.GetAssetUtilizationSummaryReport(requestModel);
            ViewBag.HtmlStr = GetTableHtml(requestModel.assetUtilizationSummary).ToString();
            return View(requestModel);
        }
        public string GetTableHtml(List<AssetUtilizationSummary> drp)
        {
            string data = "";
            data = data + TableHelper.TableStart() + TableHeader();
            data = data + "<tbody>";
            int i = 1;

            foreach (var item in drp)
            {
                string Link_href = "/AssetUtilizationDetailReport?ASSET_TYPE=" + item.ASSET_TYPE + '&' +
                    "ASSET_SPECIFICATION=" + item.ASSET_SPECIFICATION + '&' + "PROJECT_CODE="
                + item.PROJECT_CODE;

                data = data + "<tr>";
                data = data + "<td>" + i.ToString() + "</td> ";
                data = data + "<td>" + item.PROJECT_CODE_NAME + "</td> ";
                data = data + "<td>"+  item.ASSET_TYPE_NAME + "</td> ";
                data = data + "<td>" + "<u><a  title=" + "'Asset Utilization Details'" + " href= " + Link_href + " >" + item.ASSET_SPECIFICATION_NAME + "</a></u>" + "</td> ";
                data = data + "<td>" + item.Utilization + "</td> ";
                data = data + " </tr>";

                i++;
            }
            data = data + "</tbody>";
            data = data + "</table>";
            return data;


        }
        public string TableHeader()
        {

            return
                "<thead>" +
                "<tr>" +
                "<th>Sno</th>" +
                "<th>Project Name</th>" +
                "<th>Asset Type</th>" +
                "<th>Asset Specification</th>" +
                "<th>Utilization %</th>" +
                "</tr>" +
                "</thead>";


        }


    }
}
