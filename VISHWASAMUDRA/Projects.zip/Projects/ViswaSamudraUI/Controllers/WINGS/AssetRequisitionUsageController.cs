﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Asset;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers;
using ViswaSamudraUI.Providers.Assets;
using VSManagement.IOModels.DropDown;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class AssetRequisitionUsageController : Controller
    {
        string user = string.Empty;
        AssetProvider assetprovider;
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectProvider projectProvider = new ProjectProvider();
        private readonly IHttpContextAccessor _httpContextAccessor;
        AssetRequisitionUsageProvider assetRequisitionUsageProvider = null;
        
        public AssetRequisitionUsageController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            assetRequisitionUsageProvider = new AssetRequisitionUsageProvider(user, httpContextAccessor);
            projectProvider = new ProjectProvider(httpContextAccessor);
        }
        public IActionResult Index(AssetRequisitionUsageHeaderSearch requestModel)
        {
            AssetRequisitionUsageHeaderSearch returnModel = new AssetRequisitionUsageHeaderSearch();
            
            if (requestModel.searchFilter != null)
            {
                ViewBag.Project = projectProvider.GetSelectList(requestModel.searchFilter.Project.ToString());
                ViewBag.TaskType = lookUpProvider.GetSelectListTag("TTY", requestModel.searchFilter.Tasktype.ToString());
                returnModel.filterEnabled = true;
            }
            else
            {
                requestModel.searchFilter = new AssetRequisitionUsageHeader();
                ViewBag.Project = projectProvider.GetSelectList();
                ViewBag.TaskType = lookUpProvider.GetSelectListTag("TTY", "");
            }
            IEnumerable<AssetRequisitionUsageHeader> list = assetRequisitionUsageProvider.GetAll(requestModel.searchFilter).OrderByDescending(l => l.Id);
            returnModel.resultList = list;
            return View(returnModel);
        }

        public ActionResult AssetRequisitionUsageOps(AssetRequisitionUsageHeader model)
        {
            ViewBag.Project = projectProvider.GetSelectList();
            ViewBag.TaskType = lookUpProvider.GetSelectListTag("TTY", "");
            ViewBag.AssetIssues = assetRequisitionUsageProvider.GetSelectList("");
            ViewBag.UsedBy = lookUpProvider.GetUserData();
            return View(model);
        }

        public ActionResult AssetUsageModification(AssetRequisitionUsageHeader model)
        {
            return Ok(assetRequisitionUsageProvider.Add(model));
        }

        public ActionResult AssetIssuesbyAssetNo(Guid HeaderID)
        {
            AssetRequisitionIssueDetails model = new AssetRequisitionIssueDetails();
            model.AssetIssueHeaderId = HeaderID;

            return View(assetRequisitionUsageProvider.GetIssussbyIssueno(model));
           
           
        }

        public ActionResult AssetIssuesHeaderDetailsByAssetNo(Guid HeaderID)
        {
            AssetRequisitionIssueHeader model = new AssetRequisitionIssueHeader();
            model.AssetIssueHeaderId = HeaderID;

            return Json(assetRequisitionUsageProvider.GetIssueHeaderDetails(model).FirstOrDefault());



        }

        public IActionResult Delete(AssetRequisitionUsageHeader model)
        {
            ResponseBody res = assetRequisitionUsageProvider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
