﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Providers.HRMS;
using VSManagement.IOModels;
using ResponseBody = ViswaSamudraUI.Models.ResponseBody;

namespace ViswaSamudraUI.Controllers.HRMS
{
    [CheckSession]
    public class UserMenuController : Controller
    {
        UserMenuProvider provider = null;

        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public UserMenuController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            provider = new UserMenuProvider(user);
        }
        public IActionResult Index(Usermenusearch Requestmodel)
        {
            Usermenusearch returnModel = new Usermenusearch();
            ViewBag.Application = provider.GetAreaSelectList();

            if (Requestmodel.searchFilter !=null)
            {
                ViewBag.ParentMenu = provider.GetMenuSelectList(Requestmodel.searchFilter.Parent.ToString(), true, true);
                ViewBag.Roles = provider.GetComboRoles(Requestmodel.searchFilter.Role?.ToString());
                returnModel.filterEnabled = true;
            }
            else
            {
                ViewBag.ParentMenu = provider.GetMenuSelectList(null, false, true);
                ViewBag.Roles = provider.GetComboRoles("");
            }
            IEnumerable<UserMenu> list = provider.GetSearchUserMenu(Requestmodel.searchFilter).OrderByDescending(l => l.Id);
            returnModel.resultList= list;
            return View(returnModel);
        }

        public async Task<IActionResult> UserMenuOps(UserMenu ioModel)
        {
            ViewBag.Application = provider.GetAreaSelectList();
            if (ioModel.Guid == Guid.Empty)
            {
                ViewBag.ParentMenu = provider.GetMenuSelectList(null, false, true);
                ViewBag.Roles = provider.GetComboRoles("");
                return View(ioModel);
            }
            var result = provider.GetAllUserMenu(ioModel).FirstOrDefault();
            ViewBag.ParentMenu = provider.GetMenuSelectList(ioModel.Guid.ToString(), false, true);
            ViewBag.Roles = provider.GetComboRoles(result.Role?.ToString());
            return View(result);
        }

        public ActionResult UserMenuModification(UserMenu model)
        {
            return Ok(provider.Add(model));
        }
        public IActionResult Delete(UserMenu model)
        {
            ResponseBody res = provider.Delete(model);
            if (res != null && res.Success == true)
            {
                //return RedirectToAction("Index");
                return Ok(res);
            }
            else
            {
                return Ok(res);
            }
        }

    }
}
