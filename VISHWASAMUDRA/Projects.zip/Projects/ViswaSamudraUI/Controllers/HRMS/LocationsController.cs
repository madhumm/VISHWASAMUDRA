﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Providers.HRMS;
using VSManagement.IOModels;

namespace ViswaSamudraUI.Controllers.HRMS
{
    public class LocationsController : Controller
    {
		LocationsProvider provider = new LocationsProvider();
		public IActionResult Index(LocationsSearch requestModel)
		{
			
			LocationsSearch returnModel = new LocationsSearch();
			if (requestModel.searchFilter != null)
			{
				returnModel.filterEnabled = true;
			}
			IEnumerable<Locations> list = provider.GetAll(requestModel.searchFilter);
			returnModel.resultList = list;
			return View(returnModel);
		}
	}
}
