﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Providers.HRMS;
using VSManagement.IOModels;

namespace ViswaSamudraUI.Controllers.HRMS
{
    public class ZonesController : Controller
    {
		ZonesProvider provider = new ZonesProvider();
		public IActionResult Index(ZonesSearch requestModel)
		{
			ZonesSearch returnModel = new ZonesSearch();
			if (requestModel.searchFilter != null)
			{
				returnModel.filterEnabled = true;
			}

			IEnumerable<Zones> list = provider.GetAll(requestModel.searchFilter);
			returnModel.resultList = list;
			return View(returnModel);

		}
	}
}
