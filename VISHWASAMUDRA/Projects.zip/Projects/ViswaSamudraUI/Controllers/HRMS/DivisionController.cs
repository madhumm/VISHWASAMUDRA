﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Providers.HRMS;
using VSManagement.IOModels;

namespace ViswaSamudraUI.Controllers.HRMS
{
    public class DivisionController : Controller
    {
		DivisionProvider provider = new DivisionProvider();
		public IActionResult Index(DivisionSearch requestModel)
		{
            DivisionSearch returnModel = new DivisionSearch();
            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }

            IEnumerable<Division> list = provider.GetAll(requestModel.searchFilter);
            returnModel.resultList = list;
            return View(returnModel);
        }
	}
}
