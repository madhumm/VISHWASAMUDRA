﻿using Microsoft.AspNetCore.Mvc;
using ViswaSamudraUI.Providers.HRMS;
using io = VSManagement.IOModels;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Linq;

namespace ViswaSamudraUI.Controllers.HRMS
{
    public class BehiveImporterController : Controller
    {
        BehiveProvider provider = new BehiveProvider();
        [HttpGet]
        public IActionResult Index([FromQuery] string fromDate)
        {
            if (string.IsNullOrEmpty(fromDate))
            {
                return View(new List<io.Employee>());
            }

            IEnumerable<io.Employee> list = provider.GetBehiveData(fromDate);
            if(list == null) return View(new List<io.Employee>());
            return View(list);
        }

        [HttpPost]
        public IActionResult MergeEmployee([FromBody] List<io.Employee> list)
        {
            var response = provider.migrate(list);
            if (response.Message == "0") response.Success = false;
            return Ok(response);
        }
    }
}
