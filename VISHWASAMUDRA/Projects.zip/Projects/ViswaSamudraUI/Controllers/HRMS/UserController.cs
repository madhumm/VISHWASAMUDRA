﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using VSAssetManagement.IOModels;
using ViswaSamudraUI.Models;
using VSManagement.IOModels;
using ViswaSamudraUI.Providers.HRMS;
using ResponseBody = ViswaSamudraUI.Models.ResponseBody;
using Microsoft.AspNetCore.Http;
using ViswaSamudraUI.Filters;
using Microsoft.AspNetCore.Mvc.Rendering;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Providers.Assets;

namespace ViswaSamudraUI.Controllers.HRMS
{

    public class UserController : Controller
    {
        UserProvider provider;
        private readonly IHttpContextAccessor _httpContextAccessor;
        string user = string.Empty;
        ProjectProvider projectProvider = new ProjectProvider();
        public UserController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            string token = _httpContextAccessor.HttpContext.Session.GetString("auth-token");
           
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            provider = new UserProvider(token, user);

        }
        [CheckSession]
        public IActionResult Index(Usersearch requestModel)
        {
            Usersearch returnModel = new Usersearch();
            if (requestModel.searchFilter != null)
            {
                ViewBag.Department = provider.GetDepartmentData(requestModel.searchFilter.Department);
                ViewBag.Employees = provider.GetEmployeeData(requestModel.searchFilter.Department, requestModel.searchFilter.Reporting);
                //ViewBag.Roles = provider.GetComboRoles(requestModel.searchFilter);
               
                returnModel.filterEnabled = true;
            }
            else
            {
                ViewBag.Department = provider.GetDepartmentData("");
                ViewBag.Employees = provider.GetEmployeeData("", "");
                ViewBag.Roles = provider.GetComboRoles("");
            }
            IEnumerable<UserLogin> list = provider.GetSearchUser(requestModel.searchFilter).OrderByDescending(p => p.Id);
            returnModel.resultList=list;
            return View(returnModel);
        }
        [CheckSession]
        public async Task<IActionResult> UserOps(UserLogin UserIoModel)
        {

            if (string.IsNullOrEmpty(UserIoModel.Guid.ToString()))
            {
                ViewBag.Department = provider.GetDepartmentData("");
                ViewBag.Employees = provider.GetEmployeeData("","");
                ViewBag.Roles = provider.GetComboRoles("");
                ViewBag.Roles = provider.GetComboRoles("");
                ViewBag.Projects = projectProvider.GetSelectList();
                return View(UserIoModel);
            }
            var result = provider.GetAllUser(UserIoModel).FirstOrDefault();
            ViewBag.Department = provider.GetDepartmentData(result.Department);
            ViewBag.Employees = provider.GetEmployeeData(result.Department,result.Reporting);
            ViewBag.Roles = provider.GetComboRoles(result.Role.ToString());
            result.Active = result.IsActive == "1" ? true : false;
            result.IsLocked = result.Locked == 1 ? true : false;
            ViewBag.Projects = projectProvider.GetSelectList(result.Projects.ToString());
            return View(result);
        }
        [CheckSession]
        public ActionResult UserModification(UserLogin model)
        {
            model.IsActive = (model.Active == true) ? "1" : "0";
            model.Locked = (model.IsLocked == true) ? 1 : 0;
            model.RecordStatus = 1;
            model.UserName = string.Concat(model.FirstName.Substring(0, 1), model.LastName.Length > 5 ? model.LastName.Substring(0, 5) : model.LastName, model.EmpCode);
            return Ok(provider.Add(model));
        }
        [CheckSession]
        public ActionResult Delete(UserLogin model)
        {
            ResponseBody res = provider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }

        public async Task<IActionResult> EmployeesbyDepartment(string Department)
        {
            List<SelectListItem> Employees = provider.GetEmployeeData(Department, "");

            return Json(Employees);
        }

        public IActionResult Resetpassword(UserLogin model = null)
        {
            if(model == null) model = new UserLogin();
            var user = this.HttpContext.Session.GetString("user");
            if(user != null)
            {
                model.UserName = user;
            }
            return View(model);
        }

        public ActionResult PasswordUpdate(UserLogin model)
        {
            UserLogin UserIoModel = new UserLogin();
            if (!string.Equals(model.Password, model.OldPassword))
            {
                if (string.Equals(model.ConfirmPassword, model.Password))
                {
                    UserIoModel = provider.ResetPassword(model);
                    return Ok(UserIoModel);
                }
                else
                {
                    UserIoModel.Message = "Password and Confirmpassword not matched!.";
                    return Ok(UserIoModel);
                }

            }
            else
            {
                UserIoModel.Message = "Password and Defaulpassword/Oldpasswords Should not be same ";
                return Ok(UserIoModel);
            }
        }
    }
}
