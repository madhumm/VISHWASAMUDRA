﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Providers.HRMS;
using VSManagement.IOModels;
using ResponseBody = ViswaSamudraUI.Models.ResponseBody;

namespace ViswaSamudraUI.Controllers.HRMS
{
    [CheckSession]
    public class UserControlController : Controller
    {
        UserMenuProvider menuProvider = null;
        UserControlProvider provider = null;

        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public UserControlController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            menuProvider = new UserMenuProvider(user);
            provider = new UserControlProvider(user);

        }
        public IActionResult Index(Usercontrolsearch requestModel)
        {
            Usercontrolsearch returnModel = new Usercontrolsearch();
            if (requestModel.searchFilter != null)
            {
                ViewBag.Menu = menuProvider.GetMenuSelectList(requestModel.searchFilter.MenuId.ToString(), true, false);
                if (requestModel.searchFilter.Role != null)
                {
                    ViewBag.Roles = provider.GetComboRoles(requestModel.searchFilter.Role.ToString());
                }
                else
                {
                    ViewBag.Roles = provider.GetComboRoles("");
                }
                returnModel.filterEnabled = true;
            }
            else
            {
                ViewBag.Menu = menuProvider.GetMenuSelectList(null, true, false);
                ViewBag.Roles = provider.GetComboRoles("");
            }
            IEnumerable<UserControl> list = provider.GetsearchUserControl(requestModel.searchFilter).OrderByDescending(l => l.Id);
            returnModel.resultList = list;
            return View(returnModel);
        }

        public async Task<IActionResult> UserControlOps(UserControl ioModel)
        {
            if (ioModel.Guid == Guid.Empty)
            {
                ViewBag.Menu = menuProvider.GetMenuSelectList(null, true, false);
                ViewBag.Roles = provider.GetComboRoles("");
                return View(ioModel);
            }
            var result = provider.GetAllUserControl(ioModel).FirstOrDefault();
            ViewBag.Menu = menuProvider.GetMenuSelectList(ioModel.Guid.ToString(), true, false);
            result.Active = result.IsActive == "Y";
            ViewBag.Roles = provider.GetComboRoles(result.Role?.ToString());
            return View(result);
        }

        public ActionResult UserControlModification(UserControl model)
        {
            return Ok(provider.Add(model));
        }
        public IActionResult Delete(UserControl model)
        {
            ResponseBody res = provider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }

    }
}
