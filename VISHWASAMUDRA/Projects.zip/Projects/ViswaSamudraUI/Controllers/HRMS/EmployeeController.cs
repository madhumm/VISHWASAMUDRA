﻿using Microsoft.AspNetCore.Mvc;
using ViswaSamudraUI.Providers.HRMS;
using io = VSManagement.IOModels;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Asset.SearchForms;

namespace ViswaSamudraUI.Controllers.HRMS
{
    public class EmployeeController : Controller
    {
        EmployeeProvider provider = new EmployeeProvider();
        public IActionResult ProfileDetails(io.Employee employee)
        {
            io.Employee record = null;
            if (employee == null || employee.Guid == null || employee.Guid == System.Guid.Empty)
            {
                string _username = HttpContext.Session.GetString("user");
                record = provider.GetEmployeeDetails(_username);
            }
            if (employee == null && employee.Guid != null && employee.Guid != System.Guid.Empty)
            {
                string _username = HttpContext.Session.GetString("user");
                record = provider.GetEmployeeDetails(_username);
            }
            else
            {
                IEnumerable<io.Employee> list = provider.GetAll(employee);
                record=list.FirstOrDefault();
            }
            return View(record);
        }

        public IActionResult Index(EmployeeSearch requestModel)
        {
            EmployeeSearch returnModel = new EmployeeSearch();
            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }
            else
            {
                requestModel.searchFilter = new io.Employee();
            }
            IEnumerable<io.Employee> list = provider.GetAll(requestModel.searchFilter);
            returnModel.resultList = list;
            return View(returnModel);
        }

        public IActionResult BehiveImport()
        {
            IEnumerable<io.Employee> list = provider.GetBehiveData();
            return View(list);
        }
    }
}
