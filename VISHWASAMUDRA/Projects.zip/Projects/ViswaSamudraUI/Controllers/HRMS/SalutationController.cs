﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Providers.HRMS;
using VSManagement.IOModels;

namespace ViswaSamudraUI.Controllers.HRMS
{
    public class SalutationController : Controller
    {
		SalutationProvider provider = new SalutationProvider();
		public IActionResult Index(SalutationSearch requestModel)
        {
            SalutationSearch returnModel = new SalutationSearch();
            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }
            IEnumerable<Salutation> list = provider.GetAll(requestModel.searchFilter);
            returnModel.resultList = list;
            return View(returnModel);
        }
	}
}
