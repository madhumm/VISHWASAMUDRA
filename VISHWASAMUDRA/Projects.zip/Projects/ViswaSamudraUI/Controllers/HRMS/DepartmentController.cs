﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Providers.HRMS;
using VSManagement.IOModels;

namespace ViswaSamudraUI.Controllers.HRMS
{
    public class DepartmentController : Controller
    {
		DepartmentProvider provider = new DepartmentProvider();
		public IActionResult Index(DepartmentSearch requestModel)
		{
            DepartmentSearch returnModel = new DepartmentSearch();
            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }

            IEnumerable<Department> list = provider.GetAll(requestModel.searchFilter);
            returnModel.resultList = list;
            return View(returnModel);
		}
	}
}
