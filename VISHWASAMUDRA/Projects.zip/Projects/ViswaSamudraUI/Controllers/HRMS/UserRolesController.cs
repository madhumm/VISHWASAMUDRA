﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Providers.HRMS;
using VSManagement.IOModels;
using ResponseBody = ViswaSamudraUI.Models.ResponseBody;

namespace ViswaSamudraUI.Controllers.HRMS
{
    [CheckSession]
    public class UserRolesController : Controller
    {
        UserRolesProvider provider = null;
        LookUpProvider lookUpProvider = null;
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public UserRolesController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            lookUpProvider = new LookUpProvider(user);
            provider = new UserRolesProvider(user);
        }
        public IActionResult Index(Rolessearch requestModel)
        {
            Rolessearch returnModel = new Rolessearch();
            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }
            IEnumerable<UserRole> list = provider.GetAllUserRole(requestModel.searchFilter).OrderByDescending(l => l.Id);
            returnModel.resultList = list;
            return View(returnModel);
        }

        public async Task<IActionResult> UserRoleOps(UserRole ioModel)
        {
            if (ioModel.Guid == Guid.Empty)
            {
                return View(ioModel);
            }
            IEnumerable<UserRole> list = provider.GetAllUserRole(ioModel);
            var userRole = list.FirstOrDefault();
            return View(userRole);
        }

        public ActionResult UserRoleModification(UserRole model)
        {
            return Ok(provider.Add(model));
            //return Content(status);
        }
        public IActionResult Delete(UserRole model)
        {
            ResponseBody res = provider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }

    }
}
