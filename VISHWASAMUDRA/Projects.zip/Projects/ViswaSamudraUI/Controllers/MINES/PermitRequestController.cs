﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using io = ViswasamudraCommonObjects.Mines;
using sf = ViswasamudraCommonObjects.SearchForms.Mines;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Providers.MINES;
using System;
using ViswasamudraCommonObjects.Mines;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class PermitRequestController : Controller
    {
        string user = string.Empty;

        private readonly IHttpContextAccessor _httpContextAccessor;
        MineLeaseHoldersProvider leaseProvider;
        LookUpProvider lookUpProvider = new LookUpProvider();
        MinesLookupTypeProvider minesLookUpProvider = new MinesLookupTypeProvider();
        UOMProvider uomProvider = new UOMProvider();
        MineLocationsProvider locProvider = new MineLocationsProvider();
        PermitRequestProvider provider;
        public PermitRequestController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            leaseProvider = new MineLeaseHoldersProvider(user);
            provider = new PermitRequestProvider(user, _httpContextAccessor);
        }

        public IActionResult PermitRequestOps(Guid guid, string type = "O")
        {
            ViewBag.type = type;
            io.PermitRequest response = null;
            if (guid == Guid.Empty || guid == null)
            {
                //ViewBag.MineralLocation = locProvider.GetCombo("");

                //ViewBag.MineralName = locProvider.GetMineralCombo("");

                ViewBag.PermitReqType = minesLookUpProvider.GetSelectList("PRQTYPE");

                if (type == "G")
                {
                    ViewBag.Uom = uomProvider.GetCubicCombo();
                }
                else
                {
                    ViewBag.Uom = uomProvider.GetCombo("");
                }

                ViewBag.LeaseHolderList = leaseProvider.GetComboData(type == "G");

                ViewBag.LeaseHolder = leaseProvider.GetCombo("", type == "G");
                ViewBag.Users = lookUpProvider.GetUserData();

            }
            else
            {
                response = provider.GetAll(new io.PermitRequest { header = new io.PermitRequestHeader { PrHeaderId = guid } }).FirstOrDefault();
                //ViewBag.MineralLocation = locProvider.GetCombo(response.header.MineralLocationId.ToString());

                //ViewBag.MineralName = locProvider.GetMineralCombo(response.header.MineralLocationId.ToString());

                ViewBag.PermitReqType = minesLookUpProvider.GetSelectList("PRQTYPE", response.header.PrType.ToString());

                ViewBag.Uom = uomProvider.GetCombo(response.header.UomId.ToString());
                ViewBag.LeaseHolderList = leaseProvider.GetComboData(type == "G");
                ViewBag.LeaseHolder = leaseProvider.GetCombo(response.header.LeaseHolderId.ToString(), type == "G");
                ViewBag.Users = lookUpProvider.GetUserData(user);
            }
            ViewBag.SurveyReq = (type == "G");

            return View(response);
        }

        public IActionResult GraniteIndex()
        {
            return RedirectToAction("Index", "PermitRequest", new {type="G"});
        }

        public IActionResult Index(string type = "O")
        {
            ViewBag.Type = type;
            IEnumerable<io.PermitRequest> list = getdetails(new io.PermitRequestHeader { SurveyRequired = (type == "O" ? 0 : 1) });
            sf.PermitRequestSearch search = new sf.PermitRequestSearch();
            search.resultList = list;
            return View(search);
        }

        public IEnumerable<io.PermitRequest> getdetails(io.PermitRequestHeader header)
        {
            return provider.GetAll(new io.PermitRequest { header = header }).OrderByDescending(r => r.header.Id);
        }

        public ActionResult PermitRequestModification(io.PermitRequest model)
        {
            return Ok(provider.Add(model));
        }

        public IActionResult ApproveNonPRIndex(io.PermitRequestHeader model)
        {
            IEnumerable<io.PermitRequest> list = getdetails(new io.PermitRequestHeader { SurveyRequired = 0, RequestStatusCode = "PRAPRVPENDING" });
            sf.PermitRequestSearch search = new sf.PermitRequestSearch();
            search.resultList = list;
            //return View(search);
            return View("~/Views/NonGranitePermitRequest/Approval/Index.cshtml", search);
        }

        public IActionResult ApproveNonPROps(io.PermitRequestHeader model)
        {
            io.PermitRequest data = getdetails(model).FirstOrDefault();
            //return View(search);
            return View("~/Views/NonGranitePermitRequest/Approval/ViewDetails.cshtml", data);
        }

        public ActionResult Approve(io.PermitRequestHeader model)
        {
            return Ok(provider.Approve(new io.PermitRequest { header = new io.PermitRequestHeader { SurveyRequired = 0, RequestApprovalFlag = model.ApprovalFlag, PrHeaderId = model.Guid, Reason = model.ApprovalFlag == "Y" ? null : model.Reason, ApprovedQty = model.ApprovedQty } }));
        }
    }
}
