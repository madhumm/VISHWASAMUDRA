﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswaSamudraUI.Filters;
using ViswasamudraCommonObjects.Mines;
using Microsoft.AspNetCore.Mvc.Rendering;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Providers.MINES;
using ViswaSamudraUI.Models;
using Microsoft.AspNetCore.Http;

namespace ViswaSamudraUI.Controllers.MINES
{
    [CheckSession]
    public class MineLocationsController : Controller
    {
        LookUpProvider lookUpProvider = new LookUpProvider();

        MinesLookupTypeProvider minesLookUpTypeProvider = new MinesLookupTypeProvider();

        UOMProvider uOMProvider = new UOMProvider();
        MineralsProvider mineralsProvider = new MineralsProvider();
        MineLocationsProvider mineLocationsProvider = new MineLocationsProvider();
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public MineLocationsController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            mineLocationsProvider = new MineLocationsProvider(user);
        }
        public IActionResult Index(MineLocationsSearch requestModel)
        {
            MineLocationsSearch returnModel = new MineLocationsSearch();

            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }
            else
            {
                returnModel.filterEnabled = false;
                requestModel.searchFilter = new MineLocations();
            }

            IEnumerable<MineLocations> list = GetAllDetails(requestModel.searchFilter);

            returnModel.resultList = list;

            return View(returnModel);
        }

        public IEnumerable<MineLocations> GetAllDetails(MineLocations model)
        {
            IEnumerable<MineLocations> mineLocations = mineLocationsProvider.GetAllMinerals(model);

            List<SelectListItem> States = uOMProvider.GetStateCombo(null);
            foreach (var item in mineLocations)
            {
                item.StateName = States.Where(x => x.Value == item.State.ToString()).FirstOrDefault()?.Text;
            }

            List<SelectListItem> Districts = uOMProvider.GetDistrctCombo(null, null);
            foreach (var item in mineLocations)
            {
                item.DistrictName = Districts.Where(x => x.Value == item.District.ToString()).FirstOrDefault()?.Text;
            }

            List<SelectListItem> Mandal = uOMProvider.GetMandalsCombo("");
            foreach (var item in mineLocations)
            {
                item.MandalName = Mandal.Where(x => x.Value == item.Mandal.ToString()).FirstOrDefault()?.Text;
            }

            List<SelectListItem> Village = uOMProvider.GetVillagesCombo("");
            foreach (var item in mineLocations)
            {
                item.VillageName = Village.Where(x => x.Value == item.Village.ToString()).FirstOrDefault()?.Text;
            }

            List<SelectListItem> Pincode = uOMProvider.GetPinCodesCombo("");
            foreach (var item in mineLocations)
            {
                item.PincodeName = Pincode.Where(x => x.Value == item.Pincode.ToString()).FirstOrDefault()?.Text;
            }


            return mineLocations;
        }

        public async Task<IActionResult> MineLocationOps(MineLocations ioModel)
        {
            if (!ioModel.LocationId.HasValue || ioModel.LocationId == Guid.Empty)
            {
                ViewBag.Minerals = mineralsProvider.GetCombo("");

                ViewBag.States = uOMProvider.GetStateCombo(null);

                ViewBag.Districts = uOMProvider.GetDistrctCombo(null, null);

                ViewBag.Mandal = uOMProvider.GetMandalsCombo("");

                ViewBag.Village = uOMProvider.GetVillagesCombo("");

                ViewBag.LandType = minesLookUpTypeProvider.GetSelectList("LANDTYP");

                ViewBag.Pincode = uOMProvider.GetPinCodesCombo("");

                return View(ioModel);
            }

            MineLocations mineLocation = mineLocationsProvider.GetByGuId(ioModel.LocationId.Value);

            ViewBag.Minerals = mineralsProvider.GetCombo(mineLocation.MineralId.ToString());

            ViewBag.States = uOMProvider.GetStateCombo(mineLocation.State.Value.ToString());

            ViewBag.Districts = uOMProvider.GetDistrctCombo(mineLocation.District.Value.ToString(), mineLocation.State);

            ViewBag.Mandal = uOMProvider.GetMandalsCombo(mineLocation.Mandal.Value.ToString());

            ViewBag.Village = uOMProvider.GetVillagesCombo(mineLocation.Village.Value.ToString());

            ViewBag.LandType = minesLookUpTypeProvider.GetSelectList("LANDTYP");

            ViewBag.Pincode = uOMProvider.GetPinCodesCombo(mineLocation.Pincode.Value.ToString());

            return View(mineLocation);
        }

        public ActionResult MineLocationModification(MineLocations model)
        {
            return Ok(mineLocationsProvider.Add(model));
        }

        public IActionResult Delete(Guid? guid)
        {
            ResponseBody res = mineLocationsProvider.Delete(guid);

            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
