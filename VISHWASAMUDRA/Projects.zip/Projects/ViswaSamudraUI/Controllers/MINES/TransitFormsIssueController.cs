﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Mines;
using ViswasamudraCommonObjects.SearchForms.Mines;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Providers;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Providers.MINES;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class TransitFormsIssueController : Controller
    {
        string user = string.Empty;
        Guid userGuid = Guid.Empty;

        private readonly IHttpContextAccessor _httpContextAccessor;
        LookUpProvider lookUpProvider = new LookUpProvider();
        PermitRequestProvider provider = null;
        MinesLookupTypeValuesProvider minesLookUpProvider = new MinesLookupTypeValuesProvider();
        TransitFormIssueProvider transProvider = null;
        TransitFormBooksProvider tfBooksRepo = null;
        MDLHoldersProvider mdlRepo = null;
        public TransitFormsIssueController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            provider = new PermitRequestProvider(user, _httpContextAccessor);
            transProvider = new TransitFormIssueProvider(user, _httpContextAccessor);
            tfBooksRepo = new TransitFormBooksProvider(user, _httpContextAccessor);
            mdlRepo = new MDLHoldersProvider(user, _httpContextAccessor);
            userGuid = Guid.Parse(_httpContextAccessor.HttpContext.Session.GetString("userGuid"));
        }

        public IActionResult TransitFormsIssueOps(string permitNo)
        {
            TransitFormIssue response = null;
            ViewBag.Users = lookUpProvider.GetUserDropDown();
            response = transProvider.GetAll(new TransitFormIssue { header = new TransitFormIssueHeader { PermitNo = permitNo } }).FirstOrDefault();
            ViewBag.PaymentMode = lookUpProvider.GetPaymentModes();
            ViewBag.TFBookNos = tfBooksRepo.GetCombo(null);
            ViewBag.MDLHolders = mdlRepo.GetCombo(null);
            return View(response);
        }

        public IActionResult Index()
        {
            IEnumerable<PermitRequest> list = getdetails();
            PermitRequestSearch search = new PermitRequestSearch();
            search.resultList = list;
            return View(search);
        }

        public IEnumerable<PermitRequest> getdetails()
        {
            var response = provider.GetAll(new PermitRequest { header = new PermitRequestHeader { RequestStatusCode = "SURVYRAPPROVED" }, });
            return response.OrderByDescending(r => r.header.Id);
        }

        public ActionResult TransitFormsIssueModification(TransitFormIssue model)
        {
            return Ok(transProvider.IssueTransit(model));
        }
    }
}
