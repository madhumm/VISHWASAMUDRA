﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswaSamudraUI.Filters;
using ViswasamudraCommonObjects.Mines;
using Microsoft.AspNetCore.Mvc.Rendering;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Providers.MINES;
using ViswaSamudraUI.Models;
using Microsoft.AspNetCore.Http;

namespace ViswaSamudraUI.Controllers.MINES
{
    [CheckSession]
    public class MineralCategoriesController : Controller
    {
        MinesLookupTypeProvider minesLookUpTypeProvider = new MinesLookupTypeProvider();

        MineralCategoriesProvider mineralCategoriesProvider = new MineralCategoriesProvider();

        MineralsProvider mineralsProvider = new MineralsProvider();
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public MineralCategoriesController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            mineralCategoriesProvider = new MineralCategoriesProvider(user);
        }
        public IActionResult Index(MineralCategoriesSearch requestModel)
        {
            MineralCategoriesSearch returnModel = new MineralCategoriesSearch();

            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }
            else
            {
                requestModel.searchFilter = new MineralCategories();
            }

            IEnumerable<MineralCategories> list = GetAllDetails(requestModel.searchFilter);

            returnModel.resultList = list;

            return View(returnModel);
        }

        public IEnumerable<MineralCategories> GetAllDetails(MineralCategories model)
        {
            return mineralCategoriesProvider.GetAllMineralCategories(model);
        }

        public async Task<IActionResult> MineralCategoryOps(MineralCategories ioModel)
        {
            if (!ioModel.MineralCategoryId.HasValue || ioModel.MineralCategoryId == Guid.Empty)
            {
                ViewBag.Minerals = mineralsProvider.GetCombo("");

                return View(ioModel);
            }

            MineralCategories mineralCategory = mineralCategoriesProvider.GetByGuId(ioModel.MineralCategoryId.Value);
            if (mineralCategory.HasSize == null || mineralCategory.HasSize == 0)
            {
                mineralCategory.IsSizeApplicable = false;

            }
            else
            {
                mineralCategory.IsSizeApplicable = true;
            }

            ViewBag.Minerals = mineralsProvider.GetCombo(mineralCategory.MineralName);

            return View(mineralCategory);            
        }

        public ActionResult MineralCategoriesModification(MineralCategories model)
        {
            if (model.IsSizeApplicable == true)
            {
                model.HasSize = 1;

            }
            else
            {
                model.HasSize = 0;
            }
            return Ok(mineralCategoriesProvider.Add(model));
        }

        public IActionResult Delete(Guid? guid)
        {
            ResponseBody res = mineralCategoriesProvider.Delete(guid);

            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
