﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Mines;
using ViswasamudraCommonObjects.Mines.MinesSearch;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers;
using ViswaSamudraUI.Providers.MINES;

namespace ViswaSamudraUI.Controllers.MINES
{
    [CheckSession]
    public class MinesLeaseHoldersController : Controller
    {
       
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        MineLeaseHoldersProvider provider = null;
        UOMProvider uOMProvider = new UOMProvider();
        public MinesLeaseHoldersController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            provider = new MineLeaseHoldersProvider(user);
        }
      
        public IActionResult Index(LeaseHoldersSearch requestModel)
        {
            LeaseHoldersSearch returnModel = new LeaseHoldersSearch();

            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }
            List<MineLeaseHolders> list = provider.GetAllMineLeaseHolders(requestModel.searchFilter).OrderByDescending(p => p.Id).ToList(); 
            returnModel.resultList = list;

            return View(returnModel);
        }
        public ActionResult  LeaseHolderModification(MineLeaseHolders model)
        {
            return Ok(provider.Add(model));
        }
        public ActionResult LeaseHoldersOps(MineLeaseHolders leaseHolders)
        {
            if (leaseHolders.LeaseHolderId == Guid.Empty || leaseHolders.LeaseHolderId==null)
            {
                ViewBag.States = uOMProvider.GetStateCombo(null);
                ViewBag.Districts = uOMProvider.GetDistrctCombo(null,null);
                ViewBag.Pincode = uOMProvider.GetPinCodeCombo("");
                return View(leaseHolders);
            }
            IEnumerable<MineLeaseHolders> list = provider.GetAllMineLeaseHolders(leaseHolders);
            var mineLeaseHolders = list.FirstOrDefault();
            ViewBag.States = uOMProvider.GetStateCombo(mineLeaseHolders.State.ToString());
            ViewBag.Districts = uOMProvider.GetDistrctCombo(mineLeaseHolders.District.ToString(), mineLeaseHolders.State);
            ViewBag.Pincode = uOMProvider.GetPinCodeCombo(mineLeaseHolders.PinCode);
            return View(mineLeaseHolders);
        }

        public IActionResult Delete(MineLeaseHolders model)
        {
            ResponseBody res = provider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }

        public async Task<IActionResult> DistrictsbyState(Guid StateId)
        {
            List<SelectListItem> Districts = uOMProvider.GetDistrctCombo("", StateId);

            return Json(Districts);
        }

    }
}
