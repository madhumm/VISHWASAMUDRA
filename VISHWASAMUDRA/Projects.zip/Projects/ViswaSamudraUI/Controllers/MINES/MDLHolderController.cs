﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System.Threading.Tasks;
using ViswaSamudraUI.Providers.Assets;
using Microsoft.AspNetCore.Http;
using ViswasamudraCommonObjects.Mines;
using ViswaSamudraUI.Providers.MINES;
using VSManagement.IOModels.DropDown;
using System;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Filters;

namespace ViswaSamudraUI.Controllers.MINES
{
    [CheckSession]
    public class MDLHolderController : Controller
    {
        string user = string.Empty;

        private readonly IHttpContextAccessor _httpContextAccessor;

        MDLHoldersProvider mdlHoldersProvider = null;

        MineralsProvider mineralsProvider = new MineralsProvider();

        UOMProvider uOMProvider = new UOMProvider();

        public MDLHolderController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            mdlHoldersProvider = new MDLHoldersProvider(user, httpContextAccessor);
        }

        public IActionResult Index(MDLHoldersSearch requestModel)
        {
            MDLHoldersSearch returnModel = new MDLHoldersSearch();
            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }
            else{
                requestModel.searchFilter = new MDLHolder();
            }           

            IEnumerable<MDLHolder> list = GetAllDetails(requestModel.searchFilter);           

            returnModel.resultList = list;

            return View(returnModel);
        }

        public IEnumerable<MDLHolder> GetAllDetails(MDLHolder model)
        {
            return mdlHoldersProvider.GetAllMdlHolders(model);
        }

        public async Task<IActionResult> MDLHolderOps(MDLHolder ioModel)
        {
            if (!ioModel.MdlhId.HasValue || ioModel.MdlhId == Guid.Empty)
            {
                var minerals = mineralsProvider.GetCombo("");                
                ViewBag.Minerals = minerals;

                ViewBag.States = uOMProvider.GetStateCombo(null);

                ViewBag.Districts = uOMProvider.GetDistrctCombo(null, null);
                ViewBag.Pincode = uOMProvider.GetPinCodeCombo("");

                return View(ioModel);
            }

            MDLHolder mdlHolder = mdlHoldersProvider.GetByGuId(ioModel.MdlhId.Value);
            ViewBag.Minerals  = mineralsProvider.GetCombo(mdlHolder.MineralId.ToString());
           
            ViewBag.States = uOMProvider.GetStateCombo(mdlHolder.State.ToString());

            ViewBag.Districts = uOMProvider.GetDistrctCombo(mdlHolder.District.ToString(), mdlHolder.State);
            ViewBag.Pincode = uOMProvider.GetPinCodeCombo(mdlHolder.PinCode);

            return View(mdlHolder);            
        }

        public ActionResult MDLHolderModification(MDLHolder model)
        {            
            return Ok(mdlHoldersProvider.Add(model));
        }

        public IActionResult Delete(Guid? guid)
        {
            ResponseBody res = mdlHoldersProvider.Delete(guid);

            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
