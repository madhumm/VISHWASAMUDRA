﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Providers;
using VSAssetManagement.IOModels;
using ViswasamudraCommonObjects.Mines.MinesSearch;
using global = ViswasamudraCommonObjects.GlobalData.Search;
using mines = ViswasamudraCommonObjects.Mines;
using ViswasamudraCommonObjects.GlobalData;
using Microsoft.AspNetCore.Http;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Providers.MINES;
using System.Linq;
using ViswaSamudraUI.Models;

namespace ViswaSamudraUI.Controllers.MINES
{
	[CheckSession]
	public class UOMController : Controller
	{

		UOMProvider provider = null;

		string user = string.Empty;

		private readonly IHttpContextAccessor _httpContextAccessor;
		public UOMController(IHttpContextAccessor httpContextAccessor)
		{
			_httpContextAccessor = httpContextAccessor;
			user = _httpContextAccessor.HttpContext.Session.GetString("user");
			provider = new UOMProvider(user);
		}
		public IActionResult Index(global.UOMSearch requestModel)
		{
            global.UOMSearch returnModel = new global.UOMSearch();
			if (requestModel.searchFilter != null)
			{
				returnModel.filterEnabled = true;
			}

			IEnumerable<UOM> list = provider.GetAllUOMs(requestModel.searchFilter).OrderByDescending(l => l.Id);
			returnModel.resultList = list;
			return View(returnModel);
		}

		public async Task<IActionResult> UOMOps(UOM ioModel)
		{
			if (ioModel.UomId == Guid.Empty || ioModel.UomId ==null)
			{
				return View(ioModel);
			}
			IEnumerable<UOM> list = provider.GetAllUOMs(ioModel);
			var uom = list.FirstOrDefault();
			return View(uom);
		}

		public ActionResult UOMModification(UOM model)
		{
			return Ok(provider.Add(model));
		}

		public IActionResult Delete(UOM model)
		{
			ResponseBody res = provider.Delete(model);
			if (res != null && res.Success == true)
			{
				return RedirectToAction("Index");
			}
			else
			{
				return Ok(res);
			}
		}
	}
}
