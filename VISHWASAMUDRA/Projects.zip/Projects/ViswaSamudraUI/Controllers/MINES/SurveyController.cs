﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Mines;
using ViswasamudraCommonObjects.SearchForms.Mines;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Providers;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Providers.MINES;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class SurveyController : Controller
    {
        string user = string.Empty;
        Guid userGuid = Guid.Empty;

        private readonly IHttpContextAccessor _httpContextAccessor;
        LookUpProvider lookUpProvider = new LookUpProvider();
        PermitRequestProvider provider = null;
        public SurveyController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            provider = new PermitRequestProvider(user, _httpContextAccessor);
            userGuid = Guid.Parse(_httpContextAccessor.HttpContext.Session.GetString("userGuid"));
        }

        public IActionResult AssignSurveyorOps(Guid guid)
        {
            PermitRequest response = null;
            response = provider.GetAll(new PermitRequest { header = new PermitRequestHeader { PrHeaderId = guid } }).FirstOrDefault();
            ViewBag.Users = lookUpProvider.GetUserDropDown();
            return View(response);
        }

        public IActionResult AssignSurveyorIndex()
        {
            IEnumerable<PermitRequest> list = getdetails("assign");
            PermitRequestSearch search = new PermitRequestSearch();
            search.resultList = list;
            return View(search);
        }

        public IActionResult ApproveSurveyOps(Guid guid)
        {
            PermitRequest response = null;
            response = provider.GetAll(new PermitRequest { header = new PermitRequestHeader { PrHeaderId = guid } }).FirstOrDefault();
            ViewBag.Users = lookUpProvider.GetUserDropDown();
            return View(response);
        }

        public IActionResult ApproveSurveyIndex()
        {
            IEnumerable<PermitRequest> list = getdetails("approve");
            PermitRequestSearch search = new PermitRequestSearch();
            search.resultList = list;
            return View(search);
        }

        public IEnumerable<PermitRequest> getdetails(string type)
        {
            IEnumerable<PermitRequest> response = null;
            if (type == "assign")
            {
                response = provider.GetAll(new PermitRequest { header = new PermitRequestHeader { SurveyRequired = 1, RequestStatusCode = "SVYRASNPENDING" }, });
                response.Where(r => r.header.SurveyorId == Guid.Empty || r.header.SurveyorId == null);
            }else if(type == "approve")
            {
                response = provider.GetAll(new PermitRequest { header = new PermitRequestHeader { SurveyRequired = 1, RequestStatusCode = "SVYRASSIGNED", SurveyorId = userGuid }, });
                response.Where(r => r.header.SurveyorId == userGuid);
            }
            return response.OrderByDescending(r => r.header.Id);
        }

        public ActionResult AssignSurveyorModification(PermitRequest model)
        {
            return Ok(provider.Assign(model));
        }

        public ActionResult ApproveSurveyModification(PermitRequest model)
        {
            model.header.SurveyRequired = 1;
            return Ok(provider.Approve(model));
        }
    }
}
