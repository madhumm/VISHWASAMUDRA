﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswaSamudraUI.Filters;
using ViswasamudraCommonObjects.Mines;
using Microsoft.AspNetCore.Mvc.Rendering;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Providers.MINES;
using ViswaSamudraUI.Models;
using Microsoft.AspNetCore.Http;

namespace ViswaSamudraUI.Controllers.MINES
{
    [CheckSession]
    public class MineralCategorySizesController : Controller
    {
        MineralCategoriesProvider mineralCategoriesProvider = new MineralCategoriesProvider();

        MineralCategorySizesProvider mineralCategorySizesProvider = new MineralCategorySizesProvider();

        UOMProvider uOMProvider = new UOMProvider();
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public MineralCategorySizesController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            mineralCategorySizesProvider = new MineralCategorySizesProvider(user);
        }
        public IActionResult Index(MineralCategorySizesSearch requestModel)
        {
            MineralCategorySizesSearch returnModel = new MineralCategorySizesSearch();

            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }
            else
            {
                requestModel.searchFilter = new MineralCategorySizes();
            }

            IEnumerable<MineralCategorySizes> list = GetAllDetails(requestModel.searchFilter);

            returnModel.resultList = list;

            return View(returnModel);
        }

        public IEnumerable<MineralCategorySizes> GetAllDetails(MineralCategorySizes model)
        {
            IEnumerable<MineralCategorySizes> MineralCategorySizes = mineralCategorySizesProvider.GetAllMineralCategorySizes(model);

            List<SelectListItem> UOMS = uOMProvider.GetCombo("");
            foreach (var item in MineralCategorySizes)
            {
                item.MineralCategorySizeUOMName = UOMS.Where(x => x.Value == item.MineralCategorySizeUOMId.ToString()).FirstOrDefault()?.Text;
            }
            return MineralCategorySizes;
        }

        public async Task<IActionResult> MineralCategorySizeOps(MineralCategorySizes ioModel)
        {
            if (!ioModel.MineralCategorySizeId.HasValue || ioModel.MineralCategorySizeId == Guid.Empty)
            {
                ViewBag.MineralCategorySizeUOM = uOMProvider.GetCombo("");

                ViewBag.MineralCategories = mineralCategoriesProvider.GetCombo("");

                return View(ioModel);
            }

            MineralCategorySizes mineralCategorySize = mineralCategorySizesProvider.GetByGuId(ioModel.MineralCategorySizeId.Value).FirstOrDefault();

            ViewBag.MineralCategorySizeUOM = uOMProvider.GetCombo(mineralCategorySize.MineralCategorySizeUOMName);

            ViewBag.MineralCategories = mineralCategoriesProvider.GetCombo(mineralCategorySize.MineralCategoryName);

            return View(mineralCategorySize);
        }

        public ActionResult MineralCategorySizesModification(MineralCategorySizes model)
        {
            return Ok(mineralCategorySizesProvider.Add(model));
        }

        public IActionResult Delete(Guid? guid)
        {
            ResponseBody res = mineralCategorySizesProvider.Delete(guid);

            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
