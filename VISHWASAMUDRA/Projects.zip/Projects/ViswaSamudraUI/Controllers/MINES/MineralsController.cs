﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswaSamudraUI.Filters;
using ViswasamudraCommonObjects.Mines;
using Microsoft.AspNetCore.Mvc.Rendering;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Providers.MINES;
using ViswaSamudraUI.Models;
using Microsoft.AspNetCore.Http;
using VSManagement.IOModels.DropDown;

namespace ViswaSamudraUI.Controllers.MINES
{
    [CheckSession]
    public class MineralsController : Controller
    {
        MinesLookupTypeProvider minesLookupTypeProvider = new MinesLookupTypeProvider();
        LookUpProvider lookUpProvider = new LookUpProvider();
        MineralsProvider mineralsProvider = new MineralsProvider();
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public MineralsController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            mineralsProvider = new MineralsProvider(user);
        }
        public IActionResult Index(MineralsSearch requestModel)
        {
            MineralsSearch returnModel = new MineralsSearch();

            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }
            else
            {
                requestModel.searchFilter = new Minerals();
            }

            IEnumerable<Minerals> list = GetAllDetails(requestModel.searchFilter);

            returnModel.resultList = list;

            return View(returnModel);
        }

        public IEnumerable<Minerals> GetAllDetails(Minerals model)
        {
            return mineralsProvider.GetAllMinerals(model);
        }

        public async Task<IActionResult> MineralsOps(Minerals ioModel)
        {
            if (!ioModel.MineralId.HasValue || ioModel.MineralId == Guid.Empty)
            {
                ViewBag.MineralType = minesLookupTypeProvider.GetSelectList("MNRLTYP");

                return View(ioModel);
            }

            Minerals mineral = mineralsProvider.GetByGuId(ioModel.MineralId.Value);
            if (mineral.HasCategory==null ||mineral.HasCategory==0)
            {
                mineral.IsCategoryApplicable = false;

            }
            else
            {
                mineral.IsCategoryApplicable = true;
            }
            ViewBag.MineralType = minesLookupTypeProvider.GetSelectList("MNRLTYP");

            return View(mineral);
        }

        public ActionResult MineralsModification(Minerals model)
        {
            if (model.IsCategoryApplicable==true)
            {
                model.HasCategory = 1;

            }
            else
            {
                model.HasCategory = 0;
            }
            return Ok(mineralsProvider.Add(model));
        }

        public IActionResult Delete(Guid? guid)
        {
            ResponseBody res = mineralsProvider.Delete(guid);

            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
