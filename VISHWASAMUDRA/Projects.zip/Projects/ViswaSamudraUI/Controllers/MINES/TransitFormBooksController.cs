﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.PortableExecutable;
using System.Threading.Tasks;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswasamudraCommonObjects.Mines;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Providers.MINES;
using VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Controllers.MINES
{
    [CheckSession]
    public class TransitFormBooksController : Controller
    {
        string user = string.Empty;

        private readonly IHttpContextAccessor _httpContextAccessor;

        TransitFormBooksProvider transitFormBooksProvider = null;

        MinesLookupTypeProvider minesLookUpProvider = new MinesLookupTypeProvider();

        ProjectProvider projectProvider = new ProjectProvider();

        public TransitFormBooksController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            transitFormBooksProvider = new TransitFormBooksProvider(user, httpContextAccessor);
        }

        public IActionResult Index(TransitFormBooksSearch requestModel)
        {
            TransitFormBooksSearch returnModel = new TransitFormBooksSearch();

            returnModel.searchFilter = null;

            IEnumerable<TransitFormBooks> list = GetAllDetails();

            var allProjects = projectProvider.GetSelectList();

            foreach (var item in list)
            {
                item.Project = allProjects.Where(x => x.Value == item.ProjectId.ToString()).FirstOrDefault().Text;
            }

            returnModel.resultList = list;

            return View(returnModel);
        }

        public IEnumerable<TransitFormBooks> GetAllDetails()
        {
            return transitFormBooksProvider.GetAll();
        }

        public async Task<IActionResult> TransitFormBooksOps(TransitFormBooks ioModel)
        {
            if (ioModel.TfBookId == Guid.Empty)
            {
                var tfbStatus = minesLookUpProvider.GetSelectList("TFBSTAT", "");
                foreach (var tfb in tfbStatus)
                {
                    if (tfb.Text == "Ready to Use")
                    {
                        tfb.Selected = true;
                    }
                }
                ViewBag.TFBStatus = tfbStatus;

                ViewBag.Projects = projectProvider.GetSelectList();

                ioModel.TfBookDate = Convert.ToDateTime(DateTime.Now.ToString("dd/MM/yyyy"));

                return View(ioModel);
            }

            TransitFormBooks transitFormBook = transitFormBooksProvider.GetByGuId(ioModel.TfBookId);
            ViewBag.TFBStatus = minesLookUpProvider.GetSelectList("TFBSTAT");
            ViewBag.Projects = projectProvider.GetSelectList();

            return View(transitFormBook);
        }

        public ActionResult TransitFormBooksModification(TransitFormBooks model)
        {
            model.UsedTf = model.VoidTf = model.CancelledTf = 0;
             
            return Ok(transitFormBooksProvider.Add(model));
        }

        public IActionResult Delete(Guid guid)
        {
            ResponseBody res = transitFormBooksProvider.Delete(guid);

            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
