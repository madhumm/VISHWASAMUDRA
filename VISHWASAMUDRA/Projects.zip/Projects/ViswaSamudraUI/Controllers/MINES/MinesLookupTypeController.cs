﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Providers.Assets;
using ViswasamudraCommonObjects.Mines;
using ViswasamudraCommonObjects.Mines.MinesSearch;
using System.Linq;
using ViswaSamudraUI.Providers.MINES;
using ViswaSamudraUI.Models;
using System.Reflection;

namespace ViswaSamudraUI.Controllers.MINES
{
    [CheckSession]
    public class MinesLookupTypeController : Controller
    {

        MinesLookupTypeProvider lookUpProvider = null;
        MinesLookupType lookupType = new MinesLookupType();
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public MinesLookupTypeController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            lookUpProvider = new MinesLookupTypeProvider(user);
        }
        public IActionResult Index(MinesLookupTypeSearch requestModel)
        {
            MinesLookupTypeSearch returnModel = new MinesLookupTypeSearch();

            if (requestModel.searchFilter != null)
            {
                returnModel.filterEnabled = true;
            }
            IEnumerable<MinesLookupType> list = LookUpList(requestModel.searchFilter).OrderByDescending(I => I.Id);
            returnModel.resultList = list;
            return View(returnModel);
        }


        public IEnumerable<MinesLookupType> LookUpList(MinesLookupType flookupType)
        {
            if (flookupType != null)
            {
                return lookUpProvider.GetLookupData(flookupType).OrderByDescending(I => I.Id);
            }
            else
            {
                return lookUpProvider.GetLookupData(lookupType).OrderByDescending(I => I.Id);
            }
        }

        public IActionResult Mineslookupops(Guid LookupGuid = new Guid())
        {
            if (LookupGuid == Guid.Empty)
            {
                MinesLookupType ioModel = new MinesLookupType();
                ioModel.Lock = 0;
                return View(ioModel);
            }
            MinesLookupType minesLookup = new MinesLookupType();
            lookupType.LookupGuid = LookupGuid;
            IEnumerable<MinesLookupType> list = LookUpList(lookupType);
            minesLookup = list.FirstOrDefault();
            if (minesLookup.Lock == 1)
            {
                minesLookup.IsLocked = true;
            }
            else
            {
                minesLookup.IsLocked = false;

            }
            return View(minesLookup);
        }
        public ActionResult MinesLookUpTypeModification(MinesLookupType model)
        {

            if (model.IsLocked == false)
            {
                model.Lock = 0;
            }
            else
            {
                model.Lock = 1;

            }

            return Ok(lookUpProvider.Add(model));
        }

        public IActionResult Delete(MinesLookupType model)
        {
            ResponseBody res = lookUpProvider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }

}
