﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Mines;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Providers.MINES;
using VSManagement.IOModels.DropDown;

namespace ViswaSamudraUI.Controllers.MINES
{
    [CheckSession]
    public class MinesLookupTypeValuesController : Controller
    {
        MinesLookupTypeValuesProvider MineslookUpTypeValueProvider = null;
        MinesLookupTypeValues lookupTypevalue = new MinesLookupTypeValues();
        MinesLookupType lookupType = new MinesLookupType();
        private Guid guidV;
        string user = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public MinesLookupTypeValuesController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            MineslookUpTypeValueProvider = new MinesLookupTypeValuesProvider(user);
        }
        public IActionResult Index(Guid LookupGuid, string Lookupname)
        {
            if (LookupGuid == Guid.Empty)
            {
                LookupGuid = (Guid)TempData["GuidValue"];
            }
            lookupTypevalue.LookupId = LookupGuid;
            lookupType.LookupGuid = LookupGuid;
            ViewBag.lookupname = Lookupname;
            ViewBag.LookupGuid = LookupGuid;
            return View(Getdata(lookupTypevalue));
        }
        public IEnumerable<MinesLookupTypeValues> Getdata(MinesLookupTypeValues lookupTypevalue)
        {
            IEnumerable<MinesLookupTypeValues> list = MineslookUpTypeValueProvider.GetLookupData(lookupTypevalue).ToList();
            if (list.Count() > 0)
            {
                ViewBag.lookupname = list.Select(x => x.LookupName).FirstOrDefault();
            }

            if (list != null & list.Count() > 0)
            {
                list = list.OrderBy(x => x.OrderId);
            }

            return list;
        }
        public ActionResult MinesLookUpTypeModification(MinesLookupTypeValues model)
        {
            TempData["GuidValue"] = model.LookupId;
            return Ok(MineslookUpTypeValueProvider.Add(model));
        }
        public IActionResult Delete(MinesLookupTypeValues model)
        {
            lookupTypevalue.LookupId = model.LookupId;
            TempData["GuidValue"] = lookupTypevalue.LookupId;
            ResponseBody res = MineslookUpTypeValueProvider.Delete(model);
            if (res != null && res.Success == true)
            {
                var GuidValue = lookupTypevalue.LookupId;
                TempData["GuidValue"] = GuidValue;
                return RedirectToAction("Index", "MinesLookupTypeValues", model.LookupId, model.LookupValueName);
            }
            else
            {
                return Ok(res);
            }
        }

        public ActionResult SaveMinesLookupvaluesOrder(MinesLookupTypeValues model)
        {
            ResponseBody response = MineslookUpTypeValueProvider.SaveOrder(model);
            return Ok(response);
        }

    }
}
