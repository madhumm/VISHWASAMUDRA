﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Filters;
using ViswasamudraCommonObjects.Asset.SearchForms;
using Microsoft.AspNetCore.Http;
using ViswasamudraCommonObjects.Project;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class ProjectTypesController : Controller
    {
        ProjectTypesProvider provider = null;
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectTypes aProjectTypesSearch = new ProjectTypes();
        private readonly IHttpContextAccessor _httpContextAccessor;
        string user = string.Empty;
        public ProjectTypesController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            provider = new ProjectTypesProvider(user);

        }
        public IActionResult Index(ProjectTypesSearch requestModel)
        {
            ProjectTypesSearch returnModel = new ProjectTypesSearch();
            if (requestModel.searchFilter != null)
            {
                //ViewBag.Status = lookUpProvider.GetSelectList("", requestModel.searchFilter.Status);
                returnModel.filterEnabled = true;
            }
            else
            {
               // ViewBag.Status = lookUpProvider.GetSelectList("");
            }

            IEnumerable<ProjectTypes> list = provider.GetProjectTypes(requestModel.searchFilter).OrderBy(l => l.Id);
            returnModel.resultList = list;
            return View(returnModel);
        }

        public async Task<IActionResult> ProjectTypesOps(ProjectTypes ioModel)
        {
            if (ioModel.Guid == Guid.Empty)
            {
              //  ViewBag.Status = lookUpProvider.GetSelectList("");
                return View(ioModel);
            }
            IEnumerable<ProjectTypes> list = provider.GetAllProjectTypes(ioModel);
            var projectTypes = list.FirstOrDefault();
          //  ViewBag.Status = lookUpProvider.GetSelectList("", projectTypes.Status);
            return View(projectTypes);
        }

        public ActionResult ProjectTypesModification(ProjectTypes model)
        {
            return Ok(provider.Add(model));
            //return Content(status);
        }

        public IActionResult Delete(ProjectTypes model)
        {
            ResponseBody res = provider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
