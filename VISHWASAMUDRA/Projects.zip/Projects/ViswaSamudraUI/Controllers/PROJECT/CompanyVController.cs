﻿using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;
using System;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswaSamudraUI.Providers.Assets;
using ViswasamudraCommonObjects.Asset;
using System.Linq;
using ViswaSamudraUI.Models;
using System.Web.Http.Results;
using Microsoft.AspNetCore.Http;
using ViswaSamudraUI.Filters;
using ViswasamudraCommonObjects.Project;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
	public class CompanyVController : Controller
	{
		CompanyVProvider provider = null;
		LookUpProvider lookUpProvider = new LookUpProvider();
		CompanyV aCompanyVSearch = new CompanyV();
		string user = string.Empty;

		private readonly IHttpContextAccessor _httpContextAccessor;
		public CompanyVController(IHttpContextAccessor httpContextAccessor)
		{
			_httpContextAccessor = httpContextAccessor;
			user = _httpContextAccessor.HttpContext.Session.GetString("user");
			provider = new CompanyVProvider(user);
		}
		public IActionResult Index(CompanyVSearch requestModel)
		{
			CompanyVSearch returnModel = new CompanyVSearch();
			if (requestModel.searchFilter != null)
			{
				ViewBag.ParentCompany = provider.GetSelectList(0, requestModel.searchFilter.ParentCompany);
				returnModel.filterEnabled = true;
			}
			else
			{
				ViewBag.ParentCompany = provider.GetSelectList(0);
			}

			IEnumerable<CompanyV> list = provider.GetCompanyV(requestModel.searchFilter).OrderBy(l => l.Id);
			returnModel.resultList = list;
			return View(returnModel);
		}

		public async Task<IActionResult> CompanyVOps(CompanyV ioModel)
		{
			if (ioModel.Guid == Guid.Empty)
			{
                ViewBag.ParentCompany = provider.GetSelectList(0);
                return View(ioModel);
			}
			IEnumerable<CompanyV> list = provider.GetAllCompanyV(ioModel);
			var CompanyV = list.FirstOrDefault();
			ViewBag.ParentCompany = provider.GetSelectList(CompanyV.Id, CompanyV.ParentCompany);
			return View(CompanyV);
		}

		public ActionResult CompanyVModification(CompanyV model)
		{
			return Ok(provider.Add(model));
			//return Content(status);
		}

		public IActionResult Delete(CompanyV model)
		{
			ResponseBody res = provider.Delete(model);
			if (res != null && res.Success == true)
			{
				return RedirectToAction("Index");
			}
			else
			{
				return Ok(res);
			}
		}
	}
}

