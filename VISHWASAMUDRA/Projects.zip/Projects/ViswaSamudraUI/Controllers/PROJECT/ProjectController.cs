﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using ViswaSamudraUI.Providers.Assets;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Filters;
using ViswasamudraCommonObjects.Asset.SearchForms;
using Microsoft.AspNetCore.Http;
using ViswasamudraCommonObjects.Project;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class ProjectController : Controller
    {
        ProjectProvider provider = null;
        ProjectTypesProvider prjTypesProvider = null;
        LookUpProvider lookUpProvider = new LookUpProvider();
        string user = string.Empty;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public ProjectController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            provider = new ProjectProvider(user);
            prjTypesProvider = new ProjectTypesProvider(user);
        }
        public IActionResult Index(Projectsearch requestModel)
        {
            Projectsearch returnModel = new Projectsearch();
            if (requestModel.searchFilter!=null)
            {
                ViewBag.ProjectType = prjTypesProvider.GetSelectList(0, requestModel.searchFilter.ProjectType.ToString());
                ViewBag.Company = provider.GetCompanySelectList(0, requestModel.searchFilter.Company);
                returnModel.filterEnabled = true;
            }
            else
            {
                ViewBag.ProjectType = prjTypesProvider.GetSelectList(0);
                ViewBag.Company = provider.GetCompanySelectList(0);
            }
            IEnumerable<Project> list = provider.GetAll(requestModel.searchFilter).OrderByDescending(p=>p.Id);
            returnModel.resultList = list;
            return View(returnModel);
        }

		public async Task<IActionResult> ProjectOps(Project ProjectIoModel)
        {
            if (ProjectIoModel.Guid == Guid.Empty)
            {
                ViewBag.ProjectType = prjTypesProvider.GetSelectList(0);
                ViewBag.Company = provider.GetCompanySelectList(0);
                return View(ProjectIoModel);
            }
            var result = provider.GetAllProject(ProjectIoModel).FirstOrDefault();
            ViewBag.ProjectType = prjTypesProvider.GetSelectList(0, ProjectIoModel.ProjectType);
            ViewBag.Company = provider.GetCompanySelectList(0,result.Company);
            return View(result);
        }

        public ActionResult ProjectModification(Project model)
        {
            model.RecordStatus = 1;
            return Ok(provider.Add(model));            
        }

        public ActionResult Delete(Project model)
        {
            ResponseBody res = provider.Delete(model);
            if (res != null && res.Success == true)
            {
                return RedirectToAction("Index");                
            }
            else
            {
                return Ok(res);
            }
        }
    }
}
