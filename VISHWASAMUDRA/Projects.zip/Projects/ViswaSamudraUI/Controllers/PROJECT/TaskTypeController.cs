﻿using Microsoft.AspNetCore.Mvc;

namespace ViswaSamudraUI.Controllers.PROJECT
{
    public class TaskTypeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
