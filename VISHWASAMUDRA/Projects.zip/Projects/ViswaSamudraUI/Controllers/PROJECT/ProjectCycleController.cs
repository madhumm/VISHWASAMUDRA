﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Project;
using ViswaSamudraUI.Filters;
using ViswaSamudraUI.Models;
using ViswaSamudraUI.Providers.Assets;

namespace ViswaSamudraUI.Controllers.WINGS
{
    [CheckSession]
    public class ProjectCycleController : Controller
    {
        string user = string.Empty;
        ProjectTypesProvider prjTypesProvider = null;
        LookUpProvider lookUpProvider = new LookUpProvider();
        ProjectCycleProvider projcycleProvider= null;

        private readonly IHttpContextAccessor _httpContextAccessor;
        public ProjectCycleController(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
            user = _httpContextAccessor.HttpContext.Session.GetString("user");
            projcycleProvider = new ProjectCycleProvider(user);
            prjTypesProvider = new ProjectTypesProvider(user);
        }
        public IActionResult Index(ProjectCycle request)
        {
            ProjectCycle returnModel = new ProjectCycle();
            if (request != null && Guid.Empty != request.ProjectType)
            {
                returnModel.ProjectType = request.ProjectType;
                returnModel.resultList = projcycleProvider.GetAllProjectCycles(returnModel).OrderBy(l => l.OrderNo).ToList();
                ViewBag.ProjectTypes = prjTypesProvider.GetSelectList(0, request.ProjectType.ToString());
            }
            else
            {
                returnModel.resultList = new List<ProjectCycle>();
                ViewBag.ProjectTypes = prjTypesProvider.GetSelectList(0);
            }
            ViewBag.ProjectCycle = lookUpProvider.GetSelectList("PCYCLE", "");

            return View(returnModel);
        }

        public ActionResult SaveProjectOrder(ProjectCycle model)
        {
            ResponseBody response = projcycleProvider.Save(model);
            return Ok(response);
        }
        
    }
}
