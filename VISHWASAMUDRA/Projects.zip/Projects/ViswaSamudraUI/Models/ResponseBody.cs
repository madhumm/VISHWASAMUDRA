﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ViswaSamudraUI.Models
{
    public class ResponseBody
    {
        public bool Success { get; set; }
        public string Message { get; set; }
        public string Header { get; set; }
    }
}
