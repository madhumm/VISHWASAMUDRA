﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System;
using ViswasamudraCommonObjects.Mines;
using ViswaSamudraUI.Models;

namespace ViswaSamudraUI.Providers.MINES
{
    public class MineralCategorySizesProvider
    {
        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;

        public MineralCategorySizesProvider()
        {
        }

        public MineralCategorySizesProvider(string userName)
        {
            _userName = userName;
        }

        public IEnumerable<MineralCategorySizes> GetAll()
        {
            return (IEnumerable<MineralCategorySizes>)ch.GetRequest<MineralCategorySizes>("MineralCategorySizes");
        }

        public IEnumerable<MineralCategorySizes> GetAllMineralCategorySizes(MineralCategorySizes model = null)
        {
            if (model == null)
                return (IEnumerable<MineralCategorySizes>)ch.GetRequest<MineralCategorySizes>("MineralCategorySizes");
            else
                return (IEnumerable<MineralCategorySizes>)ch.GetDetailsRequest<MineralCategorySizes>("MineralCategorySizes/search", model);
        }

        private List<MineralCategorySizes> GetComboData()
        {
            return (List<MineralCategorySizes>)ch.GetRequest<MineralCategorySizes>("MineralCategorySizes/combo");
        }

        public List<SelectListItem> GetCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetComboData())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.MineralCategoryId.ToString(), Text = x.MineralCategoryName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.MineralCategoryId.ToString(), Text = x.MineralCategoryName };
                newList.Add(selListItem);
            }
            return newList;
        }

        public List<MineralCategorySizes> GetByGuId(Guid guid)
        {
            return (List<MineralCategorySizes>)ch.GetDetailsRequest<List<MineralCategorySizes>>("MineralCategorySizes/GetByGuId?guid=" + guid);
        }

        public ResponseBody Add(MineralCategorySizes model = null)
        {
            if (model != null)
            {
                if (!model.MineralCategorySizeId.HasValue || model.MineralCategorySizeId == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    var res = ch.PostRequest<MineralCategorySizes>("MineralCategorySizes/Create", model);
                    return res;

                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<MineralCategorySizes>("MineralCategorySizes/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(Guid? guid)
        {
            MineralCategorySizes model = new MineralCategorySizes();
            model.MineralCategorySizeId = guid;
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;

            return ch.PostRequest<MineralCategorySizes>("MineralCategorySizes/Delete", model);
        }
    }
}
