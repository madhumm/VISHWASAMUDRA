﻿using System.Collections.Generic;
using System;
using ViswaSamudraUI.Models;
using ViswasamudraCommonObjects.Mines;

namespace ViswaSamudraUI.Providers.MINES
{
    public class MinesLookupTypeValuesProvider
    {
        string _userName = string.Empty;
        public MinesLookupTypeValuesProvider()
        {
        }
        public MinesLookupTypeValuesProvider(string userName)
        {
            _userName = userName;
        }
        CommonHelper ch = new CommonHelper();

        public IEnumerable<MinesLookupTypeValues> GetAllLookup(string lookUpType)
        {

            return (IEnumerable<MinesLookupTypeValues>)ch.GetRequest<MinesLookupTypeValues>("MineslookupTypeValues/" + lookUpType);

        }

        public IEnumerable<MinesLookupTypeValues> GetLookupData(MinesLookupTypeValues lookupType)
        {

            return (IEnumerable<MinesLookupTypeValues>)ch.GetDetailsRequest<MinesLookupTypeValues>("MineslookupTypeValues/search", lookupType);
        }


       

        public ResponseBody Add(MinesLookupTypeValues model = null)
        {
            if (model != null)
            {
                if (model.Guid == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    return ch.PostRequest<MinesLookupTypeValues>("MineslookupTypeValues/Create", model);
                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<MinesLookupTypeValues>("MineslookupTypeValues/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(MinesLookupTypeValues model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<MinesLookupTypeValues>("MineslookupTypeValues/Delete", model);
        }
        public ResponseBody SaveOrder(MinesLookupTypeValues model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.PostRequest<MinesLookupTypeValues>("MineslookupTypeValues/SaveOrder", model);
        }

    }
}
