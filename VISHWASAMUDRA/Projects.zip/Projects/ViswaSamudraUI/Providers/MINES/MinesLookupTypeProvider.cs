﻿using System.Collections.Generic;
using System;
using ViswasamudraCommonObjects.Mines;
using ViswaSamudraUI.Models;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;

namespace ViswaSamudraUI.Providers.MINES
{
    public class MinesLookupTypeProvider
    {
        string _userName = string.Empty;
        public MinesLookupTypeProvider()
        {
        }
        public MinesLookupTypeProvider(string userName)
        {
            _userName = userName;
        }
        CommonHelper ch = new CommonHelper();

        public IEnumerable<MinesLookupType> GetAllLookup(string lookUpType)
        {            
            return (IEnumerable<MinesLookupType>)ch.GetRequest<MinesLookupType>("MineslookupType/" + lookUpType);
        }

        public IEnumerable<MinesLookupType> GetLookupData(MinesLookupType lookupType)
        {

            return (IEnumerable<MinesLookupType>)ch.GetDetailsRequest<MinesLookupType>("MineslookupType/search", lookupType);
        }




        public ResponseBody Add(MinesLookupType model = null)
        {
            if (model != null)
            {
                if (model.LookupGuid == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    return ch.PostRequest<MinesLookupType>("MineslookupType/Create", model);
                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<MinesLookupType>("MineslookupType/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(MinesLookupType model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<MinesLookupType>("MineslookupType/Delete", model);
        }

        public List<SelectListItem> GetSelectList(string code, string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);
            foreach (var x in GetAllLookup(code).Select(i => new { i.LookupName, i.LookupCode, i.LookupGuid }))
            {
                if (SelectedValue != null && x.LookupGuid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.LookupGuid.ToString(), Text = x.LookupName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.LookupGuid.ToString(), Text = x.LookupName };

                newList.Add(selListItem);
            }
            return newList;
        }        
    }
}
