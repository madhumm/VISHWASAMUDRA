﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System;
using ViswasamudraCommonObjects.Mines;
using ViswaSamudraUI.Models;
using Microsoft.AspNetCore.Http;
using System.Linq;
using DocumentFormat.OpenXml.EMMA;

namespace ViswaSamudraUI.Providers.MINES
{
    public class MineLeaseHoldersProvider
    {
        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;

        private readonly IHttpContextAccessor _httpContextAccessor;
        string _token = string.Empty;
        public MineLeaseHoldersProvider(string userName, IHttpContextAccessor httpContextAccessor = null)
        {
            _userName = userName;
            _httpContextAccessor = httpContextAccessor;
            ch = new CommonHelper(_httpContextAccessor);
        }
        public MineLeaseHoldersProvider(string userName)
        {
            _userName = userName;
        }
        public IEnumerable<MineLeaseHolders> GetAll()
        {
            return (IEnumerable<MineLeaseHolders>)ch.GetRequest<MineLeaseHolders>("MineLeaseHolder");
        }

        public IEnumerable<MineLeaseHolders> GetAllMineLeaseHolders(MineLeaseHolders model = null)
        {
            if (model == null)
            {
                return (IEnumerable<MineLeaseHolders>)ch.GetRequest<MineLeaseHolders>("MineLeaseHolder");
            }
            else
            {
                model.FromApp = "Web";
                return (IEnumerable<MineLeaseHolders>)ch.GetDetailsRequest<MineLeaseHolders>("MineLeaseHolder/searchWeb", model);
            }
        }
        public List<MineLeaseHolders> GetComboData(bool surveyRequired)
        {
            return (List<MineLeaseHolders>)ch.GetDetailsRequest<MineLeaseHolders>("MineLeaseHolder/search", new MineLeaseHolders { SurveyRequired = surveyRequired, RequiredLeasedMines = true });
        }

        public List<SelectListItem> GetCombo(string SelectedValue, bool surveyRequired)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            List<MineLeaseHolders> list = GetComboData(surveyRequired);
            foreach (var x in list)
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.LeaseHolderId.ToString(), Text = x.LeaseHolderName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.LeaseHolderId.ToString(), Text = x.LeaseHolderName };
                newList.Add(selListItem);
            }
            return newList;
        }

        public ResponseBody Add(MineLeaseHolders model = null)
        {
            if (model != null)
            {
                if (model.LeaseHolderId == Guid.Empty || model.LeaseHolderId == null)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    return ch.PostRequest<MineLeaseHolders>("MineLeaseHolder/Create", model);
                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<MineLeaseHolders>("MineLeaseHolder/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(MineLeaseHolders model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<MineLeaseHolders>("MineLeaseHolder/Delete", model);
        }
    }
}
