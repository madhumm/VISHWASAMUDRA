﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using ViswasamudraCommonObjects.Mines;
using ViswasamudraCommonObjects.SearchForms.Mines;
using ViswaSamudraUI.Models;
using VSManagement.IOModels.DropDown;

namespace ViswaSamudraUI.Providers.Assets
{
    public class PermitRequestProvider
    {
        string _userName = string.Empty;
        Guid userGuid = Guid.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        CommonHelper ch = new CommonHelper();
        public PermitRequestProvider(string userName, IHttpContextAccessor httpContextAccessor = null)
        {
            _userName = userName;
            _httpContextAccessor = httpContextAccessor;
            userGuid = Guid.Parse(_httpContextAccessor.HttpContext.Session.GetString("userGuid"));
            ch = new CommonHelper(_httpContextAccessor);
        }

        public IEnumerable<PermitRequest> GetAllHeaders()
        {
            return (IEnumerable<PermitRequest>)ch.GetDetailsRequest<PermitRequest>("PermitRequest");
        }

        public IEnumerable<PermitRequest> GetHeaders(PermitRequest model)
        {
            return (IEnumerable<PermitRequest>)ch.GetDetailsRequest<PermitRequest>("PermitRequest/header/search", model);
        }


        public IEnumerable<PermitRequest> GetAll(PermitRequest model)
        {
            return (IEnumerable<PermitRequest>)ch.GetDetailsRequest<PermitRequest>("PermitRequest/search", model);
        }

        public ResponseBody Assign(PermitRequest model = null)
        {
            model.header.LastUpdatedBy = userGuid;
            model.header.LastUpdatedDateTime = DateTime.Now;
            return ch.PostRequest<PermitRequest>("PermitRequest/Assign", model);
        }

        public ResponseBody Add(PermitRequest model = null)
        {
            if (model.header.PrHeaderId == System.Guid.Empty || model.header.PrHeaderId == null)
            {
                model.header.CreatedBy = _userName;
                model.header.CreatedDateTime = DateTime.Now;
                return ch.PostRequest<PermitRequest>("PermitRequest/Create", model);
            }
            else
            {
                model.header.LastUpdatedBy = userGuid;
                model.header.LastUpdatedDateTime = DateTime.Now;
                return ch.PostRequest<PermitRequest>("PermitRequest/Update", model);
            }
        }

        public ResponseBody Delete(PermitRequest model)
        {
            model.header.LastUpdatedBy = userGuid;
            model.header.LastUpdatedDateTime = DateTime.Now;
            return ch.PostRequest<PermitRequest>("PermitRequest/Delete", model);
        }

        public ResponseBody Approve(PermitRequest model)
        {
            return ch.PostRequest<PermitRequest>("PermitRequest/Approve", model);
        }
    }
}
