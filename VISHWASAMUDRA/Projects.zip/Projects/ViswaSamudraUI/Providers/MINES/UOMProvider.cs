﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System;
using ViswasamudraCommonObjects.GlobalData;
using mines = ViswasamudraCommonObjects.Mines;
using ViswaSamudraUI.Models;
using globaldata = ViswasamudraCommonObjects.GlobalData;

namespace ViswaSamudraUI.Providers.MINES
{
    public class UOMProvider
    {
        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;
        public UOMProvider()
        {
        }
        public UOMProvider(string userName)
        {
            _userName = userName;
        }
        public IEnumerable<UOM> GetAll()
        {
            return (IEnumerable<UOM>)ch.GetRequest<UOM>("UOM");
        }

        public IEnumerable<UOM> GetAllUOMs(UOM model = null)
        {
            if (model == null)
                return (IEnumerable<UOM>)ch.GetRequest<UOM>("UOM");
            else
                return (IEnumerable<UOM>)ch.GetDetailsRequest<UOM>("UOM/Uomsearch", model);
        }

        public IEnumerable<mines.District> GetDistricts(Guid? StateId)
        {
            if (StateId == null || StateId == new Guid())
            {
                return (List<mines.District>)ch.GetRequest<mines.District>("UOM/Districts");
            }
            else
            {
                return (List<mines.District>)ch.GetRequest<mines.District>("UOM/Districts/" + StateId);
            }
        }

        public IEnumerable<mines.State> GetStates()
        {
            return (List<mines.State>)ch.GetRequest<mines.State>("UOM/States");

        }

        public ResponseBody Add(UOM model = null)
        {
            if (model != null)
            {
                if (model.UomId == Guid.Empty || model.UomId == null)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    var res = ch.PostRequest<UOM>("UOM/Create", model);
                    return res;

                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<UOM>("UOM/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(UOM model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<UOM>("UOM/Delete", model);
        }

        private List<UOM> GetComboData()
        {
            return (List<UOM>)ch.GetRequest<UOM>("UOM");
        }

        public List<SelectListItem> GetCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetComboData())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.UomId.ToString(), Text = x.UomName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.UomId.ToString(), Text = x.UomName };
                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetCubicCombo()
        {
            List<SelectListItem> newList = new List<SelectListItem>();

            foreach (var x in GetAllUOMs(new UOM { UomCode = "CBM" }))
            {
                SelectListItem selListItem = new SelectListItem() { Value = x.UomId.ToString(), Text = x.UomName, Selected = true };
                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetStateCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetStates())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.StateId.ToString(), Text = x.StateName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.StateId.ToString(), Text = x.StateName };
                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetDistrctCombo(string SelectedValue, Guid? StateId)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetDistricts(StateId))
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.DistrictId.ToString(), Text = x.DistrictName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.DistrictId.ToString(), Text = x.DistrictName };
                newList.Add(selListItem);
            }
            return newList;
        }

        public IEnumerable<globaldata.Mandal> GetMandals()
        {
            return (List<globaldata.Mandal>)ch.GetRequest<globaldata.Mandal>("UOM/Mandals");
        }

        public List<SelectListItem> GetMandalsCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };

            List<SelectListItem> newList = new List<SelectListItem>();

            newList.Add(selListItem);

            foreach (var x in GetMandals())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.MandalName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.MandalName };

                newList.Add(selListItem);
            }

            return newList;
        }

        public IEnumerable<Village> GetVillages()
        {
            return (List<Village>)ch.GetRequest<Village>("UOM/Villages");
        }

        public List<SelectListItem> GetVillagesCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };

            List<SelectListItem> newList = new List<SelectListItem>();

            newList.Add(selListItem);

            foreach (var x in GetVillages())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.VillageName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.VillageName };

                newList.Add(selListItem);
            }

            return newList;
        }

        public IEnumerable<Pincode> GetPinCodes()
        {
            return (List<Pincode>)ch.GetRequest<Pincode>("UOM/PinCodes");
        }

        public List<SelectListItem> GetPinCodesCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };

            List<SelectListItem> newList = new List<SelectListItem>();

            newList.Add(selListItem);

            foreach (var x in GetPinCodes())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.PincodeName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.PincodeName };

                newList.Add(selListItem);
            }

            return newList;
        }

        public List<SelectListItem> GetPinCodeCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };

            List<SelectListItem> newList = new List<SelectListItem>();

            newList.Add(selListItem);
            IEnumerable<Pincode> pincodes = GetPinCodes();
            foreach (var x in pincodes)
            {
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.PincodeName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.PincodeName };

                newList.Add(selListItem);
            }

            return newList;
        }
    }
}
