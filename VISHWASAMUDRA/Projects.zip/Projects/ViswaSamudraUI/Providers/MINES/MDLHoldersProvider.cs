﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System;
using ViswasamudraCommonObjects.Mines;
using ViswaSamudraUI.Models;
using Microsoft.AspNetCore.Http;
using ViswasamudraCommonObjects.MINES;

namespace ViswaSamudraUI.Providers.MINES
{
    public class MDLHoldersProvider
    {
        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;

        private readonly IHttpContextAccessor _httpContextAccessor;
        string _token = string.Empty;

        public MDLHoldersProvider(string userName, IHttpContextAccessor httpContextAccessor = null)
        {
            _userName = userName;
            _httpContextAccessor = httpContextAccessor;
            ch = new CommonHelper(_httpContextAccessor);
        }

        public MDLHoldersProvider(string userName)
        {
            _userName = userName;
        }

        public IEnumerable<MDLHolder> GetAll()
        {
            return (IEnumerable<MDLHolder>)ch.GetRequest<MDLHolder>("MdlHolders");
        }

        public IEnumerable<MDLHolder> GetAllMdlHolders(MDLHolder model = null)
        {
            if (model == null)
                return (IEnumerable<MDLHolder>)ch.GetRequest<MDLHolder>("MdlHolders");
            else
                return (IEnumerable<MDLHolder>)ch.GetDetailsRequest<MDLHolder>("MdlHolders/search", model);
        }

        private List<MdlHolders> GetComboData()
        {
            return (List<MdlHolders>)ch.GetRequest<MdlHolders>("MDLHolders");
        }

        public List<SelectListItem> GetCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetComboData())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.MdlhId.ToString(), Text = x.MdlhName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.MdlhId.ToString(), Text = x.MdlhName };
                newList.Add(selListItem);
            }
            return newList;
        }

        public MDLHolder GetByGuId(Guid guid)
        {
            return (MDLHolder)ch.GetDetailsRequest<MDLHolder>("MDLHolders/GetByGuId?guid=" + guid);
        }

        public ResponseBody Add(MDLHolder model = null)
        {
            if (model != null)
            {
                if (!model.MdlhId.HasValue || model.MdlhId == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    var res = ch.PostRequest<MDLHolder>("MDLHolders/Create", model);
                    return res;

                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<MDLHolder>("MDLHolders/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(Guid? guid)
        {
            MDLHolder model = new MDLHolder();
            model.MdlhId = guid;
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;

            return ch.PostRequest<MDLHolder>("MDLHolders/Delete", model);
        }
    }
}
