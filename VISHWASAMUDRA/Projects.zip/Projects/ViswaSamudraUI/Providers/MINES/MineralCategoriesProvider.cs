﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System;
using ViswasamudraCommonObjects.Mines;
using ViswaSamudraUI.Models;

namespace ViswaSamudraUI.Providers.MINES
{
    public class MineralCategoriesProvider
    {
        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;

        public MineralCategoriesProvider()
        {
        }

        public MineralCategoriesProvider(string userName)
        {
            _userName = userName;
        }

        public IEnumerable<MineralCategories> GetAll()
        {
            return (IEnumerable<MineralCategories>)ch.GetRequest<MineralCategories>("MineralCategories");
        }

        public IEnumerable<MineralCategories> GetAllMineralCategories(MineralCategories model = null)
        {
            if (model == null)
                return (IEnumerable<MineralCategories>)ch.GetRequest<MineralCategories>("MineralCategories");
            else
                return (IEnumerable<MineralCategories>)ch.GetDetailsRequest<MineralCategories>("MineralCategories/search", model);
        }

        private List<MineralCategories> GetComboData()
        {
            return (List<MineralCategories>)ch.GetRequest<MineralCategories>("MineralCategories/combo");
        }

        public List<SelectListItem> GetCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetComboData())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.MineralCategoryId.ToString(), Text = x.MineralCategoryName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.MineralCategoryId.ToString(), Text = x.MineralCategoryName };
                newList.Add(selListItem);
            }
            return newList;
        }

        public MineralCategories GetByGuId(Guid guid)
        {
            return (MineralCategories)ch.GetDetailsRequest<MineralCategories>("MineralCategories/GetByGuId?guid=" + guid);
        }

        public ResponseBody Add(MineralCategories model = null)
        {
            if (model != null)
            {
                if (!model.MineralCategoryId.HasValue || model.MineralCategoryId == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    var res = ch.PostRequest<MineralCategories>("MineralCategories/Create", model);
                    return res;

                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<MineralCategories>("MineralCategories/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(Guid? guid)
        {
            MineralCategories model = new MineralCategories();
            model.MineralCategoryId = guid;
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;

            return ch.PostRequest<MineralCategories>("MineralCategories/Delete", model);
        }
    }
}
