﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System;
using ViswasamudraCommonObjects.Mines;
using ViswaSamudraUI.Models;

namespace ViswaSamudraUI.Providers.MINES
{
    public class MineLocationsProvider
    {
        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;

        public MineLocationsProvider()
        {
        }

        public MineLocationsProvider(string userName)
        {
            _userName = userName;
        }

        public IEnumerable<MineLocations> GetAll()
        {
            return (IEnumerable<MineLocations>)ch.GetRequest<MineLocations>("MineLocation");
        }

        public IEnumerable<MineLocations> GetAllMinerals(MineLocations model = null)
        {
            if (model == null)
                return (IEnumerable<MineLocations>)ch.GetRequest<MineLocations>("MineLocation");
            else
                return (IEnumerable<MineLocations>)ch.GetDetailsRequest<MineLocations>("MineLocation/search", model);
        }

        private List<MineLocations> GetComboData()
        {
            return (List<MineLocations>)ch.GetRequest<MineLocations>("MineLocation/Combo");
        }

        public List<SelectListItem> GetCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetComboData())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.LocationId.ToString(), Text = x.LocationName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.LocationId.ToString(), Text = x.LocationName };
                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetMineralCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetComboData())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.LocationId.ToString(), Text = x.MineralName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.LocationId.ToString(), Text = x.MineralName };
                newList.Add(selListItem);
            }
            return newList;
        }

        public MineLocations GetByGuId(Guid guid)
        {
            return (MineLocations)ch.GetDetailsRequest<MineLocations>("MineLocation/GetByGuId?guid=" + guid);
        }

        public ResponseBody Add(MineLocations model = null)
        {
            if (model != null)
            {
                if (!model.LocationId.HasValue || model.LocationId == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    var res = ch.PostRequest<MineLocations>("MineLocation/Create", model);
                    return res;

                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<MineLocations>("MineLocation/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(Guid? guid)
        {
            MineLocations model = new MineLocations();
            model.LocationId = guid;
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;

            return ch.PostRequest<MineLocations>("MineLocation/Delete", model);
        }
    }
}
