﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using ViswasamudraCommonObjects.Mines;
using ViswasamudraCommonObjects.SearchForms.Mines;
using ViswaSamudraUI.Models;
using VSManagement.IOModels.DropDown;

namespace ViswaSamudraUI.Providers.Assets
{
    public class TransitFormIssueProvider
    {
        string _userName = string.Empty;
        Guid userGuid = Guid.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        CommonHelper ch = new CommonHelper();
        public TransitFormIssueProvider(string userName, IHttpContextAccessor httpContextAccessor = null)
        {
            _userName = userName;
            _httpContextAccessor = httpContextAccessor;
            userGuid = Guid.Parse(_httpContextAccessor.HttpContext.Session.GetString("userGuid"));
            ch = new CommonHelper(_httpContextAccessor);
        }

        public IEnumerable<TransitFormIssue> GetAllHeaders()
        {
            return (IEnumerable<TransitFormIssue>)ch.GetDetailsRequest<TransitFormIssue>("TransitFormsIssue");
        }

        public IEnumerable<PermitRequest> GetHeaders(PermitRequest model)
        {
            return (IEnumerable<PermitRequest>)ch.GetDetailsRequest<PermitRequest>("TransitFormsIssue/header/search", model);
        }


        public IEnumerable<TransitFormIssue> GetAll(TransitFormIssue model)
        {
            return (IEnumerable<TransitFormIssue>)ch.GetDetailsRequest<TransitFormIssue>("TransitFormsIssue/search", model);
        }

        public ResponseBody IssueTransit(TransitFormIssue model = null)
        {
            model.header.CreatedBy = _userName;
            model.header.CreatedDateTime = DateTime.Now;
            return ch.PostRequest<TransitFormIssue>("TransitFormsIssue/Create", model);
        }

        public ResponseBody Add(PermitRequest model = null)
        {
            if (model.header.PrHeaderId == System.Guid.Empty || model.header.PrHeaderId == null)
            {
                model.header.CreatedBy = _userName;
                model.header.CreatedDateTime = DateTime.Now;
                return ch.PostRequest<PermitRequest>("PermitRequest/Create", model);
            }
            else
            {
                model.header.LastUpdatedBy = userGuid;
                model.header.LastUpdatedDateTime = DateTime.Now;
                return ch.PostRequest<PermitRequest>("PermitRequest/Update", model);
            }
        }

        public ResponseBody Delete(PermitRequest model)
        {
            model.header.LastUpdatedBy = userGuid;
            model.header.LastUpdatedDateTime = DateTime.Now;
            return ch.PostRequest<PermitRequest>("PermitRequest/Delete", model);
        }

        public ResponseBody Approve(PermitRequest model)
        {
            return ch.PostRequest<PermitRequest>("PermitRequest/Approve", model);
        }
    }
}
