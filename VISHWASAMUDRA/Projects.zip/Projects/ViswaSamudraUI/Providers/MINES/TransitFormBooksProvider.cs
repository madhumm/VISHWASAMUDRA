﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Mines;
using ViswaSamudraUI.Models;
using io = ViswasamudraCommonObjects.Mines;

namespace ViswaSamudraUI.Providers.MINES
{
    public class TransitFormBooksProvider
    {
        string _userName = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        CommonHelper ch = new CommonHelper();

        public TransitFormBooksProvider(string userName, IHttpContextAccessor httpContextAccessor = null)
        {
            _userName = userName;
            _httpContextAccessor = httpContextAccessor;
            ch = new CommonHelper(_httpContextAccessor);
        }

        public IEnumerable<io.TransitFormBooks> GetAll()
        {
            return (IEnumerable<io.TransitFormBooks>)ch.GetRequest<io.TransitFormBooks>("TransitFormBooks");
        }

		public io.TransitFormBooks GetByGuId(Guid? guid)
		{
			return (io.TransitFormBooks)ch.GetDetailsRequest<io.TransitFormBooks>("TransitFormBooks/GetByGuId?guid=" + guid);
		}

        public ResponseBody Add(io.TransitFormBooks model = null)
        {
            if (model != null)
            {
                if (model.TfBookId == null || model.TfBookId == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    var res = ch.PostRequest<io.TransitFormBooks>("TransitFormBooks/Create", model);
                    return res;

                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<io.TransitFormBooks>("TransitFormBooks/Update", model);
                }
            }
            else
                return null;
        }        

        public ResponseBody Delete(Guid guid)
        {
            io.TransitFormBooks model = new io.TransitFormBooks();
            model.TfBookId= guid;
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;

            return ch.PostRequest<io.TransitFormBooks>("TransitFormBooks/Delete", model);
        }

        private List<TransitFormBooks> GetComboData()
        {
            return (List<TransitFormBooks>)ch.GetRequest<TransitFormBooks>("TransitFormBooks");
        }

        public List<SelectListItem> GetCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetComboData())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.TfBookId.ToString(), Text = x.TfBookNo, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.TfBookId.ToString(), Text = x.TfBookNo };
                newList.Add(selListItem);
            }
            return newList;
        }
    }
}
