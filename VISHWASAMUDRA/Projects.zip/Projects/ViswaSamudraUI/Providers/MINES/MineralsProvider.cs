﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using System;
using ViswasamudraCommonObjects.Mines;
using ViswaSamudraUI.Models;

namespace ViswaSamudraUI.Providers.MINES
{
    public class MineralsProvider
    {
        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;

        public MineralsProvider()
        {
        }

        public MineralsProvider(string userName)
        {
            _userName = userName;
        }

        public IEnumerable<Minerals> GetAll()
        {
            return (IEnumerable<Minerals>)ch.GetRequest<Minerals>("Mineral");
        }

        public IEnumerable<Minerals> GetAllMinerals(Minerals model = null)
        {
            if (model == null)
                return (IEnumerable<Minerals>)ch.GetRequest<Minerals>("Mineral");
            else
                return (IEnumerable<Minerals>)ch.GetDetailsRequest<Minerals>("Mineral/search", model);
        }

        private List<Minerals> GetComboData()
        {
            return (List<Minerals>)ch.GetRequest<Minerals>("Mineral/combo");
        }

        public List<SelectListItem> GetCombo(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetComboData())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.MineralId.ToString(), Text = x.MineralName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.MineralId.ToString(), Text = x.MineralName };
                newList.Add(selListItem);
            }
            return newList;
        }

        public Minerals GetByGuId(Guid guid)
        {
            return (Minerals)ch.GetDetailsRequest<Minerals>("Mineral/GetByGuId?guid=" + guid);
        }

        public ResponseBody Add(Minerals model = null)
        {
            if (model != null)
            {
                if (!model.MineralId.HasValue || model.MineralId == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    var res = ch.PostRequest<Minerals>("Mineral/Create", model);
                    return res;

                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<Minerals>("Mineral/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(Guid? guid)
        {
            Minerals model = new Minerals();
            model.MineralId = guid;
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;

            return ch.PostRequest<Minerals>("Mineral/Delete", model);
        }
    }
}
