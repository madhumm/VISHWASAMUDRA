﻿using System.Collections.Generic;
using io = VSManagement.IOModels;

namespace ViswaSamudraUI.Providers.HRMS
{
	public class ZonesProvider
	{
        CommonHelper ch = new CommonHelper();
        public IEnumerable<io.Zones> GetAll(io.Zones model)
        {
            if (model == null)
            {
                return (IEnumerable<io.Zones>)ch.GetRequest<io.Zones>("Zones");
            }
            else
            {
                return (IEnumerable<io.Zones>)ch.GetDetailsRequest<io.Zones>("Zones/search", model);
            }
        }
    }
}
