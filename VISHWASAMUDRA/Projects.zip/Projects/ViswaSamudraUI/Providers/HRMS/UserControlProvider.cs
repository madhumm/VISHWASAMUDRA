﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswaSamudraUI.Models;
using io = VSManagement.IOModels;
namespace ViswaSamudraUI.Providers.HRMS
{
    public class UserControlProvider : Provider
    {
        string _userName = string.Empty;
        public UserControlProvider(string userName)
        {
            ch = new CommonHelper();
            _userName = userName;
        }
        public IEnumerable<io.UserControl> GetAllUserControl(io.UserControl model)
        {
                return (IEnumerable<io.UserControl>)ch.GetDetailsRequest<io.UserControl>("UserControl/search", model);
        }
        public IEnumerable<io.UserControl> GetsearchUserControl(io.UserControl model = null)
        {
            if (model == null) {
                return (IEnumerable<io.UserControl>)ch.GetRequest<io.UserControl>("UserControl");
            }
            else
            {
                return (IEnumerable<io.UserControl>)ch.GetDetailsRequest<io.UserControl>("UserControl/SearchResult", model);
            }

            

        }
        public ResponseBody Add(io.UserControl model = null)
        {
            if (model != null)
            {
                if (model.Guid == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDate = DateTime.Now;
                    var res = ch.PostRequest<io.UserControl>("UserControl/Create", model);
                    return res;

                }
                else
                {
                    model.ModifiedBy = _userName;
                    model.ModifiedDate = DateTime.Now;
                    return ch.PostRequest<io.UserControl>("UserControl/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(io.UserControl model = null)
        {
            model.ModifiedBy = _userName;
            model.ModifiedDate = DateTime.Now;
            return ch.DeleteRequest<io.UserControl>("UserControl/Delete", model);
        }

    }
}
