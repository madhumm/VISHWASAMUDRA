﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswaSamudraUI.Models;
using io = VSManagement.IOModels;
using ViswasamudraCommonObjects.Project;

namespace ViswaSamudraUI.Providers.HRMS
{
    public class UserRolesProvider
    {
        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;
        public UserRolesProvider(string userName)
        {
            _userName = userName;
        }
        public IEnumerable<io.UserRole> GetAll()
        {
            return (IEnumerable<io.UserRole>)ch.GetRequest<io.UserRole>("UserRole");
        }
        public IEnumerable<io.UserRole> GetAllUserRole(io.UserRole model = null)
        {
            if (model == null)
                return (IEnumerable<io.UserRole>)ch.GetRequest<io.UserRole>("UserRole");
            else
                return (IEnumerable<io.UserRole>)ch.GetDetailsRequest<io.UserRole>("UserRole/search", model);
        }
        public ResponseBody Add(io.UserRole model = null)
        {
            if (model != null)
            {
                if (model.Guid == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    var res = ch.PostRequest<io.UserRole>("UserRole/Create", model);
                    return res;

                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<io.UserRole>("UserRole/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(io.UserRole model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<io.UserRole>("UserRole/Delete", model);
        }

        public IEnumerable<io.UserRole> GetDropDown()
        {
            return (IEnumerable<io.UserRole>)ch.GetRequest<io.UserRole>("UserRole/combo");
        }

        public IEnumerable<Project> GetProjectDropDown()
        {
            return (IEnumerable<Project>)ch.GetRequest<Project>("Project/combo");
        }
        public IEnumerable<io.UserRole> GetProjectTypeDropDown()
        {
            return (IEnumerable<io.UserRole>)ch.GetRequest<io.UserRole>("UserRole/combo");
        }

        public IEnumerable<io.Department> GetDepartment()
        {
            return (IEnumerable<io.Department>)ch.GetRequest<io.Department>("Department/combo");
        }

        public List<SelectListItem> GetSelectList(string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetDropDown().Select(i => new { i.Name, i.Code, i.Guid }))
            {
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name };

                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetProjecSelectList(string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetProjectDropDown().Select(i => new { i.ProjectName, i.ProjectCode, i.Guid }))
            {
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.ProjectName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.ProjectName };

                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetDepartmentSelectList(string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetDepartment().Select(i => new { i.Name, i.Code, i.UniqueId }))
            {
                if (SelectedValue != null && x.UniqueId.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.UniqueId.ToString(), Text = x.Name, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.UniqueId.ToString(), Text = x.Name };

                newList.Add(selListItem);
            }
            return newList;
        }

    }
}
