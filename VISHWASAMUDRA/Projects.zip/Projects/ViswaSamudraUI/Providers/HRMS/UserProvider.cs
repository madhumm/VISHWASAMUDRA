﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using Settings.IOModels;
using System;
using System.Collections.Generic;
using ViswaSamudraUI.Models;
using io = VSManagement.IOModels;

namespace ViswaSamudraUI.Providers.HRMS
{
    public class UserProvider : Provider
    {
        string _userName = string.Empty;
        public UserProvider(string token,string User)
        {
            _token = token;
            ch = new CommonHelper(_token);
            _userName = User;

        }
        public io.UserLogin Login(io.UserLogin model)
        {
            ResponseBody res = ch.PostRequest<io.UserLogin>("User/Login", model);
            io.UserLogin responseBody = JsonConvert.
                DeserializeObject<io.UserLogin>(res.Message);
            return responseBody;
        }

        public void LogOut()
        {
            ch.GetRequest<string>("User/Logout");
        }


        public IEnumerable<io.UserLogin> GetAllUser(io.UserLogin model = null)
        {
            if (model == null)
                return (IEnumerable<io.UserLogin>)ch.GetRequest<io.UserLogin>("User");
            else
                return (IEnumerable<io.UserLogin>)ch.GetDetailsRequest<io.UserLogin>("User/search", model);
        }

        public IEnumerable<io.UserLogin> GetSearchUser(io.UserLogin model = null)
        {
            if (model == null)
                return (IEnumerable<io.UserLogin>)ch.GetRequest<io.UserLogin>("User");
            else
                return (IEnumerable<io.UserLogin>)ch.GetDetailsRequest<io.UserLogin>("User/Usersearch", model);
        }

        public ResponseBody Add(io.UserLogin model = null)
        {
            if (model != null)
            {
                if (string.IsNullOrEmpty(model.Guid.ToString()))
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime= DateTime.Now;
                    return ch.PostRequest<io.UserLogin>("User/Create", model);
                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<io.UserLogin>("User/Update", model);
                }
            }
            else
                return null;
        }

        public io.UserLogin ResetPassword(io.UserLogin model = null)
        {
            if (model != null)
            {
                ResponseBody res= ch.PostRequest<io.UserLogin>("User/ResetPassword", model);
                io.UserLogin responseBody = JsonConvert.
               DeserializeObject<io.UserLogin>(res.Message);
                return responseBody;
            }
            else
                return null;
        }

        public ResponseBody Delete(io.UserLogin model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<io.UserLogin>("User/Delete", model);
        }

        private List<io.Department> GetComboDepartmentData()
        {

            return (List<io.Department>)ch.GetRequest<io.Department> ("User/comboDepartment");

        }

        private List<io.Employee> getDropDownEmployeesbyDepartment(string Department)
        {

            return (List<io.Employee>)ch.GetRequest <io.Employee>("User/combobyEmployee/" + Department);

        }

        private List<io.UserRole> GetComboRolesData()
        {

            return (List<io.UserRole>)ch.GetRequest<io.UserRole>("UserRole/combo");

        }

        public List<SelectListItem> GetDepartmentData(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetComboDepartmentData())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.UniqueId.ToString(), Text = x.Name, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.UniqueId.ToString(), Text = x.Name };
                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetEmployeeData(string Department, string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);
            if(!string.IsNullOrWhiteSpace(Department)&& !string.IsNullOrEmpty(Department))
            foreach (var x in getDropDownEmployeesbyDepartment(Department))
            {
                if (SelectedValue != null && x.FirstName.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.FirstName, Selected = true };
                else
                selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.FirstName};
                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetComboRoles(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetComboRolesData())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name };
                newList.Add(selListItem);
            }
            return newList;
        }


    }
}