﻿using System;
using System.Collections.Generic;
using io = VSManagement.IOModels;

namespace ViswaSamudraUI.Providers.HRMS
{
    public class EmployeeProvider
    {
        CommonHelper ch = new CommonHelper();
        public io.Employee GetEmployeeDetails(string username)
        {
            return (io.Employee)ch.GetDetailsRequest<io.Employee>(string.Concat("Employee/", username));
        }

        public IEnumerable<io.Employee> GetAll(io.Employee model = null)
        {
            if (model == null)
                return (IEnumerable<io.Employee>)ch.GetRequest<io.Employee>("Employee");
            else
                return (IEnumerable<io.Employee>)ch.GetDetailsRequest<io.Employee>("Employee/search", model);
        }

        public IEnumerable<io.Employee> GetBehiveData()
        {
                return (IEnumerable<io.Employee>)ch.GetRequest<io.Employee>("Behive/getEmployee");
        }
    }
}
