﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Settings.IOModels;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswaSamudraUI.Models;
using io = VSManagement.IOModels;
namespace ViswaSamudraUI.Providers.HRMS
{
    public class UserMenuProvider : Provider
    {
        string _userName = string.Empty;
        CommonHelper  ch = new CommonHelper();
        public UserMenuProvider()
        {
           
        }
        public UserMenuProvider(string userName)
        {
            ch = new CommonHelper();
            _userName = userName;
        }
        public IEnumerable<io.UserMenu> GetAll()
        {
            return (IEnumerable<io.UserMenu>)ch.GetRequest<io.UserMenu>("UserMenu");
        }
        public IEnumerable<io.UserMenu> GetAllUserMenu(io.UserMenu model = null)
        {
            if (model == null)
                return (IEnumerable<io.UserMenu>)ch.GetRequest<io.UserMenu>("UserMenu");
            else
                return (IEnumerable<io.UserMenu>)ch.GetDetailsRequest<io.UserMenu>("UserMenu/search", model);
        }

        public IEnumerable<io.UserMenu> GetSearchUserMenu(io.UserMenu model = null)
        {
            if (model == null)
                return (IEnumerable<io.UserMenu>)ch.GetRequest<io.UserMenu>("UserMenu");
            else
                return (IEnumerable<io.UserMenu>)ch.GetDetailsRequest<io.UserMenu>("UserMenu/searchUsermenu", model);
        }
        public ResponseBody Add(io.UserMenu model = null)
        {
            if (model != null)
            {
                if (model.Guid == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDate = DateTime.Now;
                    var res = ch.PostRequest<io.UserMenu>("UserMenu/Create", model);
                    return res;

                }
                else
                {
                    model.ModifiedBy = _userName;
                    model.ModifiedDate = DateTime.Now;
                    return ch.PostRequest<io.UserMenu>("UserMenu/Update", model);
                }

            }
            else
                return null;
        }

        public List<UserMenuControl> GetUserMenuControls(string UserId)
        {
            return (List<UserMenuControl>)ch.GetRequest<UserMenuControl>("User/UsersMenu/" + UserId);
        }

        public ResponseBody Delete(io.UserMenu model = null)
        {
            model.ModifiedBy = _userName;
            model.ModifiedDate = DateTime.Now;
            return ch.DeleteRequest<io.UserMenu>("UserMenu/Delete", model);
        }

        public IEnumerable<io.UserMenu> GetDropDown()
        {
            IEnumerable<io.UserMenu> UserMenu = (IEnumerable<io.UserMenu>)ch.GetRequest<io.UserMenu>("UserMenu/DropDown");
            return UserMenu;
        }

        public IEnumerable<io.MenuApplication> GetAreaList()
        {
            return (IEnumerable<io.MenuApplication>)ch.GetRequest<io.MenuApplication>("UserMenu/AreaList");
        }

        public List<SelectListItem> GetAreaSelectList(string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetAreaList().Select(i => new { i.Guid, i.Name, }))
            {
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                {
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name, Selected = true };
                }
                else
                {
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name };
                }

                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetMenuSelectList(string SelectedValue = null, bool same = false, bool parentNull = true)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetDropDown().Select(i => new { i.Parent, i.ParentMenuName, i.Guid, i.MenuName, i.ApplicationName }))
            {
                if (!parentNull && string.IsNullOrEmpty(x.ParentMenuName)) continue;
                if (!string.IsNullOrEmpty(SelectedValue) && !same && SelectedValue == x.Guid.ToString()) continue;
                string parentMenu = String.Empty;
                parentMenu = x.ParentMenuName == null ? String.Empty : x.ParentMenuName+"->";
                string menuName = $"{x.ApplicationName}->{parentMenu}{x.MenuName}";
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue) {
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = menuName, Selected = true };
                }
                else {
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = menuName };
                }

                newList.Add(selListItem);
            }
            return newList;
        }

    }
}
