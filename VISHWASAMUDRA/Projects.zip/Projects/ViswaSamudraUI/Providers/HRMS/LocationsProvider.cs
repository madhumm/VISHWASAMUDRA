﻿using System.Collections.Generic;
using io = VSManagement.IOModels;

namespace ViswaSamudraUI.Providers.HRMS
{
	public class LocationsProvider
	{
        CommonHelper ch = new CommonHelper();
        public IEnumerable<io.Locations> GetAll(io.Locations model)
        {
            if (model == null)
            {
                return (IEnumerable<io.Locations>)ch.GetRequest<io.Locations>("Locations");
            }
            else
            {
                return (IEnumerable<io.Locations>)ch.GetDetailsRequest<io.Locations>("Locations/search", model);
            }
        }
    }
}
