﻿using System.Collections.Generic;
using io = VSManagement.IOModels;

namespace ViswaSamudraUI.Providers.HRMS
{
	public class DepartmentProvider
	{
        CommonHelper ch = new CommonHelper();
        public IEnumerable<io.Department> GetAll(io.Department model = null)
        {
            if (model == null)
            {
                return (IEnumerable<io.Department>)ch.GetRequest<io.Department>("Department");
            }
            else
            {
                return (IEnumerable<io.Department>)ch.GetDetailsRequest<io.Department>("Department/search", model);
            }
        }
    }
}
