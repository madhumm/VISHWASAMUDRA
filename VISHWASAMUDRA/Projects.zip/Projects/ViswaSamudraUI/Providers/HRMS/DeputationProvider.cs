﻿using System.Collections.Generic;
using io = VSManagement.IOModels;

namespace ViswaSamudraUI.Providers.HRMS
{
	public class DeputationProvider
	{
        CommonHelper ch = new CommonHelper();
        public IEnumerable<io.Deputation> GetAll(io.Deputation model=null)
        {
            if (model == null)
            {
                return (IEnumerable<io.Deputation>)ch.GetRequest<io.Deputation>("Deputation");
            }
            else
            {
                return (IEnumerable<io.Deputation>)ch.GetDetailsRequest<io.Deputation>("Deputation/search", model);
            }
        }
    }
}
