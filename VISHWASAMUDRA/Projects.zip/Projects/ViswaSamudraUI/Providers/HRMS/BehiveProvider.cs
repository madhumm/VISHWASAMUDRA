﻿using System;
using System.Collections.Generic;
using ViswaSamudraUI.Models;
using io = VSManagement.IOModels;

namespace ViswaSamudraUI.Providers.HRMS
{
    public class BehiveProvider
    {
        CommonHelper ch = new CommonHelper();
        public IEnumerable<io.Employee> GetBehiveData(string date)
        {
                return (IEnumerable<io.Employee>)ch.GetRequest<io.Employee>("Behive/getEmployee?date="+date);
        }
        
        public ResponseBody migrate(List<io.Employee> model = null)
        {
            if (model != null)
            {
                return ch.PostRequest<List<io.Employee>>("Employee/import", model);
            }
            else
                return null;
        }
    }
}
