﻿using System.Collections.Generic;
using io = VSManagement.IOModels;

namespace ViswaSamudraUI.Providers.HRMS
{
	public class DivisionProvider
	{
        CommonHelper ch = new CommonHelper();
        public IEnumerable<io.Division> GetAll(io.Division model=null)
        {
            if (model == null)
            {
                return (IEnumerable<io.Division>)ch.GetRequest<io.Division>("Division");
            }
            else
            {
                return (IEnumerable<io.Division>)ch.GetDetailsRequest<io.Division>("Division/search", model);
            }
        }

    }
}
