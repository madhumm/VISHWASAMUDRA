﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System.Collections.Generic;
using io = VSManagement.IOModels;

namespace ViswaSamudraUI.Providers
{
    public class Provider
    {
        public string _token;
        public CommonHelper ch = new CommonHelper();
        private List<io.UserRole> GetComboRolesData()
        {

            return (List<io.UserRole>)ch.GetRequest<io.UserRole>("UserRole/combo");

        }

        public List<SelectListItem> GetComboRoles(string SelectedValue)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetComboRolesData())
            {
                if (SelectedValue != null && x.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name };
                newList.Add(selListItem);
            }
            return newList;
        }
    }
}
