﻿namespace ViswaSamudraUI.Providers.Assets
{
    public class TableHelper
    {
        public string CreateChildLink(string Name, bool bo = false)
        {
            string view = bo == false ? "feather icon-chevrons-right" : "feather icon-eye";
            if (bo != true)
            {
                return
                    "<td>" +
                    "<a class='" + view + "' data-toggle='collapse' href='#" + Name.Replace(" ", "") + "' role='button' aria-expanded='false' aria-controls='collapseExample'></a>" +
                    "</td>";
            }
            else
            {
                return "<td>" +
                "<a class='" + view + "' id='#" + Name.Replace(" ", "") + "' role='button' aria-expanded='false' aria-controls='collapseExample'></a>" +
                "</td>";
            }
        }
        public string innertablehead(string Name, int i)
        {
            return
           "<tr class='collapse' id='" + Name.Replace(" ", "") + "'>" +
           "<td colspan='12' style='padding:inherit;margin:0'> " +
           "<div class='card-body' style='padding:inherit;margin:0;padding-left:15px'> " +
           "<div class='dataTables_scrollBody' style='position:relative;overflow:auto;max-height:75vh;width:100%;'>" +
           "<table class='tabletable-stripedtable-borderedtable-hovernowrap' style='border:1.2px solid " + Getcolor(i) + ";width:100%;'>";
        }

        public string innertprotablehead(string Name, int i)
        {
            return
           "<tr class='collapse' id='" + Name.Replace(" ", "") + "'>" +
           "<td colspan='12' style='padding:inherit;margin:0'> " +
           "<div class='card-body' style='padding:inherit;margin:0;padding-left:15px'> " +
           "<div class='dataTables_scrollBody' style='position:relative;overflow:auto;max-height:75vh;width:100%;'>" +
           "<table class='tabletable-stripedtable-borderedtable-hovernowrap' style='border:1.2px solid " + Getcolor(i) + ";width:100%;'>";
        }

        public string TableStart() => $"<table id='summaryTable' class='table table-striped table-bordered nowrap'>";

        public string TableHeader(string Name, string Code = null)
        {
            if (Code != null)
            {
                return
                    "<thead>" +
                    "<tr>" +
                    "<th></th>" +
                    "<th>Sno</th>" +
                    "<th>" + Code + "</th>" +
                    "<th>" + Name + "</th>" +
                    "<th>Total</th>" +
                    "<th>Available</th>" +
                    "<th>UnderUse</th>" +
                    "<th>Transfer To Qty</th>" +
                    "<th> Transfer From Qty</th>" +
                     "<th>Under Repair Qty</th>" +
                     "<th>Scrapped Qty</th>" +
                    "</tr>" +
                    "</thead>";
            }
            else
            {
                return
                    "<thead>" +
                    "<tr>" +
                    "<th></th>" +
                    "<th>Sno</th>" +
                    "<th>" + Name + "</th>" +
                    "<th>Total</th>" +
                    "<th>Available</th>" +
                    "<th>UnderUse</th>" +
                   "<th>Transfer To Qty</th>" +
                   "<th>Transfer From Qty</th>" +
                   "<th>Under Repair Qty</th>" +
                    "<th>Scrapped Qty</th>" +
                    "</tr>" +
                    "</thead>";
            }
        }

        public string Getcolor(int i)
        {
            if (i == 1)
            {
                return "#0806ed";
            }
            else if (i == 2)
            {
                return "#f30505";
            }
            else if (i == 3)
            {
                return "#25d505";
            }
            else if (i == 4)
            {
                return "#f1e11c";
            }
            else
            {
                return "#CCCCCB";
            }

        }
    }
}
