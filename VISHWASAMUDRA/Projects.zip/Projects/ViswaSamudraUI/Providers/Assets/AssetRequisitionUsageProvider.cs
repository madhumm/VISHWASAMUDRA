﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Asset;
using ViswaSamudraUI.Models;

namespace ViswaSamudraUI.Providers.Assets
{
    public class AssetRequisitionUsageProvider
    {
        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor = null;
        public AssetRequisitionUsageProvider(string userName, IHttpContextAccessor httpContextAccessor = null)
        {
            _userName = userName;
            _httpContextAccessor = httpContextAccessor;
            ch = new CommonHelper(_httpContextAccessor);
        }
        public IEnumerable<AssetRequisitionUsageHeader> GetAll(AssetRequisitionUsageHeader assetmodel)
        {
            return (IEnumerable<AssetRequisitionUsageHeader>)ch.GetDetailsRequest<AssetRequisitionUsageHeader>("AssetRequestionUsage/AssetRequestionUsagesearch", assetmodel);
        }
        public ResponseBody Add(AssetRequisitionUsageHeader model = null)
        {
            if (model != null)
            {
                model.CreatedBy = _userName;
                model.CreatedDateTime = DateTime.Now;
                return ch.PostRequest<AssetRequisitionUsageHeader>("AssetRequestionUsage/Create", model);
            }
            else
                return null;
        }

        public IEnumerable<AssetRequisitionIssueHeader> GetAllIssueNos()
        {
            return (IEnumerable<AssetRequisitionIssueHeader>)ch.GetRequest<AssetRequisitionIssueHeader>("AssetRequestionUsage/AssetRequisitionIssueHeaderDropdown");
        }
        public IEnumerable<AssetRequisitionIssueDetails> GetIssussbyIssueno(AssetRequisitionIssueDetails assetmodel)
        {
            return (IEnumerable<AssetRequisitionIssueDetails>)ch.GetDetailsRequest<AssetRequisitionIssueDetails>("AssetRequestionUsage/AssetiissuesbyIssueNo", assetmodel);
        }

        public IEnumerable<AssetRequisitionIssueHeader> GetIssueHeaderDetails(AssetRequisitionIssueHeader assetmodel)
        {
            return (IEnumerable<AssetRequisitionIssueHeader>)ch.GetDetailsRequest<AssetRequisitionIssueHeader>("AssetRequestionUsage/AssetiissueHeaderDetailsByIssueNo", assetmodel);
        }

        


        public List<SelectListItem> GetSelectList( string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);
            foreach (var x in GetAllIssueNos().Select(i => new { i.IssueNo, i.AssetIssueHeaderId }))
            {
                if (SelectedValue != null && x.AssetIssueHeaderId.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.AssetIssueHeaderId.ToString(), Text = x.IssueNo, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.AssetIssueHeaderId.ToString(), Text = x.IssueNo };

                newList.Add(selListItem);
            }
            return newList;
        }

        public ResponseBody Delete(AssetRequisitionUsageHeader model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<AssetRequisitionUsageHeader>("AssetRequestionUsage/Delete", model);
        }
    }
}
