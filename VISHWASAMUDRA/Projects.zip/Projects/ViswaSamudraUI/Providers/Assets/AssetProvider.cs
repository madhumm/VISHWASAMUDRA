﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using ViswaSamudraUI.Models;
using io = VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Providers.Assets
{
	public class AssetProvider
	{
        string _userName = string.Empty;
        CommonHelper ch = new CommonHelper();
        private readonly IHttpContextAccessor _httpContextAccessor;
        string _token = string.Empty;
        public AssetProvider(string userName, IHttpContextAccessor httpContextAccessor = null)
        {
            _userName = userName;
            _httpContextAccessor = httpContextAccessor;
            ch = new CommonHelper(_httpContextAccessor);
        }

        public IEnumerable<io.Asset> GetAll(io.Asset assetmodel)
        {
            return (IEnumerable<io.Asset>)ch.GetDetailsRequest<io.Asset>("asset/search", assetmodel);
        }
        public ResponseBody Add(io.Asset model = null)
        {
            if (model != null)
            {
                model.LastUpdatedBy = _userName;                
                return ch.PostRequest<io.Asset>("asset/assetUpdate", model);
            }
            else
                return null;
        }
    }
}
