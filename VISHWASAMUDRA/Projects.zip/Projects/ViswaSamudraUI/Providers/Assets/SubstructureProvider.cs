﻿using System.Collections.Generic;
using io = ViswasamudraCommonObjects.Asset;
using VSAssetManagement.IOModels;
using ViswaSamudraUI.Models;
using System;

namespace ViswaSamudraUI.Providers.Assets
{
    public class SubstructureProvider
    {

        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;
        public SubstructureProvider()
        {
        }
        public SubstructureProvider(string userName)
        {
            _userName = userName;
        }

        public IEnumerable<io.Substructure> GetAll()
        {
            return (IEnumerable<io.Substructure>)ch.GetRequest<io.Substructure>("SubStructure");
        }
        public IEnumerable<io.Substructure> GetAllStructures(io.Substructure model = null)
        {
            if (model == null)
                return (IEnumerable<io.Substructure>)ch.GetRequest<io.Substructure>("SubStructure");
            else
                return (IEnumerable<io.Substructure>)ch.GetDetailsRequest<io.Substructure>("SubStructure/SubStructuresearch", model);
        }

        public ResponseBody Add(io.Substructure model = null)
        {
            if (model != null)
            {
                if (model.Guid == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    var res = ch.PostRequest<io.Substructure>("SubStructure/Create", model);
                    return res;

                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<io.Substructure>("SubStructure/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(io.Substructure model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<io.Substructure>("SubStructure/Delete", model);
        }
    }
}
