﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Project;
using ViswaSamudraUI.Models;
using io = VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Providers.Assets
{
    public class ProjectProvider
    {
        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor = null;
        string[] projects = null;
        public ProjectProvider(IHttpContextAccessor httpContextAccessor = null)
        {
            _httpContextAccessor = httpContextAccessor;
            if (httpContextAccessor != null)
            {
                string prjs = _httpContextAccessor.HttpContext.Session.GetString("user-projects");
                if (!string.IsNullOrEmpty(prjs))
                {
                    projects = prjs.Split(',');
                }
            }
        }
        public ProjectProvider(string userName)
        {
            _userName = userName;
        }
        public IEnumerable<Project> GetAllProject(Project model = null)
        {
            if (model == null)
                return (IEnumerable<Project>)ch.GetRequest<Project>("Project");
            else
                return (IEnumerable<Project>)ch.GetDetailsRequest<Project>("Project/search", model);
        }
        public IEnumerable<Project> GetAll(Project model = null)
        {
            if (model == null)
                return (IEnumerable<Project>)ch.GetRequest<Project>("Project");
            else
            {
                return (IEnumerable<Project>)ch.GetDetailsRequest<Project>("Project/Searchbyproj", model);
            }
        }

        public ResponseBody Add(Project model = null)
        {
            if (model != null)
            {
                if (model.Guid == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    return ch.PostRequest<Project>("Project/Create", model);
                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<Project>("Project/Update", model);
                }
            }
            else
                return null;
        }

        public IEnumerable<Project> GetDropDown()
        {
            return (IEnumerable<Project>)ch.GetRequest<Project>("Project/combo");
        }

        public List<SelectListItem> GetSelectList(string SelectedValue = null, string fromValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);
            var dropDownList = GetDropDown();
            if (projects != null) {
                dropDownList = dropDownList.Where(r => projects.Contains(r.Guid.ToString()));
            }

            foreach (var x in dropDownList.Select(i => new { i.ProjectName, i.ProjectCode, i.Guid }))
            {
                if (fromValue != null && fromValue == x.Guid.ToString())
                    continue;
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.ProjectName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.ProjectName };

                newList.Add(selListItem);
            }
            return newList;
        }

        public IEnumerable<CompanyV> GetCompanyDropDown()
        {
            return (IEnumerable<CompanyV>)ch.GetRequest<CompanyV>("CompanyV/combo");
        }
        public List<SelectListItem> GetCompanySelectList(int id, string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetCompanyDropDown().Select(i => new { i.CompanyName, i.CompanyCode, i.Guid }))
            {
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.CompanyName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.CompanyName };

                newList.Add(selListItem);
            }
            return newList;
        }

        public IEnumerable<CompanyV> GetCompanyDropDown(string projguid)
        {
            return (IEnumerable<CompanyV>)ch.GetRequest<CompanyV>("Project/combo?guid=" +projguid);
        }

        public SelectListItem GetCompanyByProject(string projguid)
        {
            SelectListItem selListItem = new SelectListItem();
           
            foreach (var x in GetCompanyDropDown(projguid).Select(i => new { i.CompanyName,i.Guid }))
            {
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.CompanyName };

            }
            return selListItem;

        }

        public ResponseBody Delete(Project model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<Project>("Project/Delete", model);
        }
    }
}
