﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Asset;
using ViswaSamudraUI.Models;
using VSAssetManagement.IOModels;
using io = VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Providers.Assets
{
	public class ReportDetails
    {
        CommonHelper ch = new CommonHelper();        
        public IEnumerable<S_DetailedReport> GetSummaryReport()
        {
            return (IEnumerable<S_DetailedReport>)ch.GetRequest<S_DetailedReport>("reports/straightReport");
        }

        public IEnumerable<R_ProjectReport> GetProjectSummary()
        {
            return (IEnumerable<R_ProjectReport>)ch.GetRequest<R_ProjectReport>("reports/ProjectSummary");
        }
        public IEnumerable<R_StoreReport> GetStoreSummary()
        {
            return (IEnumerable<R_StoreReport>)ch.GetRequest<R_StoreReport>("reports/StoreSummary");
        }

        public IEnumerable<R_StructureReport> GetStructureSummary()
        {
            return (IEnumerable<R_StructureReport>)ch.GetRequest<R_StructureReport>("reports/StructureSummary");
        }
        public IEnumerable<R_SubStructureReport> GetSubStructureSummary()
        {
            return (IEnumerable<R_SubStructureReport>)ch.GetRequest<R_SubStructureReport>("reports/SubStructureSummary");
        }
        public IEnumerable<R_AssertTypeReport> GetAssetTypeSummary()
        {
            return (IEnumerable<R_AssertTypeReport>)ch.GetRequest<R_AssertTypeReport>("reports/AssetTypeSummary");
        }
        public IEnumerable<R_AssertSpecReport> GetAssetSpecSummary()
        {
            return (IEnumerable<R_AssertSpecReport>)ch.GetRequest<R_AssertSpecReport>("reports/AssetSpecSummary");
        }
        public IEnumerable<WingsDashboard> GetWingsDashboardSummary(Guid ?user=null)
        {
            return (IEnumerable<WingsDashboard>)ch.GetRequest<WingsDashboard>("reports/wingsDashboard");
        }

        public IEnumerable<R_ProjectReport> GetRevSummaryReport()
        {
            return (IEnumerable<R_ProjectReport>)ch.GetRequest<R_ProjectReport>("reports/reverseReport");
        }

        public IEnumerable<S_StoreReport> GetStoreSummaryReport(S_StoreReport PoIoModel)
        {
            return (IEnumerable<S_StoreReport>)ch.GetDetailsRequest<S_StoreReport>("reports/storeReport", PoIoModel);
        }

        public IEnumerable<R_AssertSpecReport> GetAssetSpecSummaryReport(R_AssertSpecReport PoIoModel)
        {
            return (IEnumerable<R_AssertSpecReport>)ch.GetDetailsRequest<R_AssertSpecReport>("reports/AssetSpecReport", PoIoModel);
        }

        public IEnumerable<string> GetStoreSummaryReport()
        {
            return (IEnumerable<string>)ch.GetRequest<string>("reports/dashboardReport");
        }

        public List<A_AassetHealthReport> GetAssetHealthReport(A_AassetHealthReport HealthModel)
        {
            return (List<A_AassetHealthReport>)ch.GetDetailsRequest<A_AassetHealthReport>("reports/AssetHealthReport", HealthModel);
        }

        public List<AssetUtilizationSummary> GetAssetUtilizationSummaryReport(AssetUtilizationSummary SummaryReport)
        {
            return (List<AssetUtilizationSummary>)ch.GetDetailsRequest<AssetUtilizationSummary>("reports/AssetUtilizationSummaryReport", SummaryReport);
        }

        public List<AssetRequisitionsReport> GetassetRequisitionsReport(AssetRequisitionsReport SummaryReport)
        {
            return (List<AssetRequisitionsReport>)ch.GetDetailsRequest<AssetRequisitionsReport>("reports/GetassetRequisitionsReport", SummaryReport);
        }

        public List<AssetUtilizationDetailReport> GetAssetUtilizationDetailReport(AssetUtilizationDetailReport SummaryReport)
        {
            return (List<AssetUtilizationDetailReport>)ch.GetDetailsRequest<AssetUtilizationDetailReport>("reports/AssetUtilizationDetailReport", SummaryReport);
        }

        public List<AssetRequestionDetailReport> GetassetRequisitionsDetailReport(AssetRequestionDetailReport SummaryReport)
        {
            return (List<AssetRequestionDetailReport>)ch.GetDetailsRequest<AssetRequestionDetailReport>("reports/GetassetRequisitionsDetailReport", SummaryReport);
        }

        //

        public List<PendingRequisitionsReport> GetPendingRequisitionsReport(PendingRequisitionsReport SummaryReport)
        {
            return (List<PendingRequisitionsReport>)ch.GetDetailsRequest<PendingRequisitionsReport>("reports/GetPendingRequisitionsReport", SummaryReport);
        }

        public List<PendingRequisitionDetailReport> GetPendingRequisitionDetailReport(PendingRequisitionDetailReport SummaryReport)
        {
            return (List<PendingRequisitionDetailReport>)ch.GetDetailsRequest<PendingRequisitionDetailReport>("reports/GetPendingRequisitionDetailReport", SummaryReport);
        }

        public List<ApprovedRequisitionsReport> GetApprovedRequisitionsReport(ApprovedRequisitionsReport SummaryReport)
        {
            return (List<ApprovedRequisitionsReport>)ch.GetDetailsRequest<ApprovedRequisitionsReport>("reports/GetApprovedRequisitionsReport", SummaryReport);
        }

        public List<ApprovedRequisitionDetailReport> GetApprovedRequisitionDetailReport(ApprovedRequisitionDetailReport SummaryReport)
        {
            return (List<ApprovedRequisitionDetailReport>)ch.GetDetailsRequest<ApprovedRequisitionDetailReport>("reports/GetApprovedRequisitionDetailReport", SummaryReport);
        }

        public List<AssetTransferSummaryReport> GetAssetTransferSummeryReport(AssetTransferSummaryReport assetTransferSummaryReport)
        {
            return (List<AssetTransferSummaryReport>)ch.GetDetailsRequest<AssetTransferSummaryReport>("reports/GetAssetTransferSummeryReport", assetTransferSummaryReport);
        }
    }
}
