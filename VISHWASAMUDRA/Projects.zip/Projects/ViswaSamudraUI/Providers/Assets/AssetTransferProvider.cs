﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using ViswaSamudraUI.Models;
using io = VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Providers.Assets
{
    public class AssetTransferProvider
    {
        string _userName = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        CommonHelper ch = new CommonHelper();
        public AssetTransferProvider(string userName, IHttpContextAccessor httpContextAccessor = null)
        {
            _userName = userName;
            _httpContextAccessor = httpContextAccessor;
            ch = new CommonHelper(_httpContextAccessor);
        }
        
        public IEnumerable<io.AssetTransfer> GetAll(io.AssetTransfer assetreqmodel)
        {
            return (IEnumerable<io.AssetTransfer>)ch.GetDetailsRequest<io.AssetTransfer>("AssetTransfer/search", assetreqmodel);
        }
        public ResponseBody Add(io.AssetTransfer model = null)
        {
            if (model.header.Guid == System.Guid.Empty)
            {
                model.header.CreatedBy = _userName;
                model.header.CreatedDateTime = DateTime.UtcNow;
                return ch.PostRequest<io.AssetTransfer>("AssetTransfer/createAssetTransfer", model);
            }
            else
            {
                model.header.LastUpdatedBy = _userName;
                model.header.LastUpdatedDateTime = DateTime.UtcNow;
                return ch.PostRequest<io.AssetTransfer>("AssetTransfer/updateAssetTransfer", model);
            }
        }

        public ResponseBody Delete(io.AssetTransfer model)
        {
            return ch.PostRequest<io.AssetTransfer>("AssetTransfer/DeleteAssetTransfer", model);
        }

        public ResponseBody Approve(io.AssetTransfer model)
        {
            return ch.PostRequest<io.AssetTransfer>("assetTransfer/Approve", model);
        }
    }
}
