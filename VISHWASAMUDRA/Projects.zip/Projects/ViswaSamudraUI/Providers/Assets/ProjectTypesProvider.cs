﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswasamudraCommonObjects.Project;
using ViswaSamudraUI.Models;
using io = VSAssetManagement.IOModels;


namespace ViswaSamudraUI.Providers.Assets
{
    public class ProjectTypesProvider
    {
        string _userName = string.Empty;
        public ProjectTypesProvider(string userName)
        {
            _userName = userName;
        }
        CommonHelper ch = new CommonHelper();
        public IEnumerable<ProjectTypes> GetAll()
        {
            return (IEnumerable<ProjectTypes>)ch.GetRequest<ProjectTypes>("ProjectTypes");
        }

        public IEnumerable<ProjectTypes> GetAllProjectTypes(ProjectTypes model = null)
        {
            if (model == null)
                return (IEnumerable<ProjectTypes>)ch.GetRequest<ProjectTypes>("ProjectTypes"); 

			else
                return (IEnumerable<ProjectTypes>)ch.GetDetailsRequest<ProjectTypes>("ProjectTypes/search", model);
        }
        public IEnumerable<ProjectTypes> GetProjectTypes(ProjectTypes model = null)
        {
            if (model == null)
                return (IEnumerable<ProjectTypes>)ch.GetRequest<ProjectTypes>("ProjectTypes");
            else
                return (IEnumerable<ProjectTypes>)ch.GetDetailsRequest<ProjectTypes>("ProjectTypes/ProjectTypesSearch", model);
        }

        public ResponseBody Add(ProjectTypes model = null)
        {
            if (model != null)
            {
                if (model.Guid == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    var res = ch.PostRequest<ProjectTypes>("ProjectTypes/Create", model);
                    return res;

                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<ProjectTypes>("ProjectTypes/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Delete(ProjectTypes model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<ProjectTypes>("ProjectTypes/Delete", model);
        }

        public IEnumerable<ProjectTypes> GetDropDown(int id)
        {
            return (IEnumerable<ProjectTypes>)ch.GetRequest<ProjectTypes>("ProjectTypes/combo?id=" + id);
        }

        public List<SelectListItem> GetSelectList(int id, string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetDropDown(id).Select(i => new { i.ProjectTypeName, i.ProjectTypeCode, i.Guid }))
            {
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.ProjectTypeName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.ProjectTypeName };

                newList.Add(selListItem);
            }
            return newList;
        }
    }

}
