﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswaSamudraUI.Models;
using io = VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Providers.Assets
{
    public class AssetRequistionProvider
    {
        string _userName = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        CommonHelper ch = new CommonHelper();
        public AssetRequistionProvider(string userName, IHttpContextAccessor httpContextAccessor = null)
        {
            _userName = userName;
            _httpContextAccessor = httpContextAccessor;
            ch = new CommonHelper(_httpContextAccessor);
        }

        
        public IEnumerable<io.AssetRequisition> GetAll(io.AssetRequisition assetreqmodel)
        {
            return (IEnumerable<io.AssetRequisition>)ch.GetDetailsRequest<io.AssetRequisition>("assetRequisition/search", assetreqmodel);
        }
        public ResponseBody Add(io.AssetRequisition model = null)
        {
            if (model.header.Guid == System.Guid.Empty)
            {
                model.header.CreatedBy = _userName;
                model.header.CreatedDateTime = DateTime.Now;
                return ch.PostRequest<io.AssetRequisition>("assetRequisition/createAssetRequisition", model);
            }
            else
            {
                model.header.LastUpdatedBy = _userName;
                model.header.LastUpdatedDateTime = DateTime.Now;
                return ch.PostRequest<io.AssetRequisition>("assetRequisition/updateAssetRequisition", model);
            }
        }


        public ResponseBody Delete(io.AssetRequisition model)
        {
            model.header.LastUpdatedBy = _userName;
            model.header.LastUpdatedDateTime = DateTime.Now;
            return ch.PostRequest<io.AssetRequisition>("assetRequisition/DeleteAssetRequisition", model);
        }

        public ResponseBody Approve(io.AssetRequisition model)
        {
            return ch.PostRequest<io.AssetRequisition>("assetRequisition/Approve", model);
        }
        public IEnumerable<string> GetProjectwiseUserData(Guid? ProjectId)
        {
            if (ProjectId == null || ProjectId == new Guid())
            {
                return new List<string>();
            }
            else
            {
                // return (IEnumerable<string>)ch.GetRequest<string>("User/UsersList");
                return (List<string>)ch.GetRequest<string>("User/ProjectwiseUsers/" + ProjectId);
            }
        }

        public List<SelectListItem> GetUserData(Guid? ProjectId, String user = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetProjectwiseUserData(ProjectId).Select(i => i))
            {
                if (user != null && x == user)
                    selListItem = new SelectListItem() { Value = x, Text = x, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x, Text = x };

                newList.Add(selListItem);
            }
            return newList;
        }
    }
}
