﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Asset.SearchForms;
using ViswasamudraCommonObjects.Project;
using ViswaSamudraUI.Models;
using io = VSAssetManagement.IOModels;


namespace ViswaSamudraUI.Providers.Assets
{
    public class CompanyVProvider
	{
		CommonHelper ch = new CommonHelper();
		string _userName = string.Empty;
		public CompanyVProvider()
		{
		}
		public CompanyVProvider(string userName)
		{
			_userName = userName;
		}
		public IEnumerable<CompanyV> GetAll()
		{
			return (IEnumerable<CompanyV>)ch.GetRequest<CompanyV>("CompanyV");
		}

		public IEnumerable<CompanyV> GetAllCompanyV(CompanyV model = null)
		{
			if (model == null)
				return (IEnumerable<CompanyV>)ch.GetRequest<CompanyV>("CompanyV");

			else
				return (IEnumerable<CompanyV>)ch.GetDetailsRequest<CompanyV>("CompanyV/search", model);
		}
		public IEnumerable<CompanyV> GetCompanyV(CompanyV model = null)
		{
			if (model == null)
				return (IEnumerable<CompanyV>)ch.GetRequest<CompanyV>("CompanyV");
			else
				return (IEnumerable<CompanyV>)ch.GetDetailsRequest<CompanyV>("CompanyV/CompanyVSearch", model);
		}
		public IEnumerable<CompanyV> GetDropDown(int id)
		{
			return (IEnumerable<CompanyV>)ch.GetRequest<CompanyV>("CompanyV/combo?id=" + id);
		}
		public List<SelectListItem> GetSelectList(int id, string SelectedValue = null)
		{
			SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
			List<SelectListItem> newList = new List<SelectListItem>();
			newList.Add(selListItem);

			foreach (var x in GetDropDown(id).Select(i => new { i.CompanyName, i.CompanyCode, i.Guid }))
			{
				if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
					selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.CompanyName, Selected = true };
				else
					selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.CompanyName };

				newList.Add(selListItem);
			}
			return newList;
		}

		public ResponseBody Add(CompanyV model = null)
		{
			if (model != null)
			{
				if (model.Guid == Guid.Empty)
				{
					model.CreatedBy = _userName;
					model.CreatedDateTime = DateTime.Now;
					var res = ch.PostRequest<CompanyV>("CompanyV/Create", model);
					return res;

				}
				else
				{
					model.LastUpdatedBy = _userName;
					model.LastUpdatedDateTime = DateTime.Now;
					return ch.PostRequest<CompanyV>("CompanyV/Update", model);
				}
			}
			else
				return null;
		}

		public ResponseBody Delete(CompanyV model = null)
		{
			model.LastUpdatedBy = _userName;
			model.LastUpdatedDateTime = DateTime.Now;
			return ch.DeleteRequest<CompanyV>("CompanyV/Delete", model);
		}
	}

}
