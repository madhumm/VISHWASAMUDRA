﻿using System;
using System.Collections.Generic;
using ViswaSamudraUI.Models;
using io = VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Providers.Assets
{
    public class ReasonProvider
    {
        string _userName = string.Empty;
        public ReasonProvider(string userName)
        {
            _userName = userName;
        }

        CommonHelper ch = new CommonHelper();
        
        public IEnumerable<io.Reason> GetAllReason(io.Reason PoIoModel = null)
        {
            if (PoIoModel == null)
                return (IEnumerable<io.Reason>)ch.GetRequest<io.Reason>("reason");
            else
                return (IEnumerable<io.Reason>)ch.GetDetailsRequest<io.Reason>("reason/reasonsearch", PoIoModel);
        }
        public ResponseBody AddReason(io.Reason model = null)
        {
            if (model != null)
            {
                if (model.Guid == Guid.Empty || model.Guid == null)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    return ch.PostRequest<io.Reason>("reason/CreateResult", model);
                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<io.Reason>("reason/UpdateResult", model);
                }
            }
            else
                return null;
        }
        public ResponseBody Delete(io.Reason model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<io.Reason>("Reason/Delete", model);
        }
    }
}