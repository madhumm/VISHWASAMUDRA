﻿using Microsoft.AspNetCore.Mvc.Rendering;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswasamudraCommonObjects.Project;
using ViswaSamudraUI.Models;
using io = VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Providers.Assets
{
    public class ProjectCycleProvider
    {
        string _userName = string.Empty;
        public ProjectCycleProvider(string userName)
        {
            _userName = userName;
        }
        CommonHelper ch = new CommonHelper();

        public IEnumerable<ProjectCycle> GetAllProjectCycles(ProjectCycle model = null)
        {
            if (model == null)
                return (IEnumerable<ProjectCycle>)ch.GetRequest<ProjectCycle>("ProjectCycle");
            else
                return (IEnumerable<ProjectCycle>)ch.GetDetailsRequest<ProjectCycle>("ProjectCycle/search", model);
        }
        public IEnumerable<io.Store> GetAll(io.Store model = null)
        {
            if (model == null)
                return (IEnumerable<io.Store>)ch.GetRequest<io.Store>("Store");
            else
            {
                return (IEnumerable<io.Store>)ch.GetDetailsRequest<io.Store>("Store/searchwithfilters", model);
            }
        }

        public IEnumerable<io.Store> GetDropDown(int id)
        {
            return (IEnumerable<io.Store>)ch.GetRequest<io.Store>("Store/combo?id="+id);
        }
        public IEnumerable<io.Store> GetDropDownByProj(int id,Guid guid)
        {
            return (IEnumerable<io.Store>)ch.GetRequest<io.Store>("Store/combobyProject?id=" + id+ "&guid=" + guid);
        }

        public List<SelectListItem> GetSelectListPro(int id, Guid project,string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetDropDownByProj(id, project).Select(i => new { i.Name, i.Code, i.Guid }))
            {
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name };

                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetSelectList(int id, string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetDropDown(id).Select(i => new { i.Name, i.Code, i.Guid }))
            {
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name };

                newList.Add(selListItem);
            }
            return newList;
        }

        public ResponseBody Save(ProjectCycle model = null)
        {
            if (model != null)
            {
                return ch.PostRequest<ProjectCycle>("ProjectCycle/Save", model);
            }
            return null;
        }

        public ResponseBody Delete(io.Store model = null)
        {
            return ch.DeleteRequest<io.Store>("Store/Delete", model);
        }
    }
}
