﻿using System.Collections.Generic;
using io = ViswasamudraCommonObjects.Asset;
using VSAssetManagement.IOModels;
using ViswaSamudraUI.Models;
using System;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq;

namespace ViswaSamudraUI.Providers.Assets
{
    public class StructureProvider
    {
        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;
        public StructureProvider()
        {
        }
        public StructureProvider(string userName)
        {
            _userName = userName;
        }
        public IEnumerable<io.Structure> GetAll()
        {
            return (IEnumerable<io.Structure>)ch.GetRequest<io.Structure>("Structure");
        }
        public IEnumerable<io.Structure> GetAllStructures(io.Structure model = null)
        {
            if (model == null)
                return (IEnumerable<io.Structure>)ch.GetRequest<io.Structure>("Structure");
            else
                return (IEnumerable<io.Structure>)ch.GetDetailsRequest<io.Structure>("Structure/Structuresearch", model);
        }

        public ResponseBody Add(io.Structure model = null)
        {
            if (model != null)
            {
                if (model.Guid == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    var res = ch.PostRequest<io.Structure>("Structure/Create", model);
                    return res;

                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<io.Structure>("Structure/Update", model);
                }
            }
            else
                return null;
        }

        private List<io.Structure> GetComboStructure()
        {

            return (List<io.Structure>)ch.GetRequest<io.Structure>("Structure/combo");

        }

        public List<SelectListItem> GetSelectList( string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetComboStructure().Select(i => new { i.StructureName, i.Guid }))
            {
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.StructureName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.StructureName };

                newList.Add(selListItem);
            }
            return newList;
        }

        public ResponseBody Delete(io.Structure model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<io.Structure>("Structure/Delete", model);
        }
    }
}
