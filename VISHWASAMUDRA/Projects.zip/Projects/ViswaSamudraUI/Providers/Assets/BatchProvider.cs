﻿using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using ViswaSamudraUI.Models;
using io = VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Providers.Assets
{
	public class BatchProvider
    {
        CommonHelper ch = new CommonHelper();
        string _userName = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        public BatchProvider(string userName, IHttpContextAccessor httpContextAccessor = null)
        {
            _userName = userName;
            _httpContextAccessor = httpContextAccessor;
            ch = new CommonHelper(_httpContextAccessor);
        }
       
        public IEnumerable<io.BatchSearch> GetAll()
        {
            return (IEnumerable<io.BatchSearch>)ch.GetRequest<io.BatchSearch>("batch/all");
        }
        public IEnumerable<io.BatchSearch> GetBatchSearch(io.BatchSearch BatchModel= null)
        {
            if (BatchModel != null)
            {
                return (IEnumerable<io.BatchSearch>)ch.GetDetailsRequest<io.BatchSearch>("batch/Batchserach", BatchModel);
            }
            else
            {
                return (IEnumerable<io.BatchSearch>)ch.GetRequest<io.BatchSearch>("batch/all");
            }
        }
        public IEnumerable<io.BatchSearch> GetAllBatches(io.BatchSearch BatchModel)
        {
            return (IEnumerable<io.BatchSearch>)ch.GetDetailsRequest<io.BatchSearch>("batch/search", BatchModel);
        }

        public ResponseBody BatchModifications(io.Batch BatchModel = null)
        {
            if (BatchModel != null)
            {
                if (BatchModel.Guid == Guid.Empty)
                {
                    BatchModel.CreatedBy = _userName;
                    BatchModel.ReceivedBy = BatchModel.ReceivedBy;
                    return ch.PostRequest<io.Batch>("batch/Create", BatchModel);
                }
                BatchModel.LastUpdatedBy = _userName;
                BatchModel.ReceivedBy = BatchModel.ReceivedBy;
                return ch.PostRequest<io.Batch>("batch/Update", BatchModel);
            }
            else
                return null;
        }
    }
}
