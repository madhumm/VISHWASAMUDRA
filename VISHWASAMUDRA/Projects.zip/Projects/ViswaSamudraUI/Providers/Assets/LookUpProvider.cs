﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswaSamudraUI.Models;
using VSAssetManagement.IOModels;
using VSManagement.IOModels.DropDown;
using io = VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Providers.Assets
{
    public class LookUpProvider
    {
        string _userName = string.Empty;
        public LookUpProvider()
        {
        }
        public LookUpProvider(string userName)
        {
            _userName = userName;
        }
        CommonHelper ch = new CommonHelper();

        public IEnumerable<io.LookupTypeValue> GetAllLookup(string lookUpType)
        {

            return (IEnumerable<io.LookupTypeValue>)ch.GetRequest<io.LookupTypeValue>("lookup/" + lookUpType);

        }

        public IEnumerable<io.LookupType> GetLookupData(LookupType lookupType)
        {

            return (IEnumerable<io.LookupType>)ch.GetDetailsRequest<io.LookupType>("lookup/search", lookupType);
        }


        public IEnumerable<io.LookupTypeValue> GetLookupValue(LookupTypeValue lookupTypevalue)
        {

            return (IEnumerable<io.LookupTypeValue>)ch.GetDetailsRequest<io.LookupTypeValue>("lookup/value/search", lookupTypevalue);
        }

        public List<SelectListItem> GetSelectList(string code, string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);
            foreach (var x in GetAllLookup(code).Select(i => new { i.Name, i.Code, i.Guid }))
            {
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name };

                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetSelectListTag(string code, string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);
            // string[] allowSatus = { "TGDMG", "TGURE" };
            foreach (var x in GetAllLookup(code).Select(i => new { i.Name, i.Code, i.Guid }))
            {
                //if (allowSatus.Contains(x.Code))
                //{
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name };

                newList.Add(selListItem);
                //}
            }
            return newList;
        }

        public List<SelectListItem> GetLookUpMasterList()
        {
            LookupType ty = new LookupType();
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetLookupData(ty).Select(i => new { i.Name, i.Code, i.Guid }))
            {
                selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.Name };

                newList.Add(selListItem);
            }
            return newList;
        }

        //LoadGrid

        public ResponseBody Add(io.LookupType model = null)
        {
            if (model != null)
            {
                if (model.Guid == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    return ch.PostRequest<io.LookupType>("LookUp/Create", model);
                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<io.LookupType>("LookUp/Update", model);
                }
            }
            else
                return null;
        }

        public ResponseBody Add(io.LookupTypeValue model = null)
        {
            if (model != null)
            {

                if (model.Guid == Guid.Empty)
                {
                    model.CreatedBy = _userName;
                    model.CreatedDateTime = DateTime.Now;
                    return ch.PostRequest<io.LookupTypeValue>("LookUp/Value/Create", model);
                }
                else
                {
                    model.LastUpdatedBy = _userName;
                    model.LastUpdatedDateTime = DateTime.Now;
                    return ch.PostRequest<io.LookupTypeValue>("LookUp/Value/Update", model);
                }
            }
            else
                return null;
        }

        public List<SelectListItem> GetUsageUomList()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem() { Value = "", Text = "" });
            list.Add(new SelectListItem() { Value = "Times", Text = "Times" });
            list.Add(new SelectListItem() { Value = "Days", Text = "Days" });
            list.Add(new SelectListItem() { Value = "Years", Text = "Years" });
            return list;
        }

        public List<SelectListItem> GetPaymentModes()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem() { Value = "", Text = "" });
            list.Add(new SelectListItem { Value = "Credit Card", Text = "Credit Card" });
            list.Add(new SelectListItem { Value = "Debit Card", Text = "Debit Card" });
            list.Add(new SelectListItem { Value = "Online", Text = "Online" });
            list.Add(new SelectListItem { Value = "UPI", Text = "UPI" });
            list.Add(new SelectListItem { Value = "Cash", Text = "Cash" });
            return list;
        }

        public List<SelectListItem> GetTempUserData(String user=null)
        {
            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem() { Value = "", Text = "" });
            list.Add(new SelectListItem() { Value = "User1", Text = "User1", Selected=user== "User1" ? true:false });
            list.Add(new SelectListItem() { Value = "Admin", Text = "Admin", Selected = user == "Admin" ? true : false });
            list.Add(new SelectListItem() { Value = "User2", Text = "User2", Selected = user == "User2" ? true : false });
            return list;
        }

        public List<SelectListItem> GetRequisitionStatusData()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem() { Value = "R", Text = "Requested" });
            list.Add(new SelectListItem() { Value = "A", Text = "Open" });
            list.Add(new SelectListItem() { Value = "O", Text = "Accepted" });
            list.Add(new SelectListItem() { Value = "C", Text = "Closed" });
            return list;
        }

        public ResponseBody Delete(io.LookupType model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<io.LookupType>("LookUp/Delete", model);
        }

        public ResponseBody DeleteValue(io.LookupTypeValue model = null)
        {
            model.LastUpdatedBy = _userName;
            model.LastUpdatedDateTime = DateTime.Now;
            return ch.DeleteRequest<io.LookupTypeValue>("LookUp/Value/Delete", model);
        }

        public IEnumerable<string> GetActiveUserNames()
        {
            return (IEnumerable<string>)ch.GetRequest<string>("User/UsersList");
        }

        public IEnumerable<User> GetActiveUserDropDown()
        {
            return (IEnumerable<User>)ch.GetRequest<User>("User/DropDown");
        }

        public IEnumerable<User> GetActiveUserDropDownByProject(Guid? ProjectId)
        {
            if (ProjectId == null || ProjectId == new Guid())
            {
                return new List<User>();
            }
            else
            {
                return (IEnumerable<User>)ch.GetRequest<User>("User/ProjectwiseDropdownUsers/" + ProjectId);
            }
        }

        public List<SelectListItem> GetUserData(String user = null)
        {
            LookupType ty = new LookupType();
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetActiveUserNames().Select(i => i))
            {
                if (user != null && x == user)
                    selListItem = new SelectListItem() { Value = x, Text = x, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x, Text = x };

                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetUserDropDown(string user = null)
        {
            LookupType ty = new LookupType();
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetActiveUserDropDown().Select(i => new { i.UserName, i.Guid }))
            {
                if (user != null && x.Guid.ToString() == user)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.UserName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.UserName };

                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetActiveUserDropDownbyProject(Guid? projectId, string user = null)
        {
            LookupType ty = new LookupType();
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetActiveUserDropDownByProject(projectId).Select(i => new { i.UserName, i.Guid }))
            {
                if (user != null && x.Guid.ToString() == user)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.UserName, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.UserName };

                newList.Add(selListItem);
            }
            return newList;
        }

        public ResponseBody Save(io.LookupTypeValue model= null)
        {
            if (model != null)
            {
                return ch.PostRequest<io.LookupTypeValue>("LookUp/Value/Save", model);
            }
            return null;
        }
    }

}
