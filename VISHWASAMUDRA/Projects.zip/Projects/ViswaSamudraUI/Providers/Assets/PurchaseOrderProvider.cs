﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using System;
using System.Collections.Generic;
using System.Linq;
using ViswaSamudraUI.Models;
using io = VSAssetManagement.IOModels;

namespace ViswaSamudraUI.Providers.Assets
{
    public class PurchaseOrderProvider
    {
        string _userName = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;
        CommonHelper ch = null;
        public PurchaseOrderProvider(string userName, IHttpContextAccessor httpContextAccessor = null)
        {
            _httpContextAccessor = httpContextAccessor;
            _userName = userName;
            if (httpContextAccessor != null)
            {
                ch = new CommonHelper(_httpContextAccessor);
            }
            else
            {

                ch = new CommonHelper();
            }
        }

        public List<io.PurchaseOrder> GetAllPurchaseOrder(io.PurchaseOrder PoIoModel = null)
        {
            if (PoIoModel == null)
                return (List<io.PurchaseOrder>)ch.GetRequest<io.PurchaseOrder>("purchaseOrder");
            else
                return (List<io.PurchaseOrder>)ch.GetDetailsRequest<io.PurchaseOrder>("purchaseOrder/posearch", PoIoModel);
        }
        public ResponseBody AddPurchaseOrder(io.PurchaseOrder PoIoModel = null)
        {
            if (PoIoModel != null)
            {
                if (PoIoModel.Guid == Guid.Empty)
                {
                    PoIoModel.CreatedBy = _userName;
                    PoIoModel.CreatedDateTime = DateTime.Now;
                    return ch.PostRequest<io.PurchaseOrder>("purchaseOrder/CreatePO", PoIoModel);
                }
                PoIoModel.LastUpdatedBy = _userName;
                PoIoModel.LastUpdatedDateTime = DateTime.Now;
                return ch.PostRequest<io.PurchaseOrder>("purchaseOrder/UpdatePo", PoIoModel);
            }
            else
                return null;
        }

        public ResponseBody UpdatePurchaseOrder(io.PurchaseOrder PoIoModel = null)
        {
            PoIoModel.LastUpdatedBy = _userName;
            PoIoModel.LastUpdatedDateTime = DateTime.Now;
            return ch.PostRequest<io.PurchaseOrder>("purchaseOrder/UpdatePoByName", PoIoModel);
        }

        public IEnumerable<io.PurchaseOrder> GetDropDown()
        {
            return (IEnumerable<io.PurchaseOrder>)ch.GetRequest<io.PurchaseOrder>("purchaseOrder/combo");
        }
        public IEnumerable<io.PurchaseOrder> GetUserProjectPurchaseDropDown(io.PurchaseOrder PoIoModel = null)
        {
            PoIoModel = new io.PurchaseOrder();
            return (IEnumerable<io.PurchaseOrder>)ch.GetDetailsRequest<io.PurchaseOrder>("purchaseOrder/UserProjectPurchasOrder", PoIoModel);
        }

        public List<SelectListItem> GetSelectList(string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetDropDown().Select(i => new { i.Id, i.PurchaseOrderNo, i.Guid }).Where(s => s.PurchaseOrderNo != null).OrderByDescending(i => i.Id))
            {
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.PurchaseOrderNo, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.PurchaseOrderNo };

                newList.Add(selListItem);
            }
            return newList;
        }

        public List<SelectListItem> GetUserProjectPurchaseSelectList(string SelectedValue = null)
        {
            SelectListItem selListItem = new SelectListItem() { Value = "", Text = "" };
            List<SelectListItem> newList = new List<SelectListItem>();
            newList.Add(selListItem);

            foreach (var x in GetUserProjectPurchaseDropDown().Select(i => new { i.Id, i.PurchaseOrderNo, i.Guid }).Where(s => s.PurchaseOrderNo != null).OrderByDescending(i => i.Id))
            {
                if (SelectedValue != null && x.Guid.ToString() == SelectedValue)
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.PurchaseOrderNo, Selected = true };
                else
                    selListItem = new SelectListItem() { Value = x.Guid.ToString(), Text = x.PurchaseOrderNo };

                newList.Add(selListItem);
            }
            return newList;
        }
    }
}