﻿using Microsoft.Extensions.Configuration;
using System;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Collections.Generic;
using ViswaSamudraUI.Models;
using Microsoft.AspNetCore.Http;

namespace ViswaSamudraUI
{
    public class CommonHelper
    {
        public string _token = string.Empty;
        private readonly IHttpContextAccessor _httpContextAccessor;

        public CommonHelper(IHttpContextAccessor httpContextAccessor = null)
        {
            _httpContextAccessor = httpContextAccessor;
            if (httpContextAccessor != null)
            {
                _token = _httpContextAccessor.HttpContext.Session.GetString("auth-token");
            }
        }

        public CommonHelper(string token)
        {
            _token = token;
        }

        public static IConfiguration configuration { get; set; }

        String baseUri = configuration["urls"];

        public IEnumerable<T> GetRequest<T>(String Route)
        {
            IEnumerable<T> ModelList = null;
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseUri);
                client.DefaultRequestHeaders.Accept.Clear();
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                if (!string.IsNullOrEmpty(_token))
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);
                }
                var getdata = client.GetAsync(Route).Result;
                

                if (getdata.IsSuccessStatusCode)
                {
                    string result = getdata.Content.ReadAsStringAsync().Result;
                    ModelList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<T>>(result);
                }
                else
                {
                    Console.WriteLine("Error");
                }
                return ModelList;
            }
        }

        public IEnumerable<T> GetDetailsRequest<T>(String Route, T PoIoModel)
        {
            IEnumerable<T> ModelList = null;
            using (var client = new HttpClient())
            {
                if (!string.IsNullOrEmpty(_token))
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);
                }
                client.BaseAddress = new Uri(baseUri);
                var postTask = client.PostAsJsonAsync<T>(Route, PoIoModel);
                postTask.Wait();

                var getdata = postTask.Result;
                if (getdata.IsSuccessStatusCode)
                {
                    string result = getdata.Content.ReadAsStringAsync().Result;
                    ModelList = Newtonsoft.Json.JsonConvert.DeserializeObject<List<T>>(result);
                }
                else
                {
                    Console.WriteLine("Error");
                }
                return ModelList;
            }
        }

        public ResponseBody PostRequest<T>(String Route, T PoIoModel)
        {
            String Status = null;
            using (var client = new HttpClient())
            {
                if (!string.IsNullOrEmpty(_token))
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);
                }
                client.BaseAddress = new Uri(baseUri);
                var postTask = client.PostAsJsonAsync<T>(Route, PoIoModel);
                postTask.Wait();

                var getdata = postTask.Result;
                if (getdata.IsSuccessStatusCode)
                {
                    return new ResponseBody() { Success = true, Header = getdata.Headers.ToString().Contains("Location")?getdata.Headers.Location.ToString():null, Message = getdata.Content.ReadAsStringAsync().Result };
                }
                else
                {
                    Console.WriteLine("Error");
                    var responseContent = getdata.Content == null ?  "NoContent"
                    : getdata.Content.ReadAsStringAsync().GetAwaiter().GetResult();
                    //throw new HttpRequestException($"{getdata.StatusCode} (ReasonPhrase: {getdata.ReasonPhrase}, Content: {responseContent})");
                    return new ResponseBody() { Success = false, Message = responseContent };

                }
            }
        }

        public ResponseBody DeleteRequest<T>(String Route, T PoIoModel)
        {
            return PostRequest(Route, PoIoModel);
        }

        public T GetDetailsRequest<T>(String Route)
        {
            using (var client = new HttpClient())
            {
                client.BaseAddress = new Uri(baseUri);
                client.DefaultRequestHeaders.Accept.Clear();
                if (!string.IsNullOrEmpty(_token))
                {
                    client.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("Bearer", _token);
                }
                client.DefaultRequestHeaders.Accept.Add(new MediaTypeWithQualityHeaderValue("application/json"));
                var getdata = client.GetAsync(Route).Result;


                if (getdata.IsSuccessStatusCode)
                {
                    string result = getdata.Content.ReadAsStringAsync().Result;
                    T Model = Newtonsoft.Json.JsonConvert.DeserializeObject<T>(result);
                    return Model;
                }
                else
                {
                    Console.WriteLine("Error");
                    return (T)Activator.CreateInstance(typeof(T));
                }
            }
        }

    }
}